import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from datetime import date, timedelta
import time
import datetime

try:
    current_date =  time.strftime('%Y-%m-%d',time.localtime(time.time()))
    print("Current Date is: {}".format(current_date))
    
    BucketName = 'lly-cn-ibu-rapid-cmds-prd-private'
    RootFolderName = 'ToRAPID/m_slv'
    
    m_slv_ProcessDir = RootFolderName + '/'+ current_date +'/process'
    
    
    m_slv_DestinationDir = RootFolderName + '/'+ current_date +'/m_slv.csv'
    
    FlagFileS3Path = 'rapid-flag-file/done.rdy'
    
    m_slv_RdyFilePath = RootFolderName + '/'+ current_date +'/m_slv.rdy'
    
    
    database_name = "rapid-prd-catalog-gluedatabase"
    m_slv_table_name = "rapid_prd_cmdsprd_cmd_owner_m_slv"
    
    
    
    ## @params: [JOB_NAME]
    args = getResolvedOptions(sys.argv, ['JOB_NAME'])
    
    sc = SparkContext()
    glueContext = GlueContext(sc)
    spark = glueContext.spark_session
    job = Job(glueContext)
    job.init(args['JOB_NAME'], args)
    
    
    ## m_slv table
    m_slv_datasource = glueContext.create_dynamic_frame.from_catalog(database = database_name, table_name = m_slv_table_name, transformation_ctx = "m_slv_datasource")
    
    
    m_slv_repartitionDF = m_slv_datasource.toDF()
    
    
    ## Merge all partition file into one csv and change type from dynamic frame to spark dataframe
    m_slv_repartitionDF = m_slv_repartitionDF.coalesce(1)
    
    
    print ("m_slv Count:  ", m_slv_repartitionDF.count())
    print(m_slv_repartitionDF)
    m_slv_repartitionDF.write.format('csv').mode("overwrite").save("s3://" + BucketName + "/" + m_slv_ProcessDir,sep=",",header='true')
    print("Load m_slv to S3 folder: {} successfully.".format(m_slv_ProcessDir))
    
    
    
    ## ------------------------------ m_slv S3 Processing Logic ------------------------------------
    import boto3
    client = boto3.client('s3')
    
    m_slv_Response = client.list_objects(
        Bucket=BucketName,
        Prefix=m_slv_ProcessDir,
    )
    
    
    m_slv__process_file_absolutely_s3_path = m_slv_Response["Contents"][0]["Key"]
    
    
    print("m_slv__process_file_absolutely_s3_path: ",m_slv__process_file_absolutely_s3_path)
    m_slv_copy_source = {'Bucket': BucketName, 'Key': m_slv__process_file_absolutely_s3_path}
    print("m_slv_copy_source: ",m_slv_copy_source)
    
    
    print(m_slv_DestinationDir)
    
    client.copy(CopySource=m_slv_copy_source, Bucket=BucketName, Key=m_slv_DestinationDir)
    print("File moving from m_slv process folder to desitination folder done.")
    
    ## Delete folder in S3
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(BucketName)
    bucket.objects.filter(Prefix=m_slv_ProcessDir).delete()
    print("Delete S3 m_slv process folder: {} done.".format(m_slv_ProcessDir))
    
    ## Copy flag file and rename it
    m_slv_CopyFlagFileDict = {'Bucket': BucketName, 'Key': FlagFileS3Path}
    print("m_slv_CopyFlagFileDict: ",m_slv_CopyFlagFileDict)
    
    client.copy(CopySource=m_slv_CopyFlagFileDict, Bucket=BucketName, Key=m_slv_RdyFilePath)
    print("Move m_slv rdy file to S3 path: {} done.".format(m_slv_RdyFilePath))
    
    
    job.commit()

except Exception as e:
    print(e)
    raise e
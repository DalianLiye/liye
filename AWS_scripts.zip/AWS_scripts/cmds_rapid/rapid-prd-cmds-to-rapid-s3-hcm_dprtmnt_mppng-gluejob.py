import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from datetime import date, timedelta
import time
import datetime

try:
    current_date =  time.strftime('%Y-%m-%d',time.localtime(time.time()))
    print("Current Date is: {}".format(current_date))
    
    BucketName = 'lly-cn-ibu-rapid-cmds-prd-private'
    RootFolderName = 'ToRAPID/hcm_dprtmnt_mppng'
    
    hcm_dprtmnt_mppng_ProcessDir = RootFolderName + '/'+ current_date +'/process'
    
    
    hcm_dprtmnt_mppng_DestinationDir = RootFolderName + '/'+ current_date +'/hcm_dprtmnt_mppng.csv'
    
    FlagFileS3Path = 'rapid-flag-file/done.rdy'
    
    hcm_dprtmnt_mppng_RdyFilePath = RootFolderName + '/'+ current_date +'/hcm_dprtmnt_mppng.rdy'
    
    
    database_name = "rapid-prd-catalog-gluedatabase"
    hcm_dprtmnt_mppng_table_name = "rapid_prd_cmdsprd_cmd_owner_hcm_dprtmnt_mppng"
    
    
    
    ## @params: [JOB_NAME]
    args = getResolvedOptions(sys.argv, ['JOB_NAME'])
    
    sc = SparkContext()
    glueContext = GlueContext(sc)
    spark = glueContext.spark_session
    job = Job(glueContext)
    job.init(args['JOB_NAME'], args)
    
    
    ## hcm_dprtmnt_mppng table
    hcm_dprtmnt_mppng_datasource = glueContext.create_dynamic_frame.from_catalog(database = database_name, table_name = hcm_dprtmnt_mppng_table_name, transformation_ctx = "hcm_dprtmnt_mppng_datasource")
    
    
    hcm_dprtmnt_mppng_repartitionDF = hcm_dprtmnt_mppng_datasource.toDF()
    
    
    ## Merge all partition file into one csv and change type from dynamic frame to spark dataframe
    hcm_dprtmnt_mppng_repartitionDF = hcm_dprtmnt_mppng_repartitionDF.coalesce(1)
    
    
    print ("hcm_dprtmnt_mppng Count:  ", hcm_dprtmnt_mppng_repartitionDF.count())
    print(hcm_dprtmnt_mppng_repartitionDF)
    hcm_dprtmnt_mppng_repartitionDF.write.format('csv').mode("overwrite").save("s3://" + BucketName + "/" + hcm_dprtmnt_mppng_ProcessDir,sep=",",header='true')
    print("Load hcm_dprtmnt_mppng to S3 folder: {} successfully.".format(hcm_dprtmnt_mppng_ProcessDir))
    
    
    
    ## ------------------------------ hcm_dprtmnt_mppng S3 Processing Logic ------------------------------------
    import boto3
    client = boto3.client('s3')
    
    hcm_dprtmnt_mppng_Response = client.list_objects(
        Bucket=BucketName,
        Prefix=hcm_dprtmnt_mppng_ProcessDir,
    )
    
    
    hcm_dprtmnt_mppng__process_file_absolutely_s3_path = hcm_dprtmnt_mppng_Response["Contents"][0]["Key"]
    
    
    print("hcm_dprtmnt_mppng__process_file_absolutely_s3_path: ",hcm_dprtmnt_mppng__process_file_absolutely_s3_path)
    hcm_dprtmnt_mppng_copy_source = {'Bucket': BucketName, 'Key': hcm_dprtmnt_mppng__process_file_absolutely_s3_path}
    print("hcm_dprtmnt_mppng_copy_source: ",hcm_dprtmnt_mppng_copy_source)
    
    
    print(hcm_dprtmnt_mppng_DestinationDir)
    
    client.copy(CopySource=hcm_dprtmnt_mppng_copy_source, Bucket=BucketName, Key=hcm_dprtmnt_mppng_DestinationDir)
    print("File moving from hcm_dprtmnt_mppng process folder to desitination folder done.")
    
    ## Delete folder in S3
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(BucketName)
    bucket.objects.filter(Prefix=hcm_dprtmnt_mppng_ProcessDir).delete()
    print("Delete S3 hcm_dprtmnt_mppng process folder: {} done.".format(hcm_dprtmnt_mppng_ProcessDir))
    
    ## Copy flag file and rename it
    hcm_dprtmnt_mppng_CopyFlagFileDict = {'Bucket': BucketName, 'Key': FlagFileS3Path}
    print("hcm_dprtmnt_mppng_CopyFlagFileDict: ",hcm_dprtmnt_mppng_CopyFlagFileDict)
    
    client.copy(CopySource=hcm_dprtmnt_mppng_CopyFlagFileDict, Bucket=BucketName, Key=hcm_dprtmnt_mppng_RdyFilePath)
    print("Move hcm_dprtmnt_mppng rdy file to S3 path: {} done.".format(hcm_dprtmnt_mppng_RdyFilePath))
    
    
    job.commit()

except Exception as e:
    print(e)
    raise e
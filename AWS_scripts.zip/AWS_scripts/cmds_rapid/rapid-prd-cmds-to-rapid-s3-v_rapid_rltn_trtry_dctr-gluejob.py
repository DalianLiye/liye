import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from datetime import date, timedelta
import time
import datetime

try:
    current_date =  time.strftime('%Y-%m-%d',time.localtime(time.time()))
    print("Current Date is: {}".format(current_date))
    
    BucketName = 'lly-cn-ibu-rapid-cmds-prd-private'
    RootFolderName = 'ToRAPID/v_rapid_rltn_trtry_dctr'
    
    v_rapid_rltn_trtry_dctr_ProcessDir = RootFolderName + '/'+ current_date +'/process'
    
    
    v_rapid_rltn_trtry_dctr_DestinationDir = RootFolderName + '/'+ current_date +'/v_rapid_rltn_trtry_dctr.csv'
    
    FlagFileS3Path = 'rapid-flag-file/done.rdy'
    
    v_rapid_rltn_trtry_dctr_RdyFilePath = RootFolderName + '/'+ current_date +'/v_rapid_rltn_trtry_dctr.rdy'
    
    
    database_name = "rapid-prd-catalog-gluedatabase"
    v_rapid_rltn_trtry_dctr_table_name = "rapid_prd_cmdsprd_cmd_owner_v_rapid_rltn_trtry_dctr"
    
    
    
    ## @params: [JOB_NAME]
    args = getResolvedOptions(sys.argv, ['JOB_NAME'])
    
    sc = SparkContext()
    glueContext = GlueContext(sc)
    spark = glueContext.spark_session
    job = Job(glueContext)
    job.init(args['JOB_NAME'], args)
    
    
    ## v_rapid_rltn_trtry_dctr table
    v_rapid_rltn_trtry_dctr_datasource = glueContext.create_dynamic_frame.from_catalog(database = database_name, table_name = v_rapid_rltn_trtry_dctr_table_name, transformation_ctx = "v_rapid_rltn_trtry_dctr_datasource")
    
    
    v_rapid_rltn_trtry_dctr_repartitionDF = v_rapid_rltn_trtry_dctr_datasource.toDF()
    
    
    ## Merge all partition file into one csv and change type from dynamic frame to spark dataframe
    v_rapid_rltn_trtry_dctr_repartitionDF = v_rapid_rltn_trtry_dctr_repartitionDF.coalesce(1)
    
    
    print ("v_rapid_rltn_trtry_dctr Count:  ", v_rapid_rltn_trtry_dctr_repartitionDF.count())
    print(v_rapid_rltn_trtry_dctr_repartitionDF)
    v_rapid_rltn_trtry_dctr_repartitionDF.write.format('csv').mode("overwrite").save("s3://" + BucketName + "/" + v_rapid_rltn_trtry_dctr_ProcessDir,sep=",",header='true')
    print("Load v_rapid_rltn_trtry_dctr to S3 folder: {} successfully.".format(v_rapid_rltn_trtry_dctr_ProcessDir))
    
    
    
    ## ------------------------------ v_rapid_rltn_trtry_dctr S3 Processing Logic ------------------------------------
    import boto3
    client = boto3.client('s3')
    
    v_rapid_rltn_trtry_dctr_Response = client.list_objects(
        Bucket=BucketName,
        Prefix=v_rapid_rltn_trtry_dctr_ProcessDir,
    )
    
    
    v_rapid_rltn_trtry_dctr__process_file_absolutely_s3_path = v_rapid_rltn_trtry_dctr_Response["Contents"][0]["Key"]
    
    
    print("v_rapid_rltn_trtry_dctr__process_file_absolutely_s3_path: ",v_rapid_rltn_trtry_dctr__process_file_absolutely_s3_path)
    v_rapid_rltn_trtry_dctr_copy_source = {'Bucket': BucketName, 'Key': v_rapid_rltn_trtry_dctr__process_file_absolutely_s3_path}
    print("v_rapid_rltn_trtry_dctr_copy_source: ",v_rapid_rltn_trtry_dctr_copy_source)
    
    
    print(v_rapid_rltn_trtry_dctr_DestinationDir)
    
    client.copy(CopySource=v_rapid_rltn_trtry_dctr_copy_source, Bucket=BucketName, Key=v_rapid_rltn_trtry_dctr_DestinationDir)
    print("File moving from v_rapid_rltn_trtry_dctr process folder to desitination folder done.")
    
    ## Delete folder in S3
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(BucketName)
    bucket.objects.filter(Prefix=v_rapid_rltn_trtry_dctr_ProcessDir).delete()
    print("Delete S3 v_rapid_rltn_trtry_dctr process folder: {} done.".format(v_rapid_rltn_trtry_dctr_ProcessDir))
    
    ## Copy flag file and rename it
    v_rapid_rltn_trtry_dctr_CopyFlagFileDict = {'Bucket': BucketName, 'Key': FlagFileS3Path}
    print("v_rapid_rltn_trtry_dctr_CopyFlagFileDict: ",v_rapid_rltn_trtry_dctr_CopyFlagFileDict)
    
    client.copy(CopySource=v_rapid_rltn_trtry_dctr_CopyFlagFileDict, Bucket=BucketName, Key=v_rapid_rltn_trtry_dctr_RdyFilePath)
    print("Move v_rapid_rltn_trtry_dctr rdy file to S3 path: {} done.".format(v_rapid_rltn_trtry_dctr_RdyFilePath))
    
    
    job.commit()

except Exception as e:
    print(e)
    raise e
import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from datetime import date, timedelta
import time
import datetime

try:
    current_date =  time.strftime('%Y-%m-%d',time.localtime(time.time()))
    print("Current Date is: {}".format(current_date))
    
    BucketName = 'lly-cn-ibu-rapid-cmds-prd-private'
    RootFolderName = 'ToRAPID/m_rltn_slv_trtry'
    
    m_rltn_slv_trtry_ProcessDir = RootFolderName + '/'+ current_date +'/process'
    
    
    m_rltn_slv_trtry_DestinationDir = RootFolderName + '/'+ current_date +'/m_rltn_slv_trtry.csv'
    
    FlagFileS3Path = 'rapid-flag-file/done.rdy'
    
    m_rltn_slv_trtry_RdyFilePath = RootFolderName + '/'+ current_date +'/m_rltn_slv_trtry.rdy'
    
    
    database_name = "rapid-prd-catalog-gluedatabase"
    m_rltn_slv_trtry_table_name = "rapid_prd_cmdsprd_cmd_owner_m_rltn_slv_trtry"
    
    
    
    ## @params: [JOB_NAME]
    args = getResolvedOptions(sys.argv, ['JOB_NAME'])
    
    sc = SparkContext()
    glueContext = GlueContext(sc)
    spark = glueContext.spark_session
    job = Job(glueContext)
    job.init(args['JOB_NAME'], args)
    
    
    ## m_rltn_slv_trtry table
    m_rltn_slv_trtry_datasource = glueContext.create_dynamic_frame.from_catalog(database = database_name, table_name = m_rltn_slv_trtry_table_name, transformation_ctx = "m_rltn_slv_trtry_datasource")
    
    
    m_rltn_slv_trtry_repartitionDF = m_rltn_slv_trtry_datasource.toDF()
    
    
    ## Merge all partition file into one csv and change type from dynamic frame to spark dataframe
    m_rltn_slv_trtry_repartitionDF = m_rltn_slv_trtry_repartitionDF.coalesce(1)
    
    
    print ("m_rltn_slv_trtry Count:  ", m_rltn_slv_trtry_repartitionDF.count())
    print(m_rltn_slv_trtry_repartitionDF)
    m_rltn_slv_trtry_repartitionDF.write.format('csv').mode("overwrite").save("s3://" + BucketName + "/" + m_rltn_slv_trtry_ProcessDir,sep=",",header='true')
    print("Load m_rltn_slv_trtry to S3 folder: {} successfully.".format(m_rltn_slv_trtry_ProcessDir))
    
    
    
    ## ------------------------------ m_rltn_slv_trtry S3 Processing Logic ------------------------------------
    import boto3
    client = boto3.client('s3')
    
    m_rltn_slv_trtry_Response = client.list_objects(
        Bucket=BucketName,
        Prefix=m_rltn_slv_trtry_ProcessDir,
    )
    
    
    m_rltn_slv_trtry__process_file_absolutely_s3_path = m_rltn_slv_trtry_Response["Contents"][0]["Key"]
    
    
    print("m_rltn_slv_trtry__process_file_absolutely_s3_path: ",m_rltn_slv_trtry__process_file_absolutely_s3_path)
    m_rltn_slv_trtry_copy_source = {'Bucket': BucketName, 'Key': m_rltn_slv_trtry__process_file_absolutely_s3_path}
    print("m_rltn_slv_trtry_copy_source: ",m_rltn_slv_trtry_copy_source)
    
    
    print(m_rltn_slv_trtry_DestinationDir)
    
    client.copy(CopySource=m_rltn_slv_trtry_copy_source, Bucket=BucketName, Key=m_rltn_slv_trtry_DestinationDir)
    print("File moving from m_rltn_slv_trtry process folder to desitination folder done.")
    
    ## Delete folder in S3
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(BucketName)
    bucket.objects.filter(Prefix=m_rltn_slv_trtry_ProcessDir).delete()
    print("Delete S3 m_rltn_slv_trtry process folder: {} done.".format(m_rltn_slv_trtry_ProcessDir))
    
    ## Copy flag file and rename it
    m_rltn_slv_trtry_CopyFlagFileDict = {'Bucket': BucketName, 'Key': FlagFileS3Path}
    print("m_rltn_slv_trtry_CopyFlagFileDict: ",m_rltn_slv_trtry_CopyFlagFileDict)
    
    client.copy(CopySource=m_rltn_slv_trtry_CopyFlagFileDict, Bucket=BucketName, Key=m_rltn_slv_trtry_RdyFilePath)
    print("Move m_rltn_slv_trtry rdy file to S3 path: {} done.".format(m_rltn_slv_trtry_RdyFilePath))
    
    
    job.commit()

except Exception as e:
    print(e)
    raise e
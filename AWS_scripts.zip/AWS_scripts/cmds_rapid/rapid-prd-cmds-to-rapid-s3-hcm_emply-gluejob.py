import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from datetime import date, timedelta
import time
import datetime

current_date =  time.strftime('%Y-%m-%d',time.localtime(time.time()))
print("Current Date is: {}".format(current_date))

BucketName = 'lly-cn-ibu-rapid-cmds-prd-private'
RootFolderName = 'ToRAPID/hcm_emply'

hcm_emply_ProcessDir = RootFolderName + '/'+ current_date +'/process'


hcm_emply_DestinationDir = RootFolderName + '/'+ current_date +'/hcm_emply.csv'

FlagFileS3Path = 'rapid-flag-file/done.rdy'

hcm_emply_RdyFilePath = RootFolderName + '/'+ current_date +'/hcm_emply.rdy'


database_name = "rapid-prd-catalog-gluedatabase"
hcm_emply_table_name = "rapid_prd_cmdsprd_cmd_owner_hcm_emply"



## @params: [JOB_NAME]
args = getResolvedOptions(sys.argv, ['JOB_NAME'])

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)


## hcm_emply table
hcm_emply_datasource = glueContext.create_dynamic_frame.from_catalog(database = database_name, table_name = hcm_emply_table_name, transformation_ctx = "hcm_emply_datasource")


hcm_emply_repartitionDF = hcm_emply_datasource.toDF()


## Merge all partition file into one csv and change type from dynamic frame to spark dataframe
hcm_emply_repartitionDF = hcm_emply_repartitionDF.coalesce(1)


print ("hcm_emply Count:  ", hcm_emply_repartitionDF.count())
print(hcm_emply_repartitionDF)
hcm_emply_repartitionDF.write.format('csv').mode("overwrite").save("s3://" + BucketName + "/" + hcm_emply_ProcessDir,sep=",",header='true')
print("Load hcm_emply to S3 folder: {} successfully.".format(hcm_emply_ProcessDir))



## ------------------------------ hcm_emply S3 Processing Logic ------------------------------------
import boto3
client = boto3.client('s3')

hcm_emply_Response = client.list_objects(
    Bucket=BucketName,
    Prefix=hcm_emply_ProcessDir,
)


hcm_emply__process_file_absolutely_s3_path = hcm_emply_Response["Contents"][0]["Key"]


print("hcm_emply__process_file_absolutely_s3_path: ",hcm_emply__process_file_absolutely_s3_path)
hcm_emply_copy_source = {'Bucket': BucketName, 'Key': hcm_emply__process_file_absolutely_s3_path}
print("hcm_emply_copy_source: ",hcm_emply_copy_source)


print(hcm_emply_DestinationDir)

client.copy(CopySource=hcm_emply_copy_source, Bucket=BucketName, Key=hcm_emply_DestinationDir)
print("File moving from hcm_emply process folder to desitination folder done.")

## Delete folder in S3
s3 = boto3.resource('s3')
bucket = s3.Bucket(BucketName)
bucket.objects.filter(Prefix=hcm_emply_ProcessDir).delete()
print("Delete S3 hcm_emply process folder: {} done.".format(hcm_emply_ProcessDir))

## Copy flag file and rename it
hcm_emply_CopyFlagFileDict = {'Bucket': BucketName, 'Key': FlagFileS3Path}
print("hcm_emply_CopyFlagFileDict: ",hcm_emply_CopyFlagFileDict)

client.copy(CopySource=hcm_emply_CopyFlagFileDict, Bucket=BucketName, Key=hcm_emply_RdyFilePath)
print("Move hcm_emply rdy file to S3 path: {} done.".format(hcm_emply_RdyFilePath))


job.commit()
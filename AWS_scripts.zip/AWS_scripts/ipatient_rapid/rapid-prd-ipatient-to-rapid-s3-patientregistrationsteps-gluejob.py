import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from datetime import date, timedelta
import time
import datetime
import pyspark.sql.functions as F
import pyspark.sql.types as T

try:
    current_date =  time.strftime('%Y-%m-%d',time.localtime(time.time()))
    print("------Current Date is: {}".format(current_date))
    
    BucketName = 'lly-cn-ibu-rapid-ipatient-prd-private'
    RootFolderName = 'ToRAPID/patientregistrationsteps'
    
    patientregistrationsteps_ProcessDir = RootFolderName + '/'+ current_date +'/process'
    
    
    patientregistrationsteps_DestinationDir = RootFolderName + '/'+ current_date +'/patientregistrationsteps.csv'
    
    FlagFileS3Path = 'rapid-flag-file/done.rdy'
    
    patientregistrationsteps_RdyFilePath = RootFolderName + '/'+ current_date +'/patientregistrationsteps.rdy'
    
    
    database_name = "rapid-prd-catalog-gluedatabase"
    patientregistrationsteps_table_name = "rapid_prd_ipatientprd_rpt_patientregistrationsteps"
    
    
    ## @params: [JOB_NAME]
    args = getResolvedOptions(sys.argv, ['JOB_NAME'])
    
    sc = SparkContext()
    glueContext = GlueContext(sc)
    spark = glueContext.spark_session
    job = Job(glueContext)
    job.init(args['JOB_NAME'], args)
    
    
    ## patientregistrationsteps table
    patientregistrationsteps_datasource = glueContext.create_dynamic_frame.from_catalog(database = database_name, table_name = patientregistrationsteps_table_name, transformation_ctx = "patientregistrationsteps_datasource")
    
    
    patientregistrationsteps_repartitionDF = patientregistrationsteps_datasource.toDF()
    
    
    ## Merge all partition file into one csv and change type from dynamic frame to spark dataframe
    patientregistrationsteps_repartitionDF = patientregistrationsteps_repartitionDF.coalesce(1)
    
    print ("------patientregistrationsteps Count:  ", patientregistrationsteps_repartitionDF.count())
    print(patientregistrationsteps_repartitionDF)
    patientregistrationsteps_repartitionDF.write.format('csv').mode("overwrite").save("s3://" + BucketName + "/" + patientregistrationsteps_ProcessDir,sep=",",header='true')
    print("------Load patientregistrationsteps to S3 folder: {} successfully.".format(patientregistrationsteps_ProcessDir))
    
    
    
    ## ------------------------------ patientregistrationsteps S3 Processing Logic ------------------------------------
    import boto3
    client = boto3.client('s3')
    
    patientregistrationsteps_Response = client.list_objects(
        Bucket=BucketName,
        Prefix=patientregistrationsteps_ProcessDir,
    )
    
    
    patientregistrationsteps__process_file_absolutely_s3_path = patientregistrationsteps_Response["Contents"][0]["Key"]
    
    
    print("------patientregistrationsteps__process_file_absolutely_s3_path: ",patientregistrationsteps__process_file_absolutely_s3_path)
    patientregistrationsteps_copy_source = {'Bucket': BucketName, 'Key': patientregistrationsteps__process_file_absolutely_s3_path}
    print("------patientregistrationsteps_copy_source: ",patientregistrationsteps_copy_source)
    
    
    print(patientregistrationsteps_DestinationDir)
    
    client.copy(CopySource=patientregistrationsteps_copy_source, Bucket=BucketName, Key=patientregistrationsteps_DestinationDir)
    print("------File moving from patientregistrationsteps process folder to desitination folder done.")
    
    ## Delete folder in S3
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(BucketName)
    bucket.objects.filter(Prefix=patientregistrationsteps_ProcessDir).delete()
    print("------Delete S3 patientregistrationsteps process folder: {} done.".format(patientregistrationsteps_ProcessDir))
    
    ## Copy flag file and rename it
    patientregistrationsteps_CopyFlagFileDict = {'Bucket': BucketName, 'Key': FlagFileS3Path}
    print("------patientregistrationsteps_CopyFlagFileDict: ",patientregistrationsteps_CopyFlagFileDict)
    
    client.copy(CopySource=patientregistrationsteps_CopyFlagFileDict, Bucket=BucketName, Key=patientregistrationsteps_RdyFilePath)
    print("------Move patientregistrationsteps rdy file to S3 path: {} done.".format(patientregistrationsteps_RdyFilePath))
    
    
    job.commit()

except Exception as e:
    print(e)
    raise e
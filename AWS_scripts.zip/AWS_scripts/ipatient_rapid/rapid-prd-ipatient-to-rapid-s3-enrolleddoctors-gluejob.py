import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from datetime import date, timedelta
import time
import datetime
import pyspark.sql.functions as F
import pyspark.sql.types as T

try:
    current_date =  time.strftime('%Y-%m-%d',time.localtime(time.time()))
    print("------Current Date is: {}".format(current_date))
    
    BucketName = 'lly-cn-ibu-rapid-ipatient-prd-private'
    RootFolderName = 'ToRAPID/enrolleddoctors'
    
    enrolleddoctors_ProcessDir = RootFolderName + '/'+ current_date +'/process'
    
    
    enrolleddoctors_DestinationDir = RootFolderName + '/'+ current_date +'/enrolleddoctors.csv'
    
    FlagFileS3Path = 'rapid-flag-file/done.rdy'
    
    enrolleddoctors_RdyFilePath = RootFolderName + '/'+ current_date +'/enrolleddoctors.rdy'
    
    
    database_name = "rapid-prd-catalog-gluedatabase"
    enrolleddoctors_table_name = "rapid_prd_ipatientprd_rpt_enrolleddoctors"
    
    
    ## @params: [JOB_NAME]
    args = getResolvedOptions(sys.argv, ['JOB_NAME'])
    
    sc = SparkContext()
    glueContext = GlueContext(sc)
    spark = glueContext.spark_session
    job = Job(glueContext)
    job.init(args['JOB_NAME'], args)
    
    
    ## enrolleddoctors table
    enrolleddoctors_datasource = glueContext.create_dynamic_frame.from_catalog(database = database_name, table_name = enrolleddoctors_table_name, transformation_ctx = "enrolleddoctors_datasource")
    
    
    enrolleddoctors_repartitionDF = enrolleddoctors_datasource.toDF()
    
    
    ## Merge all partition file into one csv and change type from dynamic frame to spark dataframe
    enrolleddoctors_repartitionDF = enrolleddoctors_repartitionDF.coalesce(1)
    
    print ("------enrolleddoctors Count:  ", enrolleddoctors_repartitionDF.count())
    print(enrolleddoctors_repartitionDF)
    enrolleddoctors_repartitionDF.write.format('csv').mode("overwrite").save("s3://" + BucketName + "/" + enrolleddoctors_ProcessDir,sep=",",header='true')
    print("------Load enrolleddoctors to S3 folder: {} successfully.".format(enrolleddoctors_ProcessDir))
    
    
    
    ## ------------------------------ enrolleddoctors S3 Processing Logic ------------------------------------
    import boto3
    client = boto3.client('s3')
    
    enrolleddoctors_Response = client.list_objects(
        Bucket=BucketName,
        Prefix=enrolleddoctors_ProcessDir,
    )
    
    
    enrolleddoctors__process_file_absolutely_s3_path = enrolleddoctors_Response["Contents"][0]["Key"]
    
    
    print("------enrolleddoctors__process_file_absolutely_s3_path: ",enrolleddoctors__process_file_absolutely_s3_path)
    enrolleddoctors_copy_source = {'Bucket': BucketName, 'Key': enrolleddoctors__process_file_absolutely_s3_path}
    print("------enrolleddoctors_copy_source: ",enrolleddoctors_copy_source)
    
    
    print(enrolleddoctors_DestinationDir)
    
    client.copy(CopySource=enrolleddoctors_copy_source, Bucket=BucketName, Key=enrolleddoctors_DestinationDir)
    print("------File moving from enrolleddoctors process folder to desitination folder done.")
    
    ## Delete folder in S3
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(BucketName)
    bucket.objects.filter(Prefix=enrolleddoctors_ProcessDir).delete()
    print("------Delete S3 enrolleddoctors process folder: {} done.".format(enrolleddoctors_ProcessDir))
    
    ## Copy flag file and rename it
    enrolleddoctors_CopyFlagFileDict = {'Bucket': BucketName, 'Key': FlagFileS3Path}
    print("------enrolleddoctors_CopyFlagFileDict: ",enrolleddoctors_CopyFlagFileDict)
    
    client.copy(CopySource=enrolleddoctors_CopyFlagFileDict, Bucket=BucketName, Key=enrolleddoctors_RdyFilePath)
    print("------Move enrolleddoctors rdy file to S3 path: {} done.".format(enrolleddoctors_RdyFilePath))
    
    
    job.commit()

except Exception as e:
    print(e)
    raise e
    
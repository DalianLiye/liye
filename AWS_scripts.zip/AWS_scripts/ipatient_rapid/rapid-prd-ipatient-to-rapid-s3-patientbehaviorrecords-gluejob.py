import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from datetime import date, timedelta
import time
import datetime
import pyspark.sql.functions as F
import pyspark.sql.types as T
from py4j.java_gateway import java_import

try:
    current_date =  time.strftime('%Y-%m-%d',time.localtime(time.time()))
    print("------Current Date is: {}".format(current_date))
    
    BucketName = 'lly-cn-ibu-rapid-ipatient-prd-private'
    RootFolderName = 'ToRAPID/patientbehaviorrecords'
    
    patientbehaviorrecords_ProcessDir = RootFolderName + '/'+ current_date +'/process'
    
    
    patientbehaviorrecords_DestinationDir = RootFolderName + '/'+ current_date +'/patientbehaviorrecords.csv'
    
    FlagFileS3Path = 'rapid-flag-file/done.rdy'
    
    patientbehaviorrecords_RdyFilePath = RootFolderName + '/'+ current_date +'/patientbehaviorrecords.rdy'
    
    
    database_name = "rapid-prd-catalog-gluedatabase"
    patientbehaviorrecords_table_name = "rapid_prd_ipatientprd_rpt_patientbehaviorrecords"
    
    ## @params: [JOB_NAME]
    args = getResolvedOptions(sys.argv, ['JOB_NAME'])
    
    sc = SparkContext()
    glueContext = GlueContext(sc)
    spark = glueContext.spark_session
    job = Job(glueContext)
    job.init(args['JOB_NAME'], args)
    
    source_jdbc_conf = glueContext.extract_jdbc_conf('rapid-prd-ipatient-connreader')
    java_import(sc._gateway.jvm,"java.sql.Connection")
    java_import(sc._gateway.jvm,"java.sql.DatabaseMetaData")
    java_import(sc._gateway.jvm,"java.sql.DriverManager")
    java_import(sc._gateway.jvm,"java.sql.SQLException")
    conn = sc._gateway.jvm.DriverManager.getConnection(source_jdbc_conf.get('url') + '/ipatientprd',source_jdbc_conf.get('user'),source_jdbc_conf.get('password'))
    stmt = conn.createStatement()
    try:
        rs = stmt.executeQuery('select * from rpt.fun_patientbehaviorrecords_create_table()')
    except:
        print("An exception occurred but proc has run")
    conn.close()

    ## patientbehaviorrecords table
    patientbehaviorrecords_datasource = glueContext.create_dynamic_frame.from_catalog(database = database_name, table_name = patientbehaviorrecords_table_name, transformation_ctx = "patientbehaviorrecords_datasource")
    
    
    patientbehaviorrecords_repartitionDF = patientbehaviorrecords_datasource.toDF()
    
    
    ## Merge all partition file into one csv and change type from dynamic frame to spark dataframe
    patientbehaviorrecords_repartitionDF = patientbehaviorrecords_repartitionDF.coalesce(1)
    
    ## scientific notation cloumn with long type 20210701
    
    print ("------patientbehaviorrecords Count:  ", patientbehaviorrecords_repartitionDF.count())
    print(patientbehaviorrecords_repartitionDF)
    patientbehaviorrecords_repartitionDF.write.format('csv').mode("overwrite").save("s3://" + BucketName + "/" + patientbehaviorrecords_ProcessDir,sep=",",header='true')
    print("------Load patientbehaviorrecords to S3 folder: {} successfully.".format(patientbehaviorrecords_ProcessDir))
    
    
    
    ## ------------------------------ patientbehaviorrecords S3 Processing Logic ------------------------------------
    import boto3
    client = boto3.client('s3')
    
    patientbehaviorrecords_Response = client.list_objects(
        Bucket=BucketName,
        Prefix=patientbehaviorrecords_ProcessDir,
    )
    
    
    patientbehaviorrecords__process_file_absolutely_s3_path = patientbehaviorrecords_Response["Contents"][0]["Key"]
    
    
    print("------patientbehaviorrecords__process_file_absolutely_s3_path: ",patientbehaviorrecords__process_file_absolutely_s3_path)
    patientbehaviorrecords_copy_source = {'Bucket': BucketName, 'Key': patientbehaviorrecords__process_file_absolutely_s3_path}
    print("------patientbehaviorrecords_copy_source: ",patientbehaviorrecords_copy_source)
    
    
    print(patientbehaviorrecords_DestinationDir)
    
    client.copy(CopySource=patientbehaviorrecords_copy_source, Bucket=BucketName, Key=patientbehaviorrecords_DestinationDir)
    print("------File moving from patientbehaviorrecords process folder to desitination folder done.")
    
    ## Delete folder in S3
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(BucketName)
    bucket.objects.filter(Prefix=patientbehaviorrecords_ProcessDir).delete()
    print("------Delete S3 patientbehaviorrecords process folder: {} done.".format(patientbehaviorrecords_ProcessDir))
    
    ## Copy flag file and rename it
    patientbehaviorrecords_CopyFlagFileDict = {'Bucket': BucketName, 'Key': FlagFileS3Path}
    print("------patientbehaviorrecords_CopyFlagFileDict: ",patientbehaviorrecords_CopyFlagFileDict)
    
    client.copy(CopySource=patientbehaviorrecords_CopyFlagFileDict, Bucket=BucketName, Key=patientbehaviorrecords_RdyFilePath)
    print("------Move patientbehaviorrecords rdy file to S3 path: {} done.".format(patientbehaviorrecords_RdyFilePath))
    
    
    job.commit()

except Exception as e:
    print(e)
    raise e
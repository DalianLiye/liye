import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from datetime import date, timedelta
import time
import datetime
import pyspark.sql.functions as F
import pyspark.sql.types as T

try:
    current_date =  time.strftime('%Y-%m-%d',time.localtime(time.time()))
    print("------Current Date is: {}".format(current_date))
    
    BucketName = 'lly-cn-ibu-rapid-ipatient-prd-private'
    RootFolderName = 'ToRAPID/doctorbehaviorrecords'
    
    doctorbehaviorrecords_ProcessDir = RootFolderName + '/'+ current_date +'/process'
    
    
    doctorbehaviorrecords_DestinationDir = RootFolderName + '/'+ current_date +'/doctorbehaviorrecords.csv'
    
    FlagFileS3Path = 'rapid-flag-file/done.rdy'
    
    doctorbehaviorrecords_RdyFilePath = RootFolderName + '/'+ current_date +'/doctorbehaviorrecords.rdy'
    
    
    database_name = "rapid-prd-catalog-gluedatabase"
    doctorbehaviorrecords_table_name = "rapid_prd_ipatientprd_rpt_doctorbehaviorrecords"
    
    
    
    ## @params: [JOB_NAME]
    args = getResolvedOptions(sys.argv, ['JOB_NAME'])
    
    sc = SparkContext()
    glueContext = GlueContext(sc)
    spark = glueContext.spark_session
    job = Job(glueContext)
    job.init(args['JOB_NAME'], args)
    
    
    ## doctorbehaviorrecords table
    doctorbehaviorrecords_datasource = glueContext.create_dynamic_frame.from_catalog(database = database_name, table_name = doctorbehaviorrecords_table_name, transformation_ctx = "doctorbehaviorrecords_datasource")
    
    
    doctorbehaviorrecords_repartitionDF = doctorbehaviorrecords_datasource.toDF()
    
    
    ## Merge all partition file into one csv and change type from dynamic frame to spark dataframe
    doctorbehaviorrecords_repartitionDF = doctorbehaviorrecords_repartitionDF.coalesce(1)
    
    ## scientific notation cloumn with long type 20210701
    
    print ("------doctorbehaviorrecords Count:  ", doctorbehaviorrecords_repartitionDF.count())
    print(doctorbehaviorrecords_repartitionDF)
    doctorbehaviorrecords_repartitionDF.write.format('csv').mode("overwrite").save("s3://" + BucketName + "/" + doctorbehaviorrecords_ProcessDir,sep=",",header='true')
    print("------Load doctorbehaviorrecords to S3 folder: {} successfully.".format(doctorbehaviorrecords_ProcessDir))
    
    
    
    ## ------------------------------ doctorbehaviorrecords S3 Processing Logic ------------------------------------
    import boto3
    client = boto3.client('s3')
    
    doctorbehaviorrecords_Response = client.list_objects(
        Bucket=BucketName,
        Prefix=doctorbehaviorrecords_ProcessDir,
    )
    
    
    doctorbehaviorrecords__process_file_absolutely_s3_path = doctorbehaviorrecords_Response["Contents"][0]["Key"]
    
    
    print("------doctorbehaviorrecords__process_file_absolutely_s3_path: ",doctorbehaviorrecords__process_file_absolutely_s3_path)
    doctorbehaviorrecords_copy_source = {'Bucket': BucketName, 'Key': doctorbehaviorrecords__process_file_absolutely_s3_path}
    print("------doctorbehaviorrecords_copy_source: ",doctorbehaviorrecords_copy_source)
    
    
    print(doctorbehaviorrecords_DestinationDir)
    
    client.copy(CopySource=doctorbehaviorrecords_copy_source, Bucket=BucketName, Key=doctorbehaviorrecords_DestinationDir)
    print("------File moving from doctorbehaviorrecords process folder to desitination folder done.")
    
    ## Delete folder in S3
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(BucketName)
    bucket.objects.filter(Prefix=doctorbehaviorrecords_ProcessDir).delete()
    print("------Delete S3 doctorbehaviorrecords process folder: {} done.".format(doctorbehaviorrecords_ProcessDir))
    
    ## Copy flag file and rename it
    doctorbehaviorrecords_CopyFlagFileDict = {'Bucket': BucketName, 'Key': FlagFileS3Path}
    print("------doctorbehaviorrecords_CopyFlagFileDict: ",doctorbehaviorrecords_CopyFlagFileDict)
    
    client.copy(CopySource=doctorbehaviorrecords_CopyFlagFileDict, Bucket=BucketName, Key=doctorbehaviorrecords_RdyFilePath)
    print("------Move doctorbehaviorrecords rdy file to S3 path: {} done.".format(doctorbehaviorrecords_RdyFilePath))
    
    
    job.commit()

except Exception as e:
    print(e)
    raise e
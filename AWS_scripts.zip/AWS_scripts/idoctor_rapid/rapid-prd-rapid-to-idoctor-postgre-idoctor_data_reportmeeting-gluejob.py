﻿import sys
from contextlib import closing
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
import pyspark.sql.functions as F
from pyspark.sql.functions import col

try:
    # Parameter which should be changed and checked before deployment
    glue_catalog_database_name = "rapid-prd-catalog-gluedatabase"
    
    ## @params: [JOB_NAME]
    args = getResolvedOptions(sys.argv, ['JOB_NAME','bucket','parent_folder'])
    #args = getResolvedOptions(sys.argv, ['JOB_NAME'])
    
    wrcBucketName = args['bucket']
    #wrcBucketName = "lly-cn-ibu-rapid-idoctor-prd-private"
    print(wrcBucketName)
    folder = args['parent_folder']
    #folder = "RapidTo/idoctor_data_reportmeeting/2021-06-23"
    print(folder)
    #最终的数据库目标表名
    postgresql_destination_table_idoctor_data_reportmeeting = "dbo.idoctor_data_reportmeeting"
    #CSV表结构的表名
    glue_postgre_table_idoctor_data_reportmeeting = "rapid_prd_idoctor_data_reportmeeting_csv"
    
    wrc_process_bucket = 'lly-cn-ibu-rapid-idoctor-prd-private'
    wrc_process_folder = 'rapid-glue-process-wrc-to-postgresql/'
    
    
    print("------ RAPID to Wechat Rep Customer360 Job: {} Start ...".format(args['JOB_NAME']))

    import boto3
    client = boto3.client('s3')
    
    file_name_idoctor_data_reportmeeting = 'idoctor_data_reportmeeting.csv'
    
    response = client.delete_objects(
        Bucket=wrc_process_bucket,
        Delete={
            'Objects': [
                {
                    'Key': wrc_process_folder + file_name_idoctor_data_reportmeeting
                },
            ],
            'Quiet': True
        }
    )
    
    print(response)
    
    file_idoctor_data_reportmeeting = folder + "/" + file_name_idoctor_data_reportmeeting
    print(file_idoctor_data_reportmeeting)
    
    idoctor_data_reportmeeting_copy_source = {'Bucket': wrcBucketName, 'Key': file_idoctor_data_reportmeeting}
    
    print(idoctor_data_reportmeeting_copy_source)
    
    client.copy(CopySource=idoctor_data_reportmeeting_copy_source, Bucket=wrc_process_bucket, Key=wrc_process_folder+file_name_idoctor_data_reportmeeting)
    print("----------------------------File: {} moving to process folder done.".format(file_name_idoctor_data_reportmeeting))
    
    sc = SparkContext()
    glueContext = GlueContext(sc)
    spark = glueContext.spark_session
    job = Job(glueContext)
    job.init(args['JOB_NAME'], args)
    #从此处开始替换成Glue job自动生成的脚本，即CSV每一列跟目标表每一列的对应关系
    ## @type: DataSource
    ## @args: [database = "rapid-prd-catalog-gluedatabase", table_name = "rapid_prd_idoctor_data_reportmeeting_csv", transformation_ctx = "datasource0"]
    ## @return: datasource0
    ## @inputs: []
    datasource0 = glueContext.create_dynamic_frame.from_catalog(database = "rapid-prd-catalog-gluedatabase", table_name = "rapid_prd_idoctor_data_reportmeeting_csv", transformation_ctx = "datasource0")
    ## @type: ApplyMapping
    ## @args: [mapping = [("dctrid", "long", "dctrid", "decimal(19,0)"), ("speakercount", "long", "speakercount", "int"), ("notspeakercount", "long", "notspeakercount", "int"), ("type", "long", "type", "int"), ("month", "long", "month", "int"), ("year", "long", "year", "int"), ("versionnumber", "long", "versionnumber", "int"), ("isdeleted", "long", "isdeleted", "boolean"), ("ownerid", "long", "ownerid", "int"), ("createdutc", "string", "createdutc", "timestamp"), ("modifiedid", "long", "modifiedid", "int"), ("modifiedutc", "string", "modifiedutc", "timestamp")], transformation_ctx = "applymapping1"]
    ## @return: applymapping1
    ## @inputs: [frame = datasource0]
    applymapping1 = ApplyMapping.apply(frame = datasource0, mappings = [("dctrid", "long", "dctrid", "decimal(19,0)"), ("speakercount", "long", "speakercount", "int"), ("notspeakercount", "long", "notspeakercount", "int"), ("type", "long", "type", "int"), ("month", "long", "month", "int"), ("year", "long", "year", "int"), ("versionnumber", "long", "versionnumber", "int"), ("isdeleted", "long", "isdeleted", "boolean"), ("ownerid", "long", "ownerid", "int"), ("createdutc", "timestamp", "createdutc", "timestamp"), ("modifiedid", "long", "modifiedid", "int"), ("modifiedutc", "timestamp", "modifiedutc", "timestamp")], transformation_ctx = "applymapping1")
    ## @type: SelectFields
    ## @args: [paths = ["year", "versionnumber", "type", "ownerid", "isdeleted", "modifiedutc", "notspeakercount", "month", "dctrid", "speakercount", "id", "modifiedid", "createdutc"], transformation_ctx = "selectfields2"]
    ## @return: selectfields2
    ## @inputs: [frame = applymapping1]
    selectfields2 = SelectFields.apply(frame = applymapping1, paths = ["year", "versionnumber", "type", "ownerid", "isdeleted", "modifiedutc", "notspeakercount", "month", "dctrid", "speakercount", "id", "modifiedid", "createdutc"], transformation_ctx = "selectfields2")
    ## @type: ResolveChoice
    ## @args: [choice = "MATCH_CATALOG", database = "rapid-prd-catalog-gluedatabase", table_name = "rapid_prd_idoctorprd_dbo_idoctor_data_reportmeeting", transformation_ctx = "resolvechoice3"]
    ## @return: resolvechoice3
    ## @inputs: [frame = selectfields2]
    resolvechoice3 = ResolveChoice.apply(frame = selectfields2, choice = "MATCH_CATALOG", database = "rapid-prd-catalog-gluedatabase", table_name = "rapid_prd_idoctorprd_dbo_idoctor_data_reportmeeting", transformation_ctx = "resolvechoice3")
    ## @type: ResolveChoice
    ## @args: [choice = "make_cols", transformation_ctx = "resolvechoice4"]
    ## @return: resolvechoice4
    ## @inputs: [frame = resolvechoice3]
    resolvechoice4 = ResolveChoice.apply(frame = resolvechoice3, choice = "make_cols", transformation_ctx = "resolvechoice4")
    ## @type: DataSink
    ## @args: [database = "rapid-prd-catalog-gluedatabase", table_name = "rapid_prd_idoctorprd_dbo_idoctor_data_reportmeeting", transformation_ctx = "datasink5"]
    ## @return: datasink5
    ## @inputs: [frame = resolvechoice4]
    #从此处结束替换成Glue job自动生成的脚本，即CSV每一列跟目标表每一列的对应关系 
    print("----------idoctor_data_reportmeeting count: {}".format(resolvechoice4.count()))
    #去空值
    Loading1= DropNullFields.apply(frame = resolvechoice4, transformation_ctx = "Loading1")
    idoctor_data_reportmeeting_df = Loading1.toDF()
    #print(idoctor_data_reportmeeting_df.show())
    idoctor_data_reportmeeting_df = idoctor_data_reportmeeting_df.withColumn("createdutc", F.unix_timestamp("createdutc", 'MM/dd/yyyy HH:mm:ss').cast("timestamp")) \
    .withColumn("modifiedutc", F.unix_timestamp("modifiedutc", 'MM/dd/yyyy HH:mm:ss').cast("timestamp"))
    #print(idoctor_data_reportmeeting_df.show())
    #idoctor_data_reportmeeting_df.show()
    
    conn = glueContext.extract_jdbc_conf('rapid-prd-idoctor-connreader-writer')
    #print("----------conn:",conn)
    url = conn['url']
    #print("----------url",url)
    USERNAME = conn['user']
    #print("----------username:",USERNAME)
    PASSWORD = conn['password']
    DATABASE = "idoctorprd"
    #print("----------database:",DATABASE)
    URL = url+"/"+DATABASE
    #print(URL)
    DRIVER = "org.postgresql.Driver"
    
    idoctor_data_reportmeeting_df.write \
        .format("jdbc") \
        .option("driver",DRIVER) \
        .option("url", URL) \
        .option("dbtable", postgresql_destination_table_idoctor_data_reportmeeting) \
        .option("user", USERNAME) \
        .option("password", PASSWORD) \
        .option("truncate","true") \
        .option("ssl","true") \
        .mode("overwrite") \
        .save()
    
    print('--------------Load all the data into table {} done.'.format(postgresql_destination_table_idoctor_data_reportmeeting))
    
    job.commit()

except Exception as e:
    print(e)
    raise e

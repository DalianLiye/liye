﻿import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from datetime import date, timedelta
import time
import datetime

try:
    current_date =  time.strftime('%Y-%m-%d',time.localtime(time.time()))
    print("Current Date is: {}".format(current_date))

    BucketName = 'lly-cn-ibu-rapid-idoctor-prd-private'
    RootFolderName = 'ToRAPID/idoctor_data_meetingdetail'

    idoctor_data_meetingdetail_ProcessDir = RootFolderName + '/'+ current_date +'/process'

    idoctor_data_meetingdetail_DestinationDir = RootFolderName + '/'+ current_date +'/idoctor_data_meetingdetail.csv'

    FlagFileS3Path = 'rapid-flag-file/done.rdy'

    idoctor_data_meetingdetail_RdyFilePath = RootFolderName + '/'+ current_date +'/idoctor_data_meetingdetail.rdy'

    database_name = "rapid-prd-catalog-gluedatabase"
    idoctor_data_meetingdetail_table_name = "rapid_prd_idoctorprd_dbo_idoctor_data_meetingdetail"

    ## @params: [JOB_NAME]
    args = getResolvedOptions(sys.argv, ['JOB_NAME'])

    sc = SparkContext()
    glueContext = GlueContext(sc)
    spark = glueContext.spark_session
    job = Job(glueContext)
    job.init(args['JOB_NAME'], args)

    ## idoctor_data_meetingdetail table
    idoctor_data_meetingdetail_datasource = glueContext.create_dynamic_frame.from_catalog(database = database_name, table_name = idoctor_data_meetingdetail_table_name, transformation_ctx = "idoctor_data_meetingdetail_datasource")
    idoctor_data_meetingdetail_repartitionDF = idoctor_data_meetingdetail_datasource.toDF()    
    ##user sql 
    idoctor_data_meetingdetail_repartitionDF.createOrReplaceTempView("idoctor_data_meetingdetail")
    idoctor_data_meetingdetail_query = "select  id,unq_nbr,'' as summary,replace(replace(body,chr(10),''),chr(13),'') as body, \
                                        starttime,endtime,location,surveyurl,bgindex,isdeleted,displaystatus,ownerid,createdutc,modifiedid,modifiedutc,surveyname,surveyicon,'' as speakerinfo, \
                                        ep2pname,ep2purl,isep2p,ibeaconid,ibeacontoken,isibeaconenabled,pollurl,qaurl,template_id,templateid,kvurl,wechatnews,participantnumber,speakerep2purl,screenshot, \
		                                participanturl,onlinelink,isonlinemeetingplatform,meetingstartdatetime,meetingenddatetime,isuploadposter,pushalertstatus,issendtemplate,meetingcode \
		                                from idoctor_data_meetingdetail"
    print(idoctor_data_meetingdetail_query)
    idoctor_data_meetingdetail_repartitionDF = spark.sql(idoctor_data_meetingdetail_query)
    #idoctor_data_meetingdetail_repartitionDF.show()
    
    ## Merge all partition file into one csv and change type from dynamic frame to spark dataframe
    idoctor_data_meetingdetail_repartitionDF = idoctor_data_meetingdetail_repartitionDF.coalesce(1)
    print ("idoctor_data_meetingdetail Count:  ", idoctor_data_meetingdetail_repartitionDF.count())
    print(idoctor_data_meetingdetail_repartitionDF)
    idoctor_data_meetingdetail_repartitionDF.write.format('csv').mode("overwrite").save("s3://" + BucketName + "/" + idoctor_data_meetingdetail_ProcessDir,sep=",",header='true')
    print("Load idoctor_data_meetingdetail to S3 folder: {} successfully.".format(idoctor_data_meetingdetail_ProcessDir))

    ## ------------------------------ idoctor_data_meetingdetail S3 Processing Logic ------------------------------------
    import boto3
    client = boto3.client('s3')

    idoctor_data_meetingdetail_Response = client.list_objects(
        Bucket=BucketName,
        Prefix=idoctor_data_meetingdetail_ProcessDir,
    )

    idoctor_data_meetingdetail_process_file_absolutely_s3_path = idoctor_data_meetingdetail_Response["Contents"][0]["Key"]

    print("idoctor_data_meetingdetail_process_file_absolutely_s3_path: ",idoctor_data_meetingdetail_process_file_absolutely_s3_path)
    idoctor_data_meetingdetail_copy_source = {'Bucket': BucketName, 'Key': idoctor_data_meetingdetail_process_file_absolutely_s3_path}
    print("idoctor_data_meetingdetail_copy_source: ",idoctor_data_meetingdetail_copy_source)

    print(idoctor_data_meetingdetail_DestinationDir)

    client.copy(CopySource=idoctor_data_meetingdetail_copy_source, Bucket=BucketName, Key=idoctor_data_meetingdetail_DestinationDir)
    print("File moving from idoctor_data_meetingdetail process folder to desitination folder done.")

    ## Delete folder in S3
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(BucketName)
    bucket.objects.filter(Prefix=idoctor_data_meetingdetail_ProcessDir).delete()
    print("Delete S3 idoctor_data_meetingdetail process folder: {} done.".format(idoctor_data_meetingdetail_ProcessDir))

    ## Copy flag file and rename it
    idoctor_data_meetingdetail_CopyFlagFileDict = {'Bucket': BucketName, 'Key': FlagFileS3Path}
    print("idoctor_data_meetingdetail_CopyFlagFileDict: ",idoctor_data_meetingdetail_CopyFlagFileDict)

    client.copy(CopySource=idoctor_data_meetingdetail_CopyFlagFileDict, Bucket=BucketName, Key=idoctor_data_meetingdetail_RdyFilePath)
    print("Move idoctor_data_meetingdetail rdy file to S3 path: {} done.".format(idoctor_data_meetingdetail_RdyFilePath))

    job.commit()

except Exception as e:
    print(e)
    raise e

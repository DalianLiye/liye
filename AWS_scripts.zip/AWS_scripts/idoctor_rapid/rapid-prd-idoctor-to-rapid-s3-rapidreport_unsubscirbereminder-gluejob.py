import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from datetime import date, timedelta
import time
import datetime

try:
    current_date =  time.strftime('%Y-%m-%d',time.localtime(time.time()))
    print("------Current Date is: {}".format(current_date))
    
    BucketName = 'lly-cn-ibu-rapid-idoctor-prd-private'
    RootFolderName = 'ToRAPID/rapidreport_unsubscirbereminder'
    
    rapidreport_unsubscirbereminder_ProcessDir = RootFolderName + '/'+ current_date +'/process'
    
    
    rapidreport_unsubscirbereminder_DestinationDir = RootFolderName + '/'+ current_date +'/rapidreport_unsubscirbereminder.csv'
    
    FlagFileS3Path = 'rapid-flag-file/done.rdy'
    
    rapidreport_unsubscirbereminder_RdyFilePath = RootFolderName + '/'+ current_date +'/rapidreport_unsubscirbereminder.rdy'
    
    
    database_name = "rapid-prd-catalog-gluedatabase"
    rapidreport_unsubscirbereminder_table_name = "rapid_prd_idoctorprd_dbo_rapidreport_unsubscirbereminder"
    
    
    
    ## @params: [JOB_NAME]
    args = getResolvedOptions(sys.argv, ['JOB_NAME'])
    
    sc = SparkContext()
    glueContext = GlueContext(sc)
    spark = glueContext.spark_session
    job = Job(glueContext)
    job.init(args['JOB_NAME'], args)
    
    
    ## rapidreport_unsubscirbereminder table
    rapidreport_unsubscirbereminder_datasource = glueContext.create_dynamic_frame.from_catalog(database = database_name, table_name = rapidreport_unsubscirbereminder_table_name, transformation_ctx = "rapidreport_unsubscirbereminder_datasource")
    
    
    rapidreport_unsubscirbereminder_repartitionDF = rapidreport_unsubscirbereminder_datasource.toDF()
    
    
    ## Merge all partition file into one csv and change type from dynamic frame to spark dataframe
    rapidreport_unsubscirbereminder_repartitionDF = rapidreport_unsubscirbereminder_repartitionDF.coalesce(1)
    
    
    print ("------rapidreport_unsubscirbereminder Count:  ", rapidreport_unsubscirbereminder_repartitionDF.count())
    print(rapidreport_unsubscirbereminder_repartitionDF)
    rapidreport_unsubscirbereminder_repartitionDF.write.format('csv').mode("overwrite").save("s3://" + BucketName + "/" + rapidreport_unsubscirbereminder_ProcessDir,sep=",",header='true')
    print("------Load rapidreport_unsubscirbereminder to S3 folder: {} successfully.".format(rapidreport_unsubscirbereminder_ProcessDir))
    
    
    
    ## ------------------------------ rapidreport_unsubscirbereminder S3 Processing Logic ------------------------------------
    import boto3
    client = boto3.client('s3')
    
    rapidreport_unsubscirbereminder_Response = client.list_objects(
        Bucket=BucketName,
        Prefix=rapidreport_unsubscirbereminder_ProcessDir,
    )
    
    
    rapidreport_unsubscirbereminder__process_file_absolutely_s3_path = rapidreport_unsubscirbereminder_Response["Contents"][0]["Key"]
    
    
    print("------rapidreport_unsubscirbereminder__process_file_absolutely_s3_path: ",rapidreport_unsubscirbereminder__process_file_absolutely_s3_path)
    rapidreport_unsubscirbereminder_copy_source = {'Bucket': BucketName, 'Key': rapidreport_unsubscirbereminder__process_file_absolutely_s3_path}
    print("------rapidreport_unsubscirbereminder_copy_source: ",rapidreport_unsubscirbereminder_copy_source)
    
    
    print(rapidreport_unsubscirbereminder_DestinationDir)
    
    client.copy(CopySource=rapidreport_unsubscirbereminder_copy_source, Bucket=BucketName, Key=rapidreport_unsubscirbereminder_DestinationDir)
    print("------File moving from rapidreport_unsubscirbereminder process folder to desitination folder done.")
    
    ## Delete folder in S3
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(BucketName)
    bucket.objects.filter(Prefix=rapidreport_unsubscirbereminder_ProcessDir).delete()
    print("------Delete S3 rapidreport_unsubscirbereminder process folder: {} done.".format(rapidreport_unsubscirbereminder_ProcessDir))
    
    ## Copy flag file and rename it
    rapidreport_unsubscirbereminder_CopyFlagFileDict = {'Bucket': BucketName, 'Key': FlagFileS3Path}
    print("------rapidreport_unsubscirbereminder_CopyFlagFileDict: ",rapidreport_unsubscirbereminder_CopyFlagFileDict)
    
    client.copy(CopySource=rapidreport_unsubscirbereminder_CopyFlagFileDict, Bucket=BucketName, Key=rapidreport_unsubscirbereminder_RdyFilePath)
    print("------Move rapidreport_unsubscirbereminder rdy file to S3 path: {} done.".format(rapidreport_unsubscirbereminder_RdyFilePath))
    
    
    job.commit()

except Exception as e:
    print(e)
    raise e
import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from datetime import date, timedelta
import time
import datetime

try:
    current_date =  time.strftime('%Y-%m-%d',time.localtime(time.time()))
    print("------Current Date is: {}".format(current_date))
    
    BucketName = 'lly-cn-ibu-rapid-idoctor-prd-private'
    RootFolderName = 'ToRAPID/rapidreport_meetingsolutionanwser'
    
    rapidreport_meetingsolutionanwser_ProcessDir = RootFolderName + '/'+ current_date +'/process'
    
    
    rapidreport_meetingsolutionanwser_DestinationDir = RootFolderName + '/'+ current_date +'/rapidreport_meetingsolutionanwser.csv'
    
    FlagFileS3Path = 'rapid-flag-file/done.rdy'
    
    rapidreport_meetingsolutionanwser_RdyFilePath = RootFolderName + '/'+ current_date +'/rapidreport_meetingsolutionanwser.rdy'
    
    
    database_name = "rapid-prd-catalog-gluedatabase"
    rapidreport_meetingsolutionanwser_table_name = "rapid_prd_idoctorprd_dbo_rapidreport_meetingsolutionanwser"
    
    
    
    ## @params: [JOB_NAME]
    args = getResolvedOptions(sys.argv, ['JOB_NAME'])
    
    sc = SparkContext()
    glueContext = GlueContext(sc)
    spark = glueContext.spark_session
    job = Job(glueContext)
    job.init(args['JOB_NAME'], args)
    
    
    ## rapidreport_meetingsolutionanwser table
    rapidreport_meetingsolutionanwser_datasource = glueContext.create_dynamic_frame.from_catalog(database = database_name, table_name = rapidreport_meetingsolutionanwser_table_name, transformation_ctx = "rapidreport_meetingsolutionanwser_datasource")
    
    
    rapidreport_meetingsolutionanwser_repartitionDF = rapidreport_meetingsolutionanwser_datasource.toDF()
    
    
    ## Merge all partition file into one csv and change type from dynamic frame to spark dataframe
    rapidreport_meetingsolutionanwser_repartitionDF = rapidreport_meetingsolutionanwser_repartitionDF.coalesce(1)
    
    
    print ("------rapidreport_meetingsolutionanwser Count:  ", rapidreport_meetingsolutionanwser_repartitionDF.count())
    print(rapidreport_meetingsolutionanwser_repartitionDF)
    rapidreport_meetingsolutionanwser_repartitionDF.write.format('csv').mode("overwrite").save("s3://" + BucketName + "/" + rapidreport_meetingsolutionanwser_ProcessDir,sep=",",header='true')
    print("------Load rapidreport_meetingsolutionanwser to S3 folder: {} successfully.".format(rapidreport_meetingsolutionanwser_ProcessDir))
    
    
    
    ## ------------------------------ rapidreport_meetingsolutionanwser S3 Processing Logic ------------------------------------
    import boto3
    client = boto3.client('s3')
    
    rapidreport_meetingsolutionanwser_Response = client.list_objects(
        Bucket=BucketName,
        Prefix=rapidreport_meetingsolutionanwser_ProcessDir,
    )
    
    
    rapidreport_meetingsolutionanwser__process_file_absolutely_s3_path = rapidreport_meetingsolutionanwser_Response["Contents"][0]["Key"]
    
    
    print("------rapidreport_meetingsolutionanwser__process_file_absolutely_s3_path: ",rapidreport_meetingsolutionanwser__process_file_absolutely_s3_path)
    rapidreport_meetingsolutionanwser_copy_source = {'Bucket': BucketName, 'Key': rapidreport_meetingsolutionanwser__process_file_absolutely_s3_path}
    print("------rapidreport_meetingsolutionanwser_copy_source: ",rapidreport_meetingsolutionanwser_copy_source)
    
    
    print(rapidreport_meetingsolutionanwser_DestinationDir)
    
    client.copy(CopySource=rapidreport_meetingsolutionanwser_copy_source, Bucket=BucketName, Key=rapidreport_meetingsolutionanwser_DestinationDir)
    print("------File moving from rapidreport_meetingsolutionanwser process folder to desitination folder done.")
    
    ## Delete folder in S3
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(BucketName)
    bucket.objects.filter(Prefix=rapidreport_meetingsolutionanwser_ProcessDir).delete()
    print("------Delete S3 rapidreport_meetingsolutionanwser process folder: {} done.".format(rapidreport_meetingsolutionanwser_ProcessDir))
    
    ## Copy flag file and rename it
    rapidreport_meetingsolutionanwser_CopyFlagFileDict = {'Bucket': BucketName, 'Key': FlagFileS3Path}
    print("------rapidreport_meetingsolutionanwser_CopyFlagFileDict: ",rapidreport_meetingsolutionanwser_CopyFlagFileDict)
    
    client.copy(CopySource=rapidreport_meetingsolutionanwser_CopyFlagFileDict, Bucket=BucketName, Key=rapidreport_meetingsolutionanwser_RdyFilePath)
    print("------Move rapidreport_meetingsolutionanwser rdy file to S3 path: {} done.".format(rapidreport_meetingsolutionanwser_RdyFilePath))
    
    
    job.commit()

except Exception as e:
    print(e)
    raise e
import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from datetime import date, timedelta
import time
import datetime

try:
    current_date =  time.strftime('%Y-%m-%d',time.localtime(time.time()))
    print("------Current Date is: {}".format(current_date))
    
    BucketName = 'lly-cn-ibu-rapid-idoctor-prd-private'
    RootFolderName = 'ToRAPID/rapidreport_doctortouchpoint'
    
    rapidreport_doctortouchpoint_ProcessDir = RootFolderName + '/'+ current_date +'/process'
    
    
    rapidreport_doctortouchpoint_DestinationDir = RootFolderName + '/'+ current_date +'/rapidreport_doctortouchpoint.csv'
    
    FlagFileS3Path = 'rapid-flag-file/done.rdy'
    
    rapidreport_doctortouchpoint_RdyFilePath = RootFolderName + '/'+ current_date +'/rapidreport_doctortouchpoint.rdy'
    
    
    database_name = "rapid-prd-catalog-gluedatabase"
    rapidreport_doctortouchpoint_table_name = "rapid_prd_idoctorprd_dbo_rapidreport_doctortouchpoint"
    
    
    
    ## @params: [JOB_NAME]
    args = getResolvedOptions(sys.argv, ['JOB_NAME'])
    
    sc = SparkContext()
    glueContext = GlueContext(sc)
    spark = glueContext.spark_session
    job = Job(glueContext)
    job.init(args['JOB_NAME'], args)
    
    
    ## rapidreport_doctortouchpoint table
    rapidreport_doctortouchpoint_datasource = glueContext.create_dynamic_frame.from_catalog(database = database_name, table_name = rapidreport_doctortouchpoint_table_name, transformation_ctx = "rapidreport_doctortouchpoint_datasource")
    
    
    rapidreport_doctortouchpoint_repartitionDF = rapidreport_doctortouchpoint_datasource.toDF()
    
    
    ## Merge all partition file into one csv and change type from dynamic frame to spark dataframe
    rapidreport_doctortouchpoint_repartitionDF = rapidreport_doctortouchpoint_repartitionDF.coalesce(1)
    
    
    print ("------rapidreport_doctortouchpoint Count:  ", rapidreport_doctortouchpoint_repartitionDF.count())
    print(rapidreport_doctortouchpoint_repartitionDF)
    rapidreport_doctortouchpoint_repartitionDF.write.format('csv').mode("overwrite").save("s3://" + BucketName + "/" + rapidreport_doctortouchpoint_ProcessDir,sep=",",header='true')
    print("------Load rapidreport_doctortouchpoint to S3 folder: {} successfully.".format(rapidreport_doctortouchpoint_ProcessDir))
    
    
    
    ## ------------------------------ rapidreport_doctortouchpoint S3 Processing Logic ------------------------------------
    import boto3
    client = boto3.client('s3')
    
    rapidreport_doctortouchpoint_Response = client.list_objects(
        Bucket=BucketName,
        Prefix=rapidreport_doctortouchpoint_ProcessDir,
    )
    
    
    rapidreport_doctortouchpoint__process_file_absolutely_s3_path = rapidreport_doctortouchpoint_Response["Contents"][0]["Key"]
    
    
    print("------rapidreport_doctortouchpoint__process_file_absolutely_s3_path: ",rapidreport_doctortouchpoint__process_file_absolutely_s3_path)
    rapidreport_doctortouchpoint_copy_source = {'Bucket': BucketName, 'Key': rapidreport_doctortouchpoint__process_file_absolutely_s3_path}
    print("------rapidreport_doctortouchpoint_copy_source: ",rapidreport_doctortouchpoint_copy_source)
    
    
    print(rapidreport_doctortouchpoint_DestinationDir)
    
    client.copy(CopySource=rapidreport_doctortouchpoint_copy_source, Bucket=BucketName, Key=rapidreport_doctortouchpoint_DestinationDir)
    print("------File moving from rapidreport_doctortouchpoint process folder to desitination folder done.")
    
    ## Delete folder in S3
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(BucketName)
    bucket.objects.filter(Prefix=rapidreport_doctortouchpoint_ProcessDir).delete()
    print("------Delete S3 rapidreport_doctortouchpoint process folder: {} done.".format(rapidreport_doctortouchpoint_ProcessDir))
    
    ## Copy flag file and rename it
    rapidreport_doctortouchpoint_CopyFlagFileDict = {'Bucket': BucketName, 'Key': FlagFileS3Path}
    print("------rapidreport_doctortouchpoint_CopyFlagFileDict: ",rapidreport_doctortouchpoint_CopyFlagFileDict)
    
    client.copy(CopySource=rapidreport_doctortouchpoint_CopyFlagFileDict, Bucket=BucketName, Key=rapidreport_doctortouchpoint_RdyFilePath)
    print("------Move rapidreport_doctortouchpoint rdy file to S3 path: {} done.".format(rapidreport_doctortouchpoint_RdyFilePath))
    
    
    job.commit()

except Exception as e:
    print(e)
    raise e
import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.types import StringType
from pyspark.sql.functions import UserDefinedFunction
from datetime import date, timedelta
import time
import datetime
import pyspark.sql.functions as F
import pyspark.sql.types as T

try:
    current_date =  time.strftime('%Y-%m-%d',time.localtime(time.time()))
    print("------Current Date is: {}".format(current_date))
    
    BucketName = 'lly-cn-ibu-rapid-idoctor-prd-private'
    RootFolderName = 'ToRAPID/wechatmpuser'
    
    wechatmpuser_ProcessDir = RootFolderName + '/'+ current_date +'/process'
    
    
    wechatmpuser_DestinationDir = RootFolderName + '/'+ current_date +'/wechatmpuser.csv'
    
    FlagFileS3Path = 'rapid-flag-file/done.rdy'
    
    wechatmpuser_RdyFilePath = RootFolderName + '/'+ current_date +'/wechatmpuser.rdy'
    
    
    database_name = "rapid-prd-catalog-gluedatabase"
    wechatmpuser_table_name = "rapid_prd_idoctorprd_dbo_wechatmpuser"
    
    
    
    ## @params: [JOB_NAME]
    args = getResolvedOptions(sys.argv, ['JOB_NAME'])
    
    sc = SparkContext()
    glueContext = GlueContext(sc)
    spark = glueContext.spark_session
    job = Job(glueContext)
    job.init(args['JOB_NAME'], args)
    
    
    ## wechatmpuser table
    wechatmpuser_datasource = glueContext.create_dynamic_frame.from_catalog(database = database_name, table_name = wechatmpuser_table_name, transformation_ctx = "wechatmpuser_datasource")
    
    
    wechatmpuser_repartitionDF = wechatmpuser_datasource.toDF()
	
    #new added for certain columns set to null values 20210901 daming start
    #Define a function to set null values
    to_none = UserDefinedFunction(lambda x: None, StringType())
    #specify columns set to null value by withColumn function
    wechatmpuser_repartitionDF = wechatmpuser_repartitionDF.withColumn('nickname', to_none(wechatmpuser_repartitionDF['nickname']))\
    .withColumn('hospital', to_none(wechatmpuser_repartitionDF['hospital']))
    #\.withColumn('given_name', to_none(wechatmpuser_repartitionDF['given_name']))
    #wechatmpuser_repartitionDF = wechatmpuser_repartitionDF.withColumn('family_name', replace(col('family_name'), '')) \
    #.withColumn('given_name', replace(col('given_name'), ''))
    #wechatmpuser_repartitionDF.show()
    #new added for certain columns set to null values 20210901 daming end
    
    
    ## Merge all partition file into one csv and change type from dynamic frame to spark dataframe
    wechatmpuser_repartitionDF = wechatmpuser_repartitionDF.coalesce(1)
    
    ## scientific notation cloumn with long type 20210701
    wechatmpuser_repartitionDF = wechatmpuser_repartitionDF.withColumn("dctrid",  F.col("dctrid").cast(T.LongType()))
    
    print ("------wechatmpuser Count:  ", wechatmpuser_repartitionDF.count())
    print(wechatmpuser_repartitionDF)
    wechatmpuser_repartitionDF.write.format('csv').mode("overwrite").save("s3://" + BucketName + "/" + wechatmpuser_ProcessDir,sep=",",header='true')
    print("------Load wechatmpuser to S3 folder: {} successfully.".format(wechatmpuser_ProcessDir))
    
    
    
    ## ------------------------------ wechatmpuser S3 Processing Logic ------------------------------------
    import boto3
    client = boto3.client('s3')
    
    wechatmpuser_Response = client.list_objects(
        Bucket=BucketName,
        Prefix=wechatmpuser_ProcessDir,
    )
    
    
    wechatmpuser__process_file_absolutely_s3_path = wechatmpuser_Response["Contents"][0]["Key"]
    
    
    print("------wechatmpuser__process_file_absolutely_s3_path: ",wechatmpuser__process_file_absolutely_s3_path)
    wechatmpuser_copy_source = {'Bucket': BucketName, 'Key': wechatmpuser__process_file_absolutely_s3_path}
    print("------wechatmpuser_copy_source: ",wechatmpuser_copy_source)
    
    
    print(wechatmpuser_DestinationDir)
    
    client.copy(CopySource=wechatmpuser_copy_source, Bucket=BucketName, Key=wechatmpuser_DestinationDir)
    print("------File moving from wechatmpuser process folder to desitination folder done.")
    
    ## Delete folder in S3
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(BucketName)
    bucket.objects.filter(Prefix=wechatmpuser_ProcessDir).delete()
    print("------Delete S3 wechatmpuser process folder: {} done.".format(wechatmpuser_ProcessDir))
    
    ## Copy flag file and rename it
    wechatmpuser_CopyFlagFileDict = {'Bucket': BucketName, 'Key': FlagFileS3Path}
    print("------wechatmpuser_CopyFlagFileDict: ",wechatmpuser_CopyFlagFileDict)
    
    client.copy(CopySource=wechatmpuser_CopyFlagFileDict, Bucket=BucketName, Key=wechatmpuser_RdyFilePath)
    print("------Move wechatmpuser rdy file to S3 path: {} done.".format(wechatmpuser_RdyFilePath))
    
    
    job.commit()

except Exception as e:
    print(e)
    raise e
import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
import pyspark.sql.functions as F
from pyspark.sql.functions import col

try:
    # Parameter which should be changed and checked before deployment
    glue_catalog_database_name = "rapid-prd-catalog-gluedatabase"
    
    ## @params: [JOB_NAME]
    args = getResolvedOptions(sys.argv, ['JOB_NAME','bucket','parent_folder'])
    #args = getResolvedOptions(sys.argv, ['JOB_NAME'])
    
    wrcBucketName = args['bucket']
    #wrcBucketName = "lly-cn-ibu-rapid-idoctor-prd-private"
    print(wrcBucketName)
    folder = args['parent_folder']
    #folder = "RapidTo/idoctor_data_articlerank/2021-06-25"
    print(folder)
    #最终的数据库目标表名
    postgresql_destination_table_idoctor_data_articlerank = "dbo.idoctor_data_articlerank"
    #CSV表结构的表名
    glue_postgre_table_idoctor_data_articlerank = "rapid_prd_idoctor_data_articlerank_csv"
    
    wrc_process_bucket = 'lly-cn-ibu-rapid-idoctor-prd-private'
    wrc_process_folder = 'rapid-glue-process-wrc-to-postgresql/'
    
    
    print("------ RAPID to Wechat Rep Customer360 Job: {} Start ...".format(args['JOB_NAME']))

    import boto3
    client = boto3.client('s3')
    
    file_name_idoctor_data_articlerank = 'idoctor_data_articlerank.csv'
    
    response = client.delete_objects(
        Bucket=wrc_process_bucket,
        Delete={
            'Objects': [
                {
                    'Key': wrc_process_folder + file_name_idoctor_data_articlerank
                },
            ],
            'Quiet': True
        }
    )
    
    print(response)
    
    file_idoctor_data_articlerank = folder + "/" + file_name_idoctor_data_articlerank
    print(file_idoctor_data_articlerank)
    
    idoctor_data_articlerank_copy_source = {'Bucket': wrcBucketName, 'Key': file_idoctor_data_articlerank}
    
    print(idoctor_data_articlerank_copy_source)
    
    client.copy(CopySource=idoctor_data_articlerank_copy_source, Bucket=wrc_process_bucket, Key=wrc_process_folder+file_name_idoctor_data_articlerank)
    print("----------------------------File: {} moving to process folder done.".format(file_name_idoctor_data_articlerank))
    
    sc = SparkContext()
    glueContext = GlueContext(sc)
    spark = glueContext.spark_session
    job = Job(glueContext)
    job.init(args['JOB_NAME'], args)
    #从此处开始替换成Glue job自动生成的脚本，即CSV每一列跟目标表每一列的对应关系
    ## @type: DataSource
    ## @args: [database = "rapid-prd-catalog-gluedatabase", table_name = "rapid_prd_idoctor_data_articlerank_csv", transformation_ctx = "datasource0"]
    ## @return: datasource0
    ## @inputs: []
    datasource0 = glueContext.create_dynamic_frame.from_catalog(database = "rapid-prd-catalog-gluedatabase", table_name = "rapid_prd_idoctor_data_articlerank_csv", transformation_ctx = "datasource0")
    ## @type: ApplyMapping
    ## @args: [mapping = [("name", "string", "name", "string"), ("brand", "string", "brand", "string"), ("contentareaname", "string", "contentareaname", "string"), ("contentareamodulename", "string", "contentareamodulename", "string"), ("contentareamodulecategoryname", "string", "contentareamodulecategoryname", "string"), ("ta", "string", "ta", "string"), ("veevavaultcode", "string", "veevavaultcode", "string"), ("rank", "long", "rank", "int"), ("contentsent", "long", "contentsent", "int"), ("contentopened", "long", "contentopened", "int"), ("isdeleted", "long", "isdeleted", "boolean"), ("ownerid", "long", "ownerid", "int"), ("createdutc", "string", "createdutc", "timestamp"), ("modifiedid", "long", "modifiedid", "int"), ("modifiedutc", "string", "modifiedutc", "timestamp")], transformation_ctx = "applymapping1"]
    ## @return: applymapping1
    ## @inputs: [frame = datasource0]
    applymapping1 = ApplyMapping.apply(frame = datasource0, mappings = [("name", "string", "name", "string"), ("brand", "string", "brand", "string"), ("contentareaname", "string", "contentareaname", "string"), ("contentareamodulename", "string", "contentareamodulename", "string"), ("contentareamodulecategoryname", "string", "contentareamodulecategoryname", "string"), ("ta", "string", "ta", "string"), ("veevavaultcode", "string", "veevavaultcode", "string"), ("rank", "long", "rank", "int"), ("contentsent", "long", "contentsent", "int"), ("contentopened", "long", "contentopened", "int"), ("isdeleted", "long", "isdeleted", "boolean"), ("ownerid", "long", "ownerid", "int"), ("createdutc", "timestamp", "createdutc", "timestamp"), ("modifiedid", "long", "modifiedid", "int"), ("modifiedutc", "timestamp", "modifiedutc", "timestamp")], transformation_ctx = "applymapping1")
    ## @type: SelectFields
    ## @args: [paths = ["contentareamodulecategoryname", "contentareaname", "versionnumber", "ownerid", "ta", "veevavaultcode", "contentsent", "isdeleted", "modifiedutc", "contentareamodulename", "contentopened", "name", "rank", "id", "brand", "modifiedid", "createdutc"], transformation_ctx = "selectfields2"]
    ## @return: selectfields2
    ## @inputs: [frame = applymapping1]
    selectfields2 = SelectFields.apply(frame = applymapping1, paths = ["contentareamodulecategoryname", "contentareaname", "versionnumber", "ownerid", "ta", "veevavaultcode", "contentsent", "isdeleted", "modifiedutc", "contentareamodulename", "contentopened", "name", "rank", "id", "brand", "modifiedid", "createdutc"], transformation_ctx = "selectfields2")
    ## @type: ResolveChoice
    ## @args: [choice = "MATCH_CATALOG", database = "rapid-prd-catalog-gluedatabase", table_name = "rapid_prd_idoctorprd_dbo_idoctor_data_articlerank", transformation_ctx = "resolvechoice3"]
    ## @return: resolvechoice3
    ## @inputs: [frame = selectfields2]
    resolvechoice3 = ResolveChoice.apply(frame = selectfields2, choice = "MATCH_CATALOG", database = "rapid-prd-catalog-gluedatabase", table_name = "rapid_prd_idoctorprd_dbo_idoctor_data_articlerank", transformation_ctx = "resolvechoice3")
    ## @type: ResolveChoice
    ## @args: [choice = "make_cols", transformation_ctx = "resolvechoice4"]
    ## @return: resolvechoice4
    ## @inputs: [frame = resolvechoice3]
    resolvechoice4 = ResolveChoice.apply(frame = resolvechoice3, choice = "make_cols", transformation_ctx = "resolvechoice4")
    ## @type: DataSink
    ## @args: [database = "rapid-prd-catalog-gluedatabase", table_name = "rapid_prd_idoctor_dbo_idoctor_data_articlerank", transformation_ctx = "datasink5"]
    ## @return: datasink5
    ## @inputs: [frame = resolvechoice4]
    #从此处结束替换成Glue job自动生成的脚本，即CSV每一列跟目标表每一列的对应关系 
    print("----------idoctor_data_articlerank——datasource0 count: {}".format(datasource0.count()))
    print("----------idoctor_data_articlerank count: {}".format(resolvechoice4.count()))
    #去空值
    #Loading1= DropNullFields.apply(frame = resolvechoice4, transformation_ctx = "Loading1")
    idoctor_data_articlerank_df = resolvechoice4.toDF()
    #print(idoctor_data_articlerank_df.show())
    idoctor_data_articlerank_df = idoctor_data_articlerank_df.withColumn("createdutc", F.unix_timestamp("createdutc", 'MM/dd/yyyy HH:mm:ss').cast("timestamp")) \
    .withColumn("modifiedutc", F.unix_timestamp("modifiedutc", 'MM/dd/yyyy HH:mm:ss').cast("timestamp"))
    #print(idoctor_data_articlerank_df.show())
    #idoctor_data_articlerank_df.show()
    
    conn = glueContext.extract_jdbc_conf('rapid-prd-idoctor-connreader-writer')
    #print("----------conn:",conn)
    url = conn['url']
    #print("----------url",url)
    USERNAME = conn['user']
    #print("----------username:",USERNAME)
    PASSWORD = conn['password']
    DATABASE = "idoctorprd"
    #print("----------database:",DATABASE)
    URL = url+"/"+DATABASE
    #print(URL)
    DRIVER = "org.postgresql.Driver"
    
    idoctor_data_articlerank_df.write \
        .format("jdbc") \
        .option("driver",DRIVER) \
        .option("url", URL) \
        .option("dbtable", postgresql_destination_table_idoctor_data_articlerank) \
        .option("user", USERNAME) \
        .option("password", PASSWORD) \
        .option("truncate","true") \
        .option("ssl","true") \
        .mode("overwrite") \
        .save()
    
    print('--------------Load all the data into table {} done.'.format(postgresql_destination_table_idoctor_data_articlerank))
    
    job.commit()
    
except Exception as e:
    print(e)
    raise e

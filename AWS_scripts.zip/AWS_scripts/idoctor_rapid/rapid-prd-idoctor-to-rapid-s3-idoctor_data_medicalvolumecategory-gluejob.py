import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from datetime import date, timedelta
import time
import datetime

try:
    current_date =  time.strftime('%Y-%m-%d',time.localtime(time.time()))
    print("------Current Date is: {}".format(current_date))
    
    BucketName = 'lly-cn-ibu-rapid-idoctor-prd-private'
    RootFolderName = 'ToRAPID/idoctor_data_medicalvolumecategory'
    
    idoctor_data_medicalvolumecategory_ProcessDir = RootFolderName + '/'+ current_date +'/process'
    
    
    idoctor_data_medicalvolumecategory_DestinationDir = RootFolderName + '/'+ current_date +'/idoctor_data_medicalvolumecategory.csv'
    
    FlagFileS3Path = 'rapid-flag-file/done.rdy'
    
    idoctor_data_medicalvolumecategory_RdyFilePath = RootFolderName + '/'+ current_date +'/idoctor_data_medicalvolumecategory.rdy'
    
    
    database_name = "rapid-prd-catalog-gluedatabase"
    idoctor_data_medicalvolumecategory_table_name = "rapid_prd_idoctorprd_dbo_idoctor_data_medicalvolumecategory"
    
    
    
    ## @params: [JOB_NAME]
    args = getResolvedOptions(sys.argv, ['JOB_NAME'])
    
    sc = SparkContext()
    glueContext = GlueContext(sc)
    spark = glueContext.spark_session
    job = Job(glueContext)
    job.init(args['JOB_NAME'], args)
    
    
    ## idoctor_data_medicalvolumecategory table
    idoctor_data_medicalvolumecategory_datasource = glueContext.create_dynamic_frame.from_catalog(database = database_name, table_name = idoctor_data_medicalvolumecategory_table_name, transformation_ctx = "idoctor_data_medicalvolumecategory_datasource")
    
    
    idoctor_data_medicalvolumecategory_repartitionDF = idoctor_data_medicalvolumecategory_datasource.toDF()
    
    
    ## Merge all partition file into one csv and change type from dynamic frame to spark dataframe
    idoctor_data_medicalvolumecategory_repartitionDF = idoctor_data_medicalvolumecategory_repartitionDF.coalesce(1)
    
    
    print ("------idoctor_data_medicalvolumecategory Count:  ", idoctor_data_medicalvolumecategory_repartitionDF.count())
    print(idoctor_data_medicalvolumecategory_repartitionDF)
    idoctor_data_medicalvolumecategory_repartitionDF.write.format('csv').mode("overwrite").save("s3://" + BucketName + "/" + idoctor_data_medicalvolumecategory_ProcessDir,sep=",",header='true')
    print("------Load idoctor_data_medicalvolumecategory to S3 folder: {} successfully.".format(idoctor_data_medicalvolumecategory_ProcessDir))
    
    
    
    ## ------------------------------ idoctor_data_medicalvolumecategory S3 Processing Logic ------------------------------------
    import boto3
    client = boto3.client('s3')
    
    idoctor_data_medicalvolumecategory_Response = client.list_objects(
        Bucket=BucketName,
        Prefix=idoctor_data_medicalvolumecategory_ProcessDir,
    )
    
    
    idoctor_data_medicalvolumecategory__process_file_absolutely_s3_path = idoctor_data_medicalvolumecategory_Response["Contents"][0]["Key"]
    
    
    print("------idoctor_data_medicalvolumecategory__process_file_absolutely_s3_path: ",idoctor_data_medicalvolumecategory__process_file_absolutely_s3_path)
    idoctor_data_medicalvolumecategory_copy_source = {'Bucket': BucketName, 'Key': idoctor_data_medicalvolumecategory__process_file_absolutely_s3_path}
    print("------idoctor_data_medicalvolumecategory_copy_source: ",idoctor_data_medicalvolumecategory_copy_source)
    
    
    print(idoctor_data_medicalvolumecategory_DestinationDir)
    
    client.copy(CopySource=idoctor_data_medicalvolumecategory_copy_source, Bucket=BucketName, Key=idoctor_data_medicalvolumecategory_DestinationDir)
    print("------File moving from idoctor_data_medicalvolumecategory process folder to desitination folder done.")
    
    ## Delete folder in S3
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(BucketName)
    bucket.objects.filter(Prefix=idoctor_data_medicalvolumecategory_ProcessDir).delete()
    print("------Delete S3 idoctor_data_medicalvolumecategory process folder: {} done.".format(idoctor_data_medicalvolumecategory_ProcessDir))
    
    ## Copy flag file and rename it
    idoctor_data_medicalvolumecategory_CopyFlagFileDict = {'Bucket': BucketName, 'Key': FlagFileS3Path}
    print("------idoctor_data_medicalvolumecategory_CopyFlagFileDict: ",idoctor_data_medicalvolumecategory_CopyFlagFileDict)
    
    client.copy(CopySource=idoctor_data_medicalvolumecategory_CopyFlagFileDict, Bucket=BucketName, Key=idoctor_data_medicalvolumecategory_RdyFilePath)
    print("------Move idoctor_data_medicalvolumecategory rdy file to S3 path: {} done.".format(idoctor_data_medicalvolumecategory_RdyFilePath))
    
    
    job.commit()

except Exception as e:
    print(e)
    raise e
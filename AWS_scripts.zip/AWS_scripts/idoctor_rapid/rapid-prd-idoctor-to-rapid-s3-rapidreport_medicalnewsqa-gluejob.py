import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from datetime import date, timedelta
import time
import datetime

try:
    current_date =  time.strftime('%Y-%m-%d',time.localtime(time.time()))
    print("------Current Date is: {}".format(current_date))
    
    BucketName = 'lly-cn-ibu-rapid-idoctor-prd-private'
    RootFolderName = 'ToRAPID/rapidreport_medicalnewsqa'
    
    rapidreport_medicalnewsqa_ProcessDir = RootFolderName + '/'+ current_date +'/process'
    
    
    rapidreport_medicalnewsqa_DestinationDir = RootFolderName + '/'+ current_date +'/rapidreport_medicalnewsqa.csv'
    
    FlagFileS3Path = 'rapid-flag-file/done.rdy'
    
    rapidreport_medicalnewsqa_RdyFilePath = RootFolderName + '/'+ current_date +'/rapidreport_medicalnewsqa.rdy'
    
    
    database_name = "rapid-prd-catalog-gluedatabase"
    rapidreport_medicalnewsqa_table_name = "rapid_prd_idoctorprd_dbo_rapidreport_medicalnewsqa"
    
    
    
    ## @params: [JOB_NAME]
    args = getResolvedOptions(sys.argv, ['JOB_NAME'])
    
    sc = SparkContext()
    glueContext = GlueContext(sc)
    spark = glueContext.spark_session
    job = Job(glueContext)
    job.init(args['JOB_NAME'], args)
    
    
    ## rapidreport_medicalnewsqa table
    rapidreport_medicalnewsqa_datasource = glueContext.create_dynamic_frame.from_catalog(database = database_name, table_name = rapidreport_medicalnewsqa_table_name, transformation_ctx = "rapidreport_medicalnewsqa_datasource")
    
    
    rapidreport_medicalnewsqa_repartitionDF = rapidreport_medicalnewsqa_datasource.toDF()
    
    
    ## Merge all partition file into one csv and change type from dynamic frame to spark dataframe
    rapidreport_medicalnewsqa_repartitionDF = rapidreport_medicalnewsqa_repartitionDF.coalesce(1)
    
    
    print ("------rapidreport_medicalnewsqa Count:  ", rapidreport_medicalnewsqa_repartitionDF.count())
    print(rapidreport_medicalnewsqa_repartitionDF)
    rapidreport_medicalnewsqa_repartitionDF.write.format('csv').mode("overwrite").save("s3://" + BucketName + "/" + rapidreport_medicalnewsqa_ProcessDir,sep=",",header='true')
    print("------Load rapidreport_medicalnewsqa to S3 folder: {} successfully.".format(rapidreport_medicalnewsqa_ProcessDir))
    
    
    
    ## ------------------------------ rapidreport_medicalnewsqa S3 Processing Logic ------------------------------------
    import boto3
    client = boto3.client('s3')
    
    rapidreport_medicalnewsqa_Response = client.list_objects(
        Bucket=BucketName,
        Prefix=rapidreport_medicalnewsqa_ProcessDir,
    )
    
    
    rapidreport_medicalnewsqa__process_file_absolutely_s3_path = rapidreport_medicalnewsqa_Response["Contents"][0]["Key"]
    
    
    print("------rapidreport_medicalnewsqa__process_file_absolutely_s3_path: ",rapidreport_medicalnewsqa__process_file_absolutely_s3_path)
    rapidreport_medicalnewsqa_copy_source = {'Bucket': BucketName, 'Key': rapidreport_medicalnewsqa__process_file_absolutely_s3_path}
    print("------rapidreport_medicalnewsqa_copy_source: ",rapidreport_medicalnewsqa_copy_source)
    
    
    print(rapidreport_medicalnewsqa_DestinationDir)
    
    client.copy(CopySource=rapidreport_medicalnewsqa_copy_source, Bucket=BucketName, Key=rapidreport_medicalnewsqa_DestinationDir)
    print("------File moving from rapidreport_medicalnewsqa process folder to desitination folder done.")
    
    ## Delete folder in S3
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(BucketName)
    bucket.objects.filter(Prefix=rapidreport_medicalnewsqa_ProcessDir).delete()
    print("------Delete S3 rapidreport_medicalnewsqa process folder: {} done.".format(rapidreport_medicalnewsqa_ProcessDir))
    
    ## Copy flag file and rename it
    rapidreport_medicalnewsqa_CopyFlagFileDict = {'Bucket': BucketName, 'Key': FlagFileS3Path}
    print("------rapidreport_medicalnewsqa_CopyFlagFileDict: ",rapidreport_medicalnewsqa_CopyFlagFileDict)
    
    client.copy(CopySource=rapidreport_medicalnewsqa_CopyFlagFileDict, Bucket=BucketName, Key=rapidreport_medicalnewsqa_RdyFilePath)
    print("------Move rapidreport_medicalnewsqa rdy file to S3 path: {} done.".format(rapidreport_medicalnewsqa_RdyFilePath))
    
    
    job.commit()

except Exception as e:
    print(e)
    raise e
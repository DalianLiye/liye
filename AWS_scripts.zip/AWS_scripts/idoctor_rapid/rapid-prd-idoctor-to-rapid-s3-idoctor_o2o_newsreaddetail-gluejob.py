import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from datetime import date, timedelta
import time
import datetime

try:
    current_date =  time.strftime('%Y-%m-%d',time.localtime(time.time()))
    print("Current Date is: {}".format(current_date))

    BucketName = 'lly-cn-ibu-rapid-idoctor-prd-private'
    RootFolderName = 'ToRAPID/idoctor_o2o_newsreaddetail'

    idoctor_o2o_newsreaddetail_ProcessDir = RootFolderName + '/'+ current_date +'/process'

    idoctor_o2o_newsreaddetail_DestinationDir = RootFolderName + '/'+ current_date +'/idoctor_o2o_newsreaddetail.csv'

    FlagFileS3Path = 'rapid-flag-file/done.rdy'

    idoctor_o2o_newsreaddetail_RdyFilePath = RootFolderName + '/'+ current_date +'/idoctor_o2o_newsreaddetail.rdy'

    database_name = "rapid-prd-catalog-gluedatabase"
    idoctor_o2o_newsreaddetail_table_name = "rapid_prd_idoctorprd_dbo_idoctor_o2o_newsreaddetail"

    ## @params: [JOB_NAME]
    args = getResolvedOptions(sys.argv, ['JOB_NAME'])

    sc = SparkContext()
    glueContext = GlueContext(sc)
    spark = glueContext.spark_session
    job = Job(glueContext)
    job.init(args['JOB_NAME'], args)

    ## idoctor_o2o_newsreaddetail table
    idoctor_o2o_newsreaddetail_datasource = glueContext.create_dynamic_frame.from_catalog(database = database_name, table_name = idoctor_o2o_newsreaddetail_table_name, transformation_ctx = "idoctor_o2o_newsreaddetail_datasource")

    idoctor_o2o_newsreaddetail_repartitionDF = idoctor_o2o_newsreaddetail_datasource.toDF()

    ## Merge all partition file into one csv and change type from dynamic frame to spark dataframe
    idoctor_o2o_newsreaddetail_repartitionDF = idoctor_o2o_newsreaddetail_repartitionDF.coalesce(1)

    print ("idoctor_o2o_newsreaddetail Count:  ", idoctor_o2o_newsreaddetail_repartitionDF.count())
    print(idoctor_o2o_newsreaddetail_repartitionDF)
    idoctor_o2o_newsreaddetail_repartitionDF.write.format('csv').mode("overwrite").save("s3://" + BucketName + "/" + idoctor_o2o_newsreaddetail_ProcessDir,sep=",",header='true')
    print("Load idoctor_o2o_newsreaddetail to S3 folder: {} successfully.".format(idoctor_o2o_newsreaddetail_ProcessDir))

    ## ------------------------------ idoctor_o2o_newsreaddetail S3 Processing Logic ------------------------------------
    import boto3
    client = boto3.client('s3')

    idoctor_o2o_newsreaddetail_Response = client.list_objects(
        Bucket=BucketName,
        Prefix=idoctor_o2o_newsreaddetail_ProcessDir,
    )

    idoctor_o2o_newsreaddetail_process_file_absolutely_s3_path = idoctor_o2o_newsreaddetail_Response["Contents"][0]["Key"]

    print("idoctor_o2o_newsreaddetail_process_file_absolutely_s3_path: ",idoctor_o2o_newsreaddetail_process_file_absolutely_s3_path)
    idoctor_o2o_newsreaddetail_copy_source = {'Bucket': BucketName, 'Key': idoctor_o2o_newsreaddetail_process_file_absolutely_s3_path}
    print("idoctor_o2o_newsreaddetail_copy_source: ",idoctor_o2o_newsreaddetail_copy_source)

    print(idoctor_o2o_newsreaddetail_DestinationDir)

    client.copy(CopySource=idoctor_o2o_newsreaddetail_copy_source, Bucket=BucketName, Key=idoctor_o2o_newsreaddetail_DestinationDir)
    print("File moving from idoctor_o2o_newsreaddetail process folder to desitination folder done.")

    ## Delete folder in S3
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(BucketName)
    bucket.objects.filter(Prefix=idoctor_o2o_newsreaddetail_ProcessDir).delete()
    print("Delete S3 idoctor_o2o_newsreaddetail process folder: {} done.".format(idoctor_o2o_newsreaddetail_ProcessDir))

    ## Copy flag file and rename it
    idoctor_o2o_newsreaddetail_CopyFlagFileDict = {'Bucket': BucketName, 'Key': FlagFileS3Path}
    print("idoctor_o2o_newsreaddetail_CopyFlagFileDict: ",idoctor_o2o_newsreaddetail_CopyFlagFileDict)

    client.copy(CopySource=idoctor_o2o_newsreaddetail_CopyFlagFileDict, Bucket=BucketName, Key=idoctor_o2o_newsreaddetail_RdyFilePath)
    print("Move idoctor_o2o_newsreaddetail rdy file to S3 path: {} done.".format(idoctor_o2o_newsreaddetail_RdyFilePath))

    job.commit()

except Exception as e:
    print(e)
    raise e

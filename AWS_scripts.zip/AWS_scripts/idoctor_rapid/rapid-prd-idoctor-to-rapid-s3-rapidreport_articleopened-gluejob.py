import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from datetime import date, timedelta
import time
import datetime

try:
    current_date =  time.strftime('%Y-%m-%d',time.localtime(time.time()))
    print("------Current Date is: {}".format(current_date))
    
    BucketName = 'lly-cn-ibu-rapid-idoctor-prd-private'
    RootFolderName = 'ToRAPID/rapidreport_articleopened'
    
    rapidreport_articleopened_ProcessDir = RootFolderName + '/'+ current_date +'/process'
    
    
    rapidreport_articleopened_DestinationDir = RootFolderName + '/'+ current_date +'/rapidreport_articleopened.csv'
    
    FlagFileS3Path = 'rapid-flag-file/done.rdy'
    
    rapidreport_articleopened_RdyFilePath = RootFolderName + '/'+ current_date +'/rapidreport_articleopened.rdy'
    
    
    database_name = "rapid-prd-catalog-gluedatabase"
    rapidreport_articleopened_table_name = "rapid_prd_idoctorprd_dbo_rapidreport_articleopened"
    
    
    
    ## @params: [JOB_NAME]
    args = getResolvedOptions(sys.argv, ['JOB_NAME'])
    
    sc = SparkContext()
    glueContext = GlueContext(sc)
    spark = glueContext.spark_session
    job = Job(glueContext)
    job.init(args['JOB_NAME'], args)
    
    
    ## rapidreport_articleopened table
    rapidreport_articleopened_datasource = glueContext.create_dynamic_frame.from_catalog(database = database_name, table_name = rapidreport_articleopened_table_name, transformation_ctx = "rapidreport_articleopened_datasource")
    
    
    rapidreport_articleopened_repartitionDF = rapidreport_articleopened_datasource.toDF()
    
    
    ## Merge all partition file into one csv and change type from dynamic frame to spark dataframe
    rapidreport_articleopened_repartitionDF = rapidreport_articleopened_repartitionDF.coalesce(1)
    
    
    print ("------rapidreport_articleopened Count:  ", rapidreport_articleopened_repartitionDF.count())
    print(rapidreport_articleopened_repartitionDF)
    rapidreport_articleopened_repartitionDF.write.format('csv').mode("overwrite").save("s3://" + BucketName + "/" + rapidreport_articleopened_ProcessDir,sep=",",header='true')
    print("------Load rapidreport_articleopened to S3 folder: {} successfully.".format(rapidreport_articleopened_ProcessDir))
    
    
    
    ## ------------------------------ rapidreport_articleopened S3 Processing Logic ------------------------------------
    import boto3
    client = boto3.client('s3')
    
    rapidreport_articleopened_Response = client.list_objects(
        Bucket=BucketName,
        Prefix=rapidreport_articleopened_ProcessDir,
    )
    
    
    rapidreport_articleopened__process_file_absolutely_s3_path = rapidreport_articleopened_Response["Contents"][0]["Key"]
    
    
    print("------rapidreport_articleopened__process_file_absolutely_s3_path: ",rapidreport_articleopened__process_file_absolutely_s3_path)
    rapidreport_articleopened_copy_source = {'Bucket': BucketName, 'Key': rapidreport_articleopened__process_file_absolutely_s3_path}
    print("------rapidreport_articleopened_copy_source: ",rapidreport_articleopened_copy_source)
    
    
    print(rapidreport_articleopened_DestinationDir)
    
    client.copy(CopySource=rapidreport_articleopened_copy_source, Bucket=BucketName, Key=rapidreport_articleopened_DestinationDir)
    print("------File moving from rapidreport_articleopened process folder to desitination folder done.")
    
    ## Delete folder in S3
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(BucketName)
    bucket.objects.filter(Prefix=rapidreport_articleopened_ProcessDir).delete()
    print("------Delete S3 rapidreport_articleopened process folder: {} done.".format(rapidreport_articleopened_ProcessDir))
    
    ## Copy flag file and rename it
    rapidreport_articleopened_CopyFlagFileDict = {'Bucket': BucketName, 'Key': FlagFileS3Path}
    print("------rapidreport_articleopened_CopyFlagFileDict: ",rapidreport_articleopened_CopyFlagFileDict)
    
    client.copy(CopySource=rapidreport_articleopened_CopyFlagFileDict, Bucket=BucketName, Key=rapidreport_articleopened_RdyFilePath)
    print("------Move rapidreport_articleopened rdy file to S3 path: {} done.".format(rapidreport_articleopened_RdyFilePath))
    
    
    job.commit()

except Exception as e:
    print(e)
    raise e
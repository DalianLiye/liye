import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from datetime import date, timedelta
import time
import datetime

try:
    current_date =  time.strftime('%Y-%m-%d',time.localtime(time.time()))
    print("------Current Date is: {}".format(current_date))
    
    BucketName = 'lly-cn-ibu-rapid-idoctor-prd-private'
    RootFolderName = 'ToRAPID/rapidreport_literaturesearch'
    
    rapidreport_literaturesearch_ProcessDir = RootFolderName + '/'+ current_date +'/process'
    
    
    rapidreport_literaturesearch_DestinationDir = RootFolderName + '/'+ current_date +'/rapidreport_literaturesearch.csv'
    
    FlagFileS3Path = 'rapid-flag-file/done.rdy'
    
    rapidreport_literaturesearch_RdyFilePath = RootFolderName + '/'+ current_date +'/rapidreport_literaturesearch.rdy'
    
    
    database_name = "rapid-prd-catalog-gluedatabase"
    rapidreport_literaturesearch_table_name = "rapid_prd_idoctorprd_dbo_rapidreport_literaturesearch"
    
    
    
    ## @params: [JOB_NAME]
    args = getResolvedOptions(sys.argv, ['JOB_NAME'])
    
    sc = SparkContext()
    glueContext = GlueContext(sc)
    spark = glueContext.spark_session
    job = Job(glueContext)
    job.init(args['JOB_NAME'], args)
    
    
    ## rapidreport_literaturesearch table
    rapidreport_literaturesearch_datasource = glueContext.create_dynamic_frame.from_catalog(database = database_name, table_name = rapidreport_literaturesearch_table_name, transformation_ctx = "rapidreport_literaturesearch_datasource")
    
    
    rapidreport_literaturesearch_repartitionDF = rapidreport_literaturesearch_datasource.toDF()
    
    
    ## Merge all partition file into one csv and change type from dynamic frame to spark dataframe
    rapidreport_literaturesearch_repartitionDF = rapidreport_literaturesearch_repartitionDF.coalesce(1)
    
    
    print ("------rapidreport_literaturesearch Count:  ", rapidreport_literaturesearch_repartitionDF.count())
    print(rapidreport_literaturesearch_repartitionDF)
    rapidreport_literaturesearch_repartitionDF.write.format('csv').mode("overwrite").save("s3://" + BucketName + "/" + rapidreport_literaturesearch_ProcessDir,sep=",",header='true')
    print("------Load rapidreport_literaturesearch to S3 folder: {} successfully.".format(rapidreport_literaturesearch_ProcessDir))
    
    
    
    ## ------------------------------ rapidreport_literaturesearch S3 Processing Logic ------------------------------------
    import boto3
    client = boto3.client('s3')
    
    rapidreport_literaturesearch_Response = client.list_objects(
        Bucket=BucketName,
        Prefix=rapidreport_literaturesearch_ProcessDir,
    )
    
    
    rapidreport_literaturesearch__process_file_absolutely_s3_path = rapidreport_literaturesearch_Response["Contents"][0]["Key"]
    
    
    print("------rapidreport_literaturesearch__process_file_absolutely_s3_path: ",rapidreport_literaturesearch__process_file_absolutely_s3_path)
    rapidreport_literaturesearch_copy_source = {'Bucket': BucketName, 'Key': rapidreport_literaturesearch__process_file_absolutely_s3_path}
    print("------rapidreport_literaturesearch_copy_source: ",rapidreport_literaturesearch_copy_source)
    
    
    print(rapidreport_literaturesearch_DestinationDir)
    
    client.copy(CopySource=rapidreport_literaturesearch_copy_source, Bucket=BucketName, Key=rapidreport_literaturesearch_DestinationDir)
    print("------File moving from rapidreport_literaturesearch process folder to desitination folder done.")
    
    ## Delete folder in S3
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(BucketName)
    bucket.objects.filter(Prefix=rapidreport_literaturesearch_ProcessDir).delete()
    print("------Delete S3 rapidreport_literaturesearch process folder: {} done.".format(rapidreport_literaturesearch_ProcessDir))
    
    ## Copy flag file and rename it
    rapidreport_literaturesearch_CopyFlagFileDict = {'Bucket': BucketName, 'Key': FlagFileS3Path}
    print("------rapidreport_literaturesearch_CopyFlagFileDict: ",rapidreport_literaturesearch_CopyFlagFileDict)
    
    client.copy(CopySource=rapidreport_literaturesearch_CopyFlagFileDict, Bucket=BucketName, Key=rapidreport_literaturesearch_RdyFilePath)
    print("------Move rapidreport_literaturesearch rdy file to S3 path: {} done.".format(rapidreport_literaturesearch_RdyFilePath))
    
    
    job.commit()

except Exception as e:
    print(e)
    raise e
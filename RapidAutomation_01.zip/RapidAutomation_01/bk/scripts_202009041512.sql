with ctx_ruleid_rulename as (
    select distinct
           t.attr_ctx as ctx,
           t1.rule_name
    from xref_ctx_id t
    left outer join xref_rule t1
        on t.attr_rule_id = t1.rule_id
),

parent_child_mappingInfo as (
    select t1.rule_name as parent_rule_name,
		   t.attr_parent as parent_ctx,
           t2.rule_name as child_rule_name,
		   t.attr_child as child_ctx,
           t.attr_flg as flg,
           t.attr_value as text
    from test_liye_0828 t
    left outer join ctx_ruleid_rulename t1
        on substr(t.attr_parent,0,instr(t.attr_parent,'_') - 1) = t1.ctx
    left outer join ctx_ruleid_rulename t2
        on substr(t.attr_child,0,instr(t.attr_child,'_') - 1) = t2.ctx
),

parentRule_numbering as (
    select t.parent_rule_name,
           t.parent_ctx,
           t.flg,
           row_number()over(partition by t.parent_rule_name,t.flg order by t.parent_ctx) as parent_num
    from (
        select distinct
              t.parent_rule_name,
              t.parent_ctx,
              t.flg
        from parent_child_mappingInfo t
    ) t
),

childRule_numbering as (
    select  t.child_rule_name,
            t.child_ctx,
            t.flg,
            row_number()over(partition by t.child_rule_name,t.flg order by t.child_ctx) as child_num
    from (
        select distinct
              t.child_rule_name,
              t.child_ctx,
              t.flg
        from parent_child_mappingInfo t
    ) t
),

dataset as (
    select t.parent_rule_name || '_' || parent_num || '_' ||t.flg as parent_rule_name,
           t.child_rule_name || '_' || child_num || '_' ||t.flg as child_rule_name,
           t.text
    from parent_child_mappingInfo t
    left outer join parentRule_numbering t1
        on t.parent_ctx = t1.parent_ctx
    left outer join childRule_numbering t2
        on t.child_ctx = t2.child_ctx
),

dataset_metrics as (
  select distinct
        case
            when t5.child_rule_name like 'select_clause%' then t8.parent_rule_name
            when t5.child_rule_name like 'from_clause%' then t8.parent_rule_name
        end as r_column_name,
        case
            when t5.child_rule_name like 'select_clause%' or t5.child_rule_name like 'from_clause%' then t5.parent_rule_name
        end as r_table_name,
        case
            when t5.child_rule_name like 'select_clause%' and t9.child_rule_name like 'table_alias%' then t9.text
            when t5.child_rule_name like 'from_clause%' and t8.child_rule_name like 'table_alias%' then t8.text
        end as table_alias,
        case when t5.child_rule_name like 'select_clause%' and t8.child_rule_name like 'field%' then t8.text end as column_name,
        case when t5.child_rule_name like 'select_clause%' and t8.child_rule_name like 'column_alias%' then t8.text end as column_alias,
        case when t5.child_rule_name like 'from_clause%' then t7.text end as table_name
    from dataset t
    left outer join dataset t1  --table_name_list
        on t.parent_rule_name = t1.child_rule_name
    left outer join dataset t2  --from_clause
        on t1.parent_rule_name = t2.child_rule_name
    left outer join dataset t3  --query_script
        on t2.parent_rule_name = t3.child_rule_name
    left outer join dataset t4  --query_script
        on t3.parent_rule_name = t4.parent_rule_name
    left outer join dataset t5  --select_clause，from_clause
        on t4.child_rule_name = t5.parent_rule_name
    left outer join dataset t6  --colum_list，table_name_list
        on t5.child_rule_name = t6.parent_rule_name
    left outer join dataset t7  --colum，table_name
        on t6.child_rule_name = t7.parent_rule_name
    left outer join dataset t8  --field，operator，column_alias，schema，table_alias
        on t7.child_rule_name = t8.parent_rule_name
    left outer join dataset t9  --table_alias
        on t8.child_rule_name = t9.parent_rule_name
    where t.child_rule_name like 'table_name___final'
        and case when t5.child_rule_name like 'select_clause%' or t5.child_rule_name like 'from_clause%' then t5.parent_rule_name end  is not null
    order by 2,3,4,5
),

tableName_alias as (
    select t.r_table_name,
           t.table_alias,
           t.table_name
    from dataset_metrics t
    where t.r_column_name like 'table_name%'
        and t.table_alias is not null
),

dataset_merge as (
	select r_column_name,
		r_table_name,
		listagg(t.table_alias, '') within group (order by '1') table_alias,
		listagg(t.column_name, '') within group (order by '1') column_name ,
		listagg(t.column_alias, '') within group (order by '1') column_alias,
		listagg(t.table_name, '') within group (order by '1') table_name
	from dataset_metrics t
	where t.r_column_name like 'colum%'
	group by r_column_name,r_table_name
)

select row_number()over(partition by t.r_table_name order by t.column_name) as num,
       t.r_table_name,
       t.column_alias,
       t.column_name,
       t.table_alias,
       t1.table_name
from dataset_merge t
left outer join tableName_alias t1
    on t.r_table_name = t1.r_table_name
    and t.table_alias = t1.table_alias


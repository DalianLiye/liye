with ctx_ruleid_rulename as (
    select distinct
           t.attr_ctx as ctx,
           t1.rule_name
    from xref_ctx_id t
    left outer join xref_rule t1
        on t.attr_rule_id = t1.rule_id
),

parent_child_mappingInfo as (
    select t1.rule_name as parent_rule_name,
		   t.attr_parent as parent_ctx,
           t2.rule_name as child_rule_name,
		   t.attr_child as child_ctx,
           t.attr_flg as flg,
           t.attr_value as text
    from test_liye_0828 t
    left outer join ctx_ruleid_rulename t1
        on substr(t.attr_parent,0,instr(t.attr_parent,'_') - 1) = t1.ctx
    left outer join ctx_ruleid_rulename t2
        on substr(t.attr_child,0,instr(t.attr_child,'_') - 1) = t2.ctx
),

parentRule_numbering as (
    select t.parent_rule_name,
           t.parent_ctx,
           t.flg,
           row_number()over(partition by t.parent_rule_name,t.flg order by to_number(substr(t.parent_ctx,instr(t.parent_ctx,'_',1,1) + 1,instr(t.parent_ctx,'_',1,2) - instr(t.parent_ctx,'_',1,1) - 1))) as parent_num
    from (
        select distinct
              t.parent_rule_name,
              t.parent_ctx,
              t.flg
        from parent_child_mappingInfo t
    ) t
),

childRule_numbering as (
    select  t.child_rule_name,
            t.child_ctx,
            t.flg,
            row_number()over(partition by t.child_rule_name,t.flg order by to_number(substr(t.child_ctx,instr(t.child_ctx,'_',1,1) + 1,instr(t.child_ctx,'_',1,2) - instr(t.child_ctx,'_',1,1) - 1))) as child_num
    from (
        select distinct
              t.child_rule_name,
              t.child_ctx,
              t.flg
        from parent_child_mappingInfo t
    ) t
),

dataset as (
    select t.parent_rule_name || '_' || parent_num || '_' ||t.flg as parent_rule_name,
           t.child_rule_name || '_' || child_num || '_' ||t.flg as child_rule_name,
           t.text,
		   t.flg
    from parent_child_mappingInfo t
    left outer join parentRule_numbering t1
        on t.parent_ctx = t1.parent_ctx
    left outer join childRule_numbering t2
        on t.child_ctx = t2.child_ctx
),

fromqueryscript_Alias as (
    select t.r_query_script,
           t.r_from_clause,
		   t.flg,
           listagg(t.r_from_query_script_list, '') within group (order by '1') as r_from_query_script_list,
           listagg(t.table_alias, '') within group (order by '1') as table_alias
    from (
        select  t.parent_rule_name as r_query_script,
				t.child_rule_name as r_from_clause,
				t.flg,
				case
					when t1.child_rule_name like 'from_query_script_list_%' then t1.child_rule_name
				end as r_from_query_script_list,
				case
					when t1.child_rule_name like 'table_alias_%' then t1.text
				end as table_alias
        from dataset t
        left outer join dataset t1
            on t.child_rule_name = t1.parent_rule_name
			and t.flg = t1.flg
        where t.child_rule_name like 'from_clause_%'
            and (t1.child_rule_name like 'from_query_script_list_%'
                 or t1.child_rule_name like 'table_alias_%')
    ) t
    group by t.r_query_script,
             t.r_from_clause,
			 t.flg
),

tableName_Alias as (
	select  t.parent_rule_name as r_query_script,
            t1.parent_rule_name as r_from_clause,
			t.flg,
			case
                when t2.child_rule_name like 'table_name_%' then t2.text
            end as table_name,
			case
                when t3.child_rule_name like 'table_alias_%' then t3.text
            end as table_alias
	from dataset t
	left outer join dataset t1
		on t.child_rule_name = t1.parent_rule_name
		and t.flg = t1.flg
	left outer join dataset t2
		on t1.child_rule_name = t2.parent_rule_name
		and t1.flg = t2.flg
	left outer join dataset t3
		on t2.child_rule_name = t3.parent_rule_name
		and t2.flg = t3.flg
	where t.child_rule_name like 'from_clause_%'
		and t1.child_rule_name like 'table_name_list_%'
		and t3.child_rule_name like 'table_alias_%'
),

fromqueryscript_tableName_Alias as (
    select t.r_query_script,
           t.r_from_clause,
           t.r_from_query_script_list,
           t.table_alias,
		   t.flg
    from (
        select * from fromqueryscript_Alias
        union all
        select * from tableName_Alias
    ) t
),

select_clause_dtl as (
    select t.r_query_script,
           t.r_colum,
           t.table_alias,
		   t.flg,
           listagg(t.field, '') within group (order by '1') as field,
           listagg(t.column_alias, '') within group (order by '1') as column_alias,
           row_number()over(partition by t.r_query_script order by to_number(substr(r_colum,instr(r_colum,'_',1,1) + 1,instr(r_colum,'_',1,2) - instr(r_colum,'_',1,1) - 1))) as column_order_num

    from (
        select t.r_query_script,
               t3.child_rule_name as r_colum,
               t.table_alias,
			   t.flg,
               case when t4.child_rule_name like 'field_%' then t4.text end as field,
               case when t4.child_rule_name like 'column_alias_%' then t4.text end as column_alias
        from fromqueryscript_tableName_Alias t
        left outer join dataset t1
            on t.r_query_script = t1.parent_rule_name
        left outer join dataset t2
            on t1.child_rule_name = t2.parent_rule_name
        left outer join dataset t3
            on t2.child_rule_name = t3.parent_rule_name
        left outer join dataset t4
            on t3.child_rule_name = t4.parent_rule_name
        left outer join dataset t5
            on t4.child_rule_name = t5.parent_rule_name
        where t1.child_rule_name like 'select_clause_%'
    ) t
    group by t.r_query_script,
             t.r_colum,
             t.table_alias,
			 t.flg
),

temporary_table as (
    select t.parent_rule_name,
           t.child_rule_name,
           t.text,
           t.flg
    from dataset t
    where t.child_rule_name like 'temporary_table_name%'
),

dataset_metrics as (
    select distinct
           --t3.parent_rule_name,
           case when t3.parent_rule_name like 'with_clause_%' then t4.text else   t2.parent_rule_name end as tt,
           t2.parent_rule_name,
           t2.child_rule_name as tt1,
           t.column_order_num,
           t.column_alias,
           t.field,
           t.table_alias,
           t1.r_from_query_script_list,
           t.flg
    from select_clause_dtl t
    left outer join fromqueryscript_tableName_Alias t1
        on t.r_query_script = t1.r_query_script
        and t.flg = t1.flg
    left outer join dataset t2
        on t.r_query_script = t2.child_rule_name
        and t.flg = t2.flg
    left outer join dataset t3
        on t2.parent_rule_name = t3.child_rule_name
        and t2.flg = t3.flg
    left outer join temporary_table t4
        on t3.parent_rule_name = t4.parent_rule_name
    order by 9 desc,1,2,3,4,5,6,7,8
),

test01 as (
    select t.tt as data_name,
           t.tt1 as data_name1,
           t.column_order_num,
           t.column_alias,
           t.field,
           t.table_alias,
           t.r_from_query_script_list as source_name,
           t.flg
    from dataset_metrics t
),

test02 as (
   select t.data_name,
           t.data_name1,
           t.column_order_num,
           t.column_alias,
           t.field,
           t.table_alias,
           t.source_name,
           level as level1
    from test01 t
    start with t.data_name = 'final_query_list_1_final'
        and t.column_order_num = 3
        and t.data_name1 = 'query_script_3_final'
    connect by  prior t.source_name = t.data_name
        and prior t.column_order_num = t.column_order_num
    order by 8
),

test03 as (
    select t.data_name,
           t.data_name1,
           t.column_order_num
    from test01 t
    where t.data_name like 'final_query_list_%_final'
),

/*

select t.*,t.data_name,
           t.data_name1,
           t.column_order_num,
           t.column_alias,
           t.field,
           t.table_alias,
           t.source_name,
           level as level1
from  test01 t
left outer join test03 t1
    on t.data_name = t1.data_name
    and t.data_name1 = t1.data_name1
    and t.column_order_num = t1.column_order_num
start with t1.data_name = t.data_name
    and t1.column_order_num = t.column_order_num
    and t1.data_name1 = t.data_name1
connect by  prior t.source_name = t.data_name
    and prior t.column_order_num = t.column_order_num
    and prior t.data_name1 = t.data_name1
order by 1,2,3
*/

test04 as (
  select t.data_name,
           t.data_name1,
           t.column_order_num,
           t.column_alias,
           t.field,
           t.table_alias,
           t.source_name,
           level as level1,
           SYS_CONNECT_BY_PATH(t.data_name, '/') as Path
    from test01 t
    start with t.data_name like 'final_query_list_%_final'
        --and t.column_order_num =1
        and t.data_name1 like 'query_script_%_final'
    connect by  prior t.source_name = t.data_name
        and prior t.column_order_num = t.column_order_num

    order by 2,3,8
),

test05 as (
    select first,
           last,
           row_number()over(partition by '1' order by '1') as id,
           data_name1
    from (
        select  distinct
                substr(t.path,2,instr(t.path,'/',2)-2) as first,
                substr(t.path,instr(t.path,'/',-1)+1) as last,
                t.data_name1
        from (
            select t.path,
                   case
                        when t.path ='/final_query_list_1_final' or instr(lead(t.path, 1, null) over(order by '1') ,t.path) = 0 or t.numm = 1 then 'Y'
                        else 'N'
                   end as tt,
                   t.data_name1,
                   t.numm
            from (
                select distinct
                        t.Path,
                        t.data_name1,
                        row_number()over(partition by '1' order by t.path desc) as numm
                from test04 t
                order by 1
            ) t
        ) t

        where t.tt = 'Y'
    )
),

test06 as (
    select t.*
    from test04 t
    where t.data_name in (
        select distinct data_name
        from (
            select first as data_name
            from test05 t

            union all

            select last
            from test05 t
        )
    )
    order by 1,2,3,4,5,6,7,8,9
),

test07 as (
    select distinct first,id,data_name1
    from test05 t

    union all

    select last,id,data_name1
    from test05 t
),

test99 as (
    select distinct
           data_name,
           source_name
    from test04
    order by 1,2
)


select distinct
  t1.data_name,
  connect_by_root(t1.data_name) as root
from
  test99 t1
  left join test99 t2
    on t2.data_name = t1.source_name
start with t2.data_name is null
connect by t1.source_name = prior t1.data_name


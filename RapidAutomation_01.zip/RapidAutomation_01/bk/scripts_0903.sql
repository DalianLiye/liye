with ctx_vs_ruleid_vs_rulename as (
    select distinct
           t.ctx,
           t.rule_id,
           t1.rule_name
    from xref_ctx_id t
    left outer join xref_rule t1
        on t.rule_id = t1.rule_id
),

temp as (
    select t1.rule_name as parent,
           t.parent as parent_ctx,
           t2.rule_name as child,
           t.child as child_ctx,
           t.flg,
           t.value
    from test_liye_0828 t
    left outer join ctx_vs_ruleid_vs_rulename t1
        on substr(t.parent,0,instr(t.parent,'_') - 1) = t1.ctx
    left outer join ctx_vs_ruleid_vs_rulename t2
        on substr(t.child,0,instr(t.child,'_') - 1) = t2.ctx
),

parent_number as (
    select t.*,
          row_number()over(partition by t.parent,t.flg order by t.parent_ctx) as parent_num
    from (
        select distinct
              t.parent,
              t.parent_ctx,
              t.flg
        from temp t
    ) t
),

child_number as (
    select t.*,
          row_number()over(partition by t.child,t.flg order by t.child_ctx) as child_num
    from (
        select distinct
              t.child,
              t.child_ctx,
              t.flg
        from temp t
    ) t
),

dataset as (
    select t.parent || '_' || parent_num || '_' ||t.flg as parent,
           t.child || '_' || child_num || '_' ||t.flg as child,
           t.value
    from temp t
    left outer join parent_number t1
        on t.parent_ctx = t1.parent_ctx
    left outer join child_number t2
        on t.child_ctx = t2.child_ctx
),

final_table_vs_schema_vs_table_alias as (
    select t.table_name,
           listagg (t.schema_name, ' ') within group (order by t.table_name) as schema_name,
           listagg (t.table_alias, ' ') within group (order by t.table_name) as table_alias
    from (
        select
            t.value as table_name,
            case when t1.child like 'schema%' then t1.value else null end as schema_name,
            case when t1.child like 'table_alias%' then t1.value else null end as table_alias
        from dataset t
        left outer join dataset t1  --schema  table_alias
            on t.child = t1.parent
        where t.child like 'table_name___final'
    ) t
    group by t.table_name
),

final_table_alias_column_alias_temp as (
    select distinct
        t8.parent as column_name1,
        t5.parent as table_name,
        case when t9.child like 'table_alias%' then t9.value else null end as table_alias,
        case when t8.child like 'field%' then t8.value else null end as column_name,
        case when t8.child like 'column_alias%' then t8.value else null end as column_alias
    from dataset t
    left outer join dataset t1
        on t.parent = t1.child
    left outer join dataset t2
        on t1.parent = t2.child
    left outer join dataset t3
        on t2.parent = t3.child
    left outer join dataset t4
        on t3.parent = t4.parent
    left outer join dataset t5
        on t4.child = t5.parent
    left outer join dataset t6
        on t5.child = t6.parent
    left outer join dataset t7
        on t6.child = t7.parent
    left outer join dataset t8
        on t7.child = t8.parent
    left outer join dataset t9
        on t8.child = t9.parent
    where t.child like 'table_name___final'
        and t5.child like 'select_clause%'
),

temp_01 as (
    select t.table_name,
           t.table_alias,
           t.column_name,
           t.column_alias
    from (
        select t.*,
               row_number()over(partition by t.table_name,t.column_name order by t.table_alias asc) as table_alias_num,
               row_number()over(partition by t.table_name,t.column_name order by t.column_name asc) as column_name_num,
               row_number()over(partition by t.table_name,t.column_name order by t.column_alias asc) as column_alias_num
        from (
            select distinct t.table_name,
                   nvl(t.table_alias,t1.table_alias) as table_alias,
                   nvl(t.column_name,t1.column_name) as column_name,
                   nvl(t.column_alias,t1.column_alias) as column_alias
            from final_table_alias_column_alias_temp t
            inner join final_table_alias_column_alias_temp t1
                on t.column_name1 = t1.column_name1
            where nvl(t.column_name,t1.column_name) is not null
        ) t
    ) t
    where t.table_alias_num=1 and t.column_name_num=1 and t.column_alias_num=1
),

test11 as (
  select distinct
        case
            when t5.child like 'select_clause%' or t5.child like 'from_clause%' then t8.parent
        end as column_name1,
        case
            when t5.child like 'select_clause%' or t5.child like 'from_clause%' then t5.parent
        end as table_name,
        case
            when t5.child like 'select_clause%' and t9.child like 'table_alias%' then t9.value
            when t5.child like 'from_clause%' and t8.child like 'table_alias%' then t8.value
        end as table_alias,
        case when t5.child like 'select_clause%' and t8.child like 'field%' then t8.value end as column_name,
        case when t5.child like 'select_clause%' and t8.child like 'column_alias%' then t8.value end as column_alias,

        case when t5.child like 'from_clause%' then t7.value end as column_name111

    from dataset t
    left outer join dataset t1
        on t.parent = t1.child
    left outer join dataset t2
        on t1.parent = t2.child
    left outer join dataset t3
        on t2.parent = t3.child
    left outer join dataset t4
        on t3.parent = t4.parent
    left outer join dataset t5
        on t4.child = t5.parent
    left outer join dataset t6
        on t5.child = t6.parent
    left outer join dataset t7
        on t6.child = t7.parent
    left outer join dataset t8
        on t7.child = t8.parent
    left outer join dataset t9
        on t8.child = t9.parent
    where t.child like 'table_name___final'
        and case when t5.child like 'select_clause%' or t5.child like 'from_clause%' then t5.parent end  is not null
    order by 2,3,4,5
)

 select * from test11
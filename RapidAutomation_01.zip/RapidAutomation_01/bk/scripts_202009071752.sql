with ctx_ruleid_rulename as (
    select distinct
           t.attr_ctx as ctx,
           t1.rule_name
    from xref_ctx_id t
    left outer join xref_rule t1
        on t.attr_rule_id = t1.rule_id
),

parent_child_mappingInfo as (
    select t1.rule_name as parent_rule_name,
		   t.attr_parent as parent_ctx,
           t2.rule_name as child_rule_name,
		   t.attr_child as child_ctx,
           t.attr_flg as flg,
           t.attr_value as text
    from test_liye_0828 t
    left outer join ctx_ruleid_rulename t1
        on substr(t.attr_parent,0,instr(t.attr_parent,'_') - 1) = t1.ctx
    left outer join ctx_ruleid_rulename t2
        on substr(t.attr_child,0,instr(t.attr_child,'_') - 1) = t2.ctx
),

parentRule_numbering as (
    select t.parent_rule_name,
           t.parent_ctx,
           t.flg,
           row_number()over(partition by t.parent_rule_name,t.flg order by to_number(substr(t.parent_ctx,instr(t.parent_ctx,'_',1,1) + 1,instr(t.parent_ctx,'_',1,2) - instr(t.parent_ctx,'_',1,1) - 1))) as parent_num
    from (
        select distinct
              t.parent_rule_name,
              t.parent_ctx,
              t.flg
        from parent_child_mappingInfo t
    ) t
),

childRule_numbering as (
    select  t.child_rule_name,
            t.child_ctx,
            t.flg,
            row_number()over(partition by t.child_rule_name,t.flg order by to_number(substr(t.child_ctx,instr(t.child_ctx,'_',1,1) + 1,instr(t.child_ctx,'_',1,2) - instr(t.child_ctx,'_',1,1) - 1))) as child_num
    from (
        select distinct
              t.child_rule_name,
              t.child_ctx,
              t.flg
        from parent_child_mappingInfo t
    ) t
),

dataset as (
    select t.parent_rule_name || '_' || parent_num || '_' ||t.flg as parent_rule_name,
           t.child_rule_name || '_' || child_num || '_' ||t.flg as child_rule_name,
           t.text
    from parent_child_mappingInfo t
    left outer join parentRule_numbering t1
        on t.parent_ctx = t1.parent_ctx
    left outer join childRule_numbering t2
        on t.child_ctx = t2.child_ctx
),

from_query_script_list as (
    select *
    from dataset t
    where t.child_rule_name like 'from_query_script_list%_temp'
),

dataset01 as (
    select t.child_rule_name,
           listagg(t.from_query_script_list, '') within group (order by '1') as from_query_script_list,
           listagg(t.table_alias, '') within group (order by '1') as table_alias
    from (
       select t.child_rule_name,
            case when t1.child_rule_name like 'from_query_script_list_%_temp' then t1.child_rule_name end as from_query_script_list,
            case when t1.child_rule_name like 'table_alias_%_temp' then t1.text end as table_alias
        from dataset t
        left outer join dataset t1
            on t.child_rule_name = t1.parent_rule_name
        where t.child_rule_name like 'from_clause_%_temp'
            and (t1.child_rule_name like 'from_query_script_list_%_temp' or t1.child_rule_name like 'table_alias_%_temp')
    ) t
    group by t.child_rule_name

),

dataset02 as (
select t1.parent_rule_name,
        case when t2.child_rule_name like 'table_name_%_temp' then t2.text end as table_name,
        case when t3.child_rule_name like 'table_alias_%_temp' then t3.text end as table_alias

from dataset t
left outer join dataset t1
    on t.child_rule_name = t1.parent_rule_name
left outer join dataset t2
    on t1.child_rule_name = t2.parent_rule_name
left outer join dataset t3
    on t2.child_rule_name = t3.parent_rule_name
where t.child_rule_name like 'from_clause_%_temp'
    and t1.child_rule_name like 'table_name_list_%_temp'
    and t3.child_rule_name like 'table_alias_%_temp'

),

dataset03 as (
    select t1.parent_rule_name,
           t.*
    from (
        select * from dataset01
        union all
        select * from dataset02
    ) t
    left outer join dataset t1
        on t.child_rule_name = t1.child_rule_name
),

dataset04 as (
    select t.parent_rule_name,
           t.child_rule_name,
           t.table_alias,
           listagg(t.field, '') within group (order by '1') as field,
           listagg(t.column_alias, '') within group (order by '1') as column_alias
    from (
        select t.parent_rule_name,
               t3.child_rule_name,
               t.table_alias,
               --t4.child_rule_name,
               --t4.text ,

               case when t4.child_rule_name like 'field_%_temp' then t4.text end as field,
               case when t4.child_rule_name like 'column_alias_%_temp' then t4.text end as column_alias
               --*
        from dataset03 t
        left outer join dataset t1
            on t.parent_rule_name = t1.parent_rule_name
        left outer join dataset t2
            on t1.child_rule_name = t2.parent_rule_name
        left outer join dataset t3
            on t2.child_rule_name = t3.parent_rule_name
        left outer join dataset t4
            on t3.child_rule_name = t4.parent_rule_name
        left outer join dataset t5
            on t4.child_rule_name = t5.parent_rule_name
        where t1.child_rule_name like 'select_clause_%_temp'
    ) t
    group by t.parent_rule_name,t.child_rule_name,t.table_alias
)

select t2.parent_rule_name,
       t.column_alias,
       t.field,
       t.table_alias,
       t1.from_query_script_list
from dataset04 t
left outer join dataset03 t1
    on t.parent_rule_name = t1.parent_rule_name
left outer join dataset t2
    on t.parent_rule_name = t2.child_rule_name
order by 1,2,3

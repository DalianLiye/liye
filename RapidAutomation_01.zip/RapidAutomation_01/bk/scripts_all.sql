with ctx_ruleid_rulename as (
    select distinct
           t.attr_ctx as ctx,
           t1.rule_name
    from xref_ctx_id t
    left outer join xref_rule t1
        on t.attr_rule_id = t1.rule_id
),

parent_child_mappinginfo as (
    select t1.rule_name as parent_rule_name,
		   t.attr_parent as parent_ctx,
           t2.rule_name as child_rule_name,
		   t.attr_child as child_ctx,
           t.attr_flg as flg,
           t.attr_value as text
    from test_liye_0828 t
    left outer join ctx_ruleid_rulename t1
        on substr(t.attr_parent,0,instr(t.attr_parent,'_') - 1) = t1.ctx
    left outer join ctx_ruleid_rulename t2
        on substr(t.attr_child,0,instr(t.attr_child,'_') - 1) = t2.ctx
),

parentrule_numbering as (
    select t.parent_rule_name,
           t.parent_ctx,
           t.flg,
           row_number()over(partition by t.parent_rule_name,t.flg order by to_number(substr(t.parent_ctx,instr(t.parent_ctx,'_',1,1) + 1,instr(t.parent_ctx,'_',1,2) - instr(t.parent_ctx,'_',1,1) - 1))) as parent_num
    from (
        select distinct
              t.parent_rule_name,
              t.parent_ctx,
              t.flg
        from parent_child_mappinginfo t
    ) t
),

childrule_numbering as (
    select  t.child_rule_name,
            t.child_ctx,
            t.flg,
            row_number()over(partition by t.child_rule_name,t.flg order by to_number(substr(t.child_ctx,instr(t.child_ctx,'_',1,1) + 1,instr(t.child_ctx,'_',1,2) - instr(t.child_ctx,'_',1,1) - 1))) as child_num
    from (
        select distinct
              t.child_rule_name,
              t.child_ctx,
              t.flg
        from parent_child_mappinginfo t
    ) t
),

dataset as (
    select t.parent_rule_name || '_' || parent_num || '_' ||t.flg as parent_rule_name,
           t.child_rule_name || '_' || child_num || '_' ||t.flg as child_rule_name,
           t.text,
		   t.flg
    from parent_child_mappinginfo t
    left outer join parentrule_numbering t1
        on t.parent_ctx = t1.parent_ctx
    left outer join childrule_numbering t2
        on t.child_ctx = t2.child_ctx
),

fromqueryscript_alias as (
    select t.r_query_script,
           t.r_from_clause,
		   t.flg,
           listagg(t.r_from_query_script_list, '') within group (order by '1') as r_from_query_script_list,
           listagg(t.table_alias, '') within group (order by '1') as table_alias
    from (
        select  t.parent_rule_name as r_query_script,
				t.child_rule_name as r_from_clause,
				t.flg,
				case
					when t1.child_rule_name like 'from_query_script_list_%' then t1.child_rule_name
				end as r_from_query_script_list,
				case
					when t1.child_rule_name like 'table_alias_%' then t1.text
				end as table_alias
        from dataset t
        left outer join dataset t1
            on t.child_rule_name = t1.parent_rule_name
			and t.flg = t1.flg
        where t.child_rule_name like 'from_clause_%'
            and (t1.child_rule_name like 'from_query_script_list_%'
                 or t1.child_rule_name like 'table_alias_%')
    ) t
    group by t.r_query_script,
             t.r_from_clause,
			 t.flg
),

tablename_alias as (
	select  t.parent_rule_name as r_query_script,
            t1.parent_rule_name as r_from_clause,
			t.flg,
			case
                when t2.child_rule_name like 'table_name_%' then t2.text
            end as table_name,
			case
                when t3.child_rule_name like 'table_alias_%' then t3.text
            end as table_alias
	from dataset t
	left outer join dataset t1
		on t.child_rule_name = t1.parent_rule_name
		and t.flg = t1.flg
	left outer join dataset t2
		on t1.child_rule_name = t2.parent_rule_name
		and t1.flg = t2.flg
	left outer join dataset t3
		on t2.child_rule_name = t3.parent_rule_name
		and t2.flg = t3.flg
	where t.child_rule_name like 'from_clause_%'
		and t1.child_rule_name like 'table_name_list_%'
		and t3.child_rule_name like 'table_alias_%'
),

fromqueryscript_tablename_alias as (
    select t.r_query_script,
           t.r_from_clause,
           t.r_from_query_script_list,
           t.table_alias,
		   t.flg
    from (
        select * from fromqueryscript_alias
        union all
        select * from tablename_alias
    ) t
),

select_clause_dtl as (
    select t.r_query_script,
           t.r_colum,
           t.table_alias,
		   t.flg,
           listagg(t.field, '') within group (order by '1') as field,
           listagg(t.column_alias, '') within group (order by '1') as column_alias,
           row_number()over(partition by t.r_query_script order by to_number(substr(r_colum,instr(r_colum,'_',1,1) + 1,instr(r_colum,'_',1,2) - instr(r_colum,'_',1,1) - 1))) as column_order_num

    from (
        select t.r_query_script,
               t3.child_rule_name as r_colum,
               t.table_alias,
			   t.flg,
               case when t4.child_rule_name like 'field_%' then t4.text end as field,
               case when t4.child_rule_name like 'column_alias_%' then t4.text end as column_alias
        from fromqueryscript_tablename_alias t
        left outer join dataset t1
            on t.r_query_script = t1.parent_rule_name
        left outer join dataset t2
            on t1.child_rule_name = t2.parent_rule_name
        left outer join dataset t3
            on t2.child_rule_name = t3.parent_rule_name
        left outer join dataset t4
            on t3.child_rule_name = t4.parent_rule_name
        left outer join dataset t5
            on t4.child_rule_name = t5.parent_rule_name
        where t1.child_rule_name like 'select_clause_%'
    ) t
    group by t.r_query_script,
             t.r_colum,
             t.table_alias,
			 t.flg
),

temporary_table as (
    select t.parent_rule_name,
           t.child_rule_name,
           t.text,
           t.flg
    from dataset t
    where t.child_rule_name like 'temporary_table_name%'
),

dataset_metrics as (
    select distinct
           t3.parent_rule_name as tt1,
           case when t3.parent_rule_name like 'with_clause_%' then t4.text else  t2.parent_rule_name end as tt,
           t2.parent_rule_name,
           t2.child_rule_name,
           t.column_order_num,
           t.column_alias,
           t.field,
           t.table_alias,
           t1.r_from_query_script_list,
           t.flg
    from select_clause_dtl t
    left outer join fromqueryscript_tablename_alias t1
        on t.r_query_script = t1.r_query_script
        and t.flg = t1.flg
    left outer join dataset t2
        on t.r_query_script = t2.child_rule_name
        and t.flg = t2.flg
    left outer join dataset t3
        on t2.parent_rule_name = t3.child_rule_name
        and t2.flg = t3.flg
    left outer join temporary_table t4
        on t3.parent_rule_name = t4.parent_rule_name
    order by 9 desc,1,2,3,4,5,6,7,8
),

temp as (
    select
           t.tt as query,
           t.child_rule_name as sub_query,
           t.column_order_num,
           t.column_alias,
           t.field,
           t.table_alias,
           t.r_from_query_script_list as source_query,
           t.flg
    from dataset_metrics t
    order by 8 desc, 1,2,3,4,5,6,7
)

select distinct
       t.column_order_num,
       t.source_query as source_table,
       t.field as source_field
from (
    select t.*,
           prior t.field as source_field,
           prior t.source_query as source_table,
           connect_by_isleaf,
           connect_by_root t.query as query_target,
           connect_by_root t.sub_query as sub_query_target,
           connect_by_root t.field as field_target
    from temp t
    start with t.sub_query like 'query_script_%_final'
        and t.column_order_num in (1,2,3)
        and t.query like 'final_query_list_%_final'
    connect by prior t.source_query = t.query and prior t.COLUMN_ORDER_NUM = t.COLUMN_ORDER_NUM
) t
where t.connect_by_isleaf = 1
order by 1,2,3
select distinct
	   (select repository_name from opb_reposit_info) as repo,
	   case
			when a.object_subtype = 0 then 'FTP'
			when a.object_subtype = 101 then 'Oracle'
			when a.object_subtype = 104 then 'Sql Server'
			when a.object_subtype = 106 then 'ODBC'
			else 'NULL'
		end as cnx_type,
		a.object_name as connection_name,
		a.user_name as conn_user_name,
		a.connection_string as connect_string,
		case
			when b.attr_id = 10 then 'DB Name'
			when b.attr_id = 11 then 'Data Source Name'
			when b.attr_id = 12 then 'Connection Env SQL'
			when b.attr_id = 13 then 'Transaction Env SQL'
			when b.attr_id = 14 then 'Connection Retry Period'
	    end as cnx_value,
		b.attr_value,
		a.last_saved
from inf10_prd_pcrepo.opb_cnx a,
	 inf10_prd_pcrepo.opb_cnx_attr b
where a.object_id = b.object_id
order by 1,2,3,4

select distinct
	   c.subject_area,
	   b.workflow_name,
	   a.session_instance_name,
	   connection_name,
	   connect_string
from inf10_prd_pcrepo.rep_session_cnxs c,
	 inf10_prd_pcrepo.opb_cnx,
	 inf10_prd_pcrepo.rep_sess_log a,
	 inf10_prd_pcrepo.rep_wflow_run b
where c.connection_id= opb_cnx.object_id
	and c.session_id = a.session_id
	and a.workflow_id = b.workflow_id
	and connection_name in ('rapid_db')
order by 1,2
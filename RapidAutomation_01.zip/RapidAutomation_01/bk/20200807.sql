with final_d_table_alias_vs_r_table_alias as (
    select *
    from test_liye_0805 t
    where t.flg='final'
        and t.parents like 'table_alias%'
        and t.parents not like 'table_alias_table%'
),

final_r_table_alias_vs_r_field as (
    select *
    from test_liye_0805 t
    where t.flg='final'
        and t.children like 'table_alias%'
        and t.parents like 'field%'

),

final_d_field_vs_r_field as (
    select *
    from test_liye_0805 t
    where t.flg='final'
        and t.children not like 'table_alias%'
        and t.parents like 'field%'
),

final_r_field_vs_r_colum as (
    select *
    from test_liye_0805 t
    where t.flg='final'
        and t.children like 'field%'
        and t.parents like 'colum%'
),

final_r_table_name_list_vs_r_from_clause as (
    select *
    from test_liye_0805 t
    where t.flg='final'
        and t.children like 'table_name_list%'
        and t.parents like 'from_clause%'
),

final_r_table_name_vs_r_table_name_list as (
    select *
    from test_liye_0805 t
    where t.flg='final'
        and t.children like 'table_name%'
        and t.parents like 'table_name_list%'
),

final_d_table_name_vs_r_table_name as (
    select *
    from test_liye_0805 t
    where t.flg='final'
        and t.children not like 'table_alias_table%'
        and t.children not like 'table_name%'
        and t.parents like 'table_name%'
),

final_r_table_alias_table_vs_r_table_name as (
    select *
    from test_liye_0805 t
    where t.flg='final'
        and t.children like 'table_alias_table%'
        and t.parents like 'table_name%'
),

final_d_table_alias_table_vs_r_table_alias_table as (
    select *
    from test_liye_0805 t
    where t.flg='final'
        and t.parents like 'table_alias_table%'
),

final_r_colum_vs_r_colum_list as (
    select *
    from test_liye_0805 t
    where t.flg='final'
        and t.children like 'colum%'
        and t.parents like 'colum_list%'
),

final_r_colum_list_vs_r_select_clause as (
    select *
    from test_liye_0805 t
    where t.flg='final'
        and t.children like 'colum_list%'
        and t.parents like 'select_clause%'
),

final_r_from_clause_vs_r_query_script as (
    select *
    from test_liye_0805 t
    where t.flg='final'
        and t.children like 'from_clause%'
        and t.parents like 'query_script%'
),

final_r_select_clause_vs_r_query_script as (
    select *
    from test_liye_0805 t
    where t.flg='final'
        and t.children like 'select_clause%'
        and t.parents like 'query_script%'
),

final_r_query_script_vs_r_final_query_list as (
    select *
    from test_liye_0805 t
    where t.flg='final'
        and t.children like 'query_script%'
        and t.parents like 'final_query_list%'
),

final_r_final_query_list_vs_r_query_script_list as (
    select *
    from test_liye_0805 t
    where t.flg='final'
        and t.children like 'final_query_list%'
        and t.parents like 'query_script_list%'
),


d_table_alias_table_vs_r_table_alias_table as (
    select *
    from test_liye_0805 t
    where t.flg<>'final'
        and t.parents like 'table_alias_table%'
),

r_table_alias_table_vs_r_table_name as (
    select *
    from test_liye_0805 t
    where t.flg<>'final'
        and t.children like 'table_alias_table%'
        and t.parents like 'table_name%'
),

d_table_name_vs_r_table_name as (
    select *
    from test_liye_0805 t
    where t.flg<>'final'
        and t.children not like 'table_name%' and t.children not like 'table_alias_table%'
        and t.parents like 'table_name%'
),

r_table_name_vs_r_table_name_list as (
    select *
    from test_liye_0805 t
    where t.flg<>'final'
        and t.children like 'table_name%'
        and t.parents like 'table_name_list%'
),

r_table_name_list_vs_r_from_clause as (
    select *
    from test_liye_0805 t
    where t.flg<>'final'
        and t.children like 'table_name_list%'
        and t.parents like 'from_clause%'
),

d_field_vs_r_field as (
    select *
    from test_liye_0805 t
    where t.flg<>'final'
        and t.children not like 'table_alias%'
        and t.parents like 'field%'
),

d_table_alias_vs_r_table_alias as (
    select *
    from test_liye_0805 t
    where t.flg<>'final'
        --and t.children not like 'table_alias%'
        and t.parents like 'table_alias%'
        and t.parents not like 'table_alias_table%'
),

r_table_alias_vs_r_field as (
    select *
    from test_liye_0805 t
    where t.flg<>'final'
        and t.children like 'table_alias%'
        and t.parents like 'field%'
),

d_column_name_vs_r_column_alias as (
    select *
    from test_liye_0805 t
    where t.flg<>'final'
        --and t.children like 'table_alias%'
        and t.parents like 'column_alias%'
),

r_column_alias_vs_r_colum as (
    select *
    from test_liye_0805 t
    where t.flg<>'final'
        and t.children like 'column_alias%'
        and t.parents like 'colum%'
),

r_field_vs_r_colum as (
    select *
    from test_liye_0805 t
    where t.flg<>'final'
        and t.children like 'field%'
        and t.parents like 'colum%'
),

r_colum_vs_r_colum_list as (
    select *
    from test_liye_0805 t
    where t.flg<>'final'
        and t.children like 'colum%'
        and t.parents like 'colum_list%'
),

r_colum_list_vs_r_select_clause as (
    select *
    from test_liye_0805 t
    where t.flg<>'final'
        and t.children like 'colum_list%'
        and t.parents like 'select_clause%'
),

r_from_clause_vs_r_query_script as (
    select *
    from test_liye_0805 t
    where t.flg<>'final'
        and t.children like 'from_clause%'
        and t.parents like 'query_script%'
),

r_select_clause_vs_r_query_script as (
    select *
    from test_liye_0805 t
    where t.flg<>'final'
        and t.children like 'select_clause%'
        and t.parents like 'query_script%'
),

r_query_script_vs_r_from_query_script_list as (
    select *
    from test_liye_0805 t
    where t.flg<>'final'
        and t.children like 'query_script%'
        and t.parents like 'from_query_script_list%'
),

r_table_alias_table_vs_r_from_clause as (
    select *
    from test_liye_0805 t
    where t.flg<>'final'
        and t.children like 'table_alias_table%'
        and t.parents like 'from_clause%'

),

r_from_query_script_list_vs_r_from_clause as (
    select *
    from test_liye_0805 t
    where t.flg<>'final'
        and t.children like 'from_query_script_list%'
        and t.parents like 'from_clause%'
),

r_query_script_vs_r_with_query_script_list as (
    select *
    from test_liye_0805 t
    where t.flg<>'final'
        and t.children like 'query_script%'
        and t.parents like 'with_query_script_list%'
),

d_temporary_table_name_vs_r_temporary_table_name as (
    select *
    from test_liye_0805 t
    where t.flg<>'final'
        and t.parents like 'temporary_table_name%'
),

r_with_query_script_list_vs_r_with_clause as (
    select *
    from test_liye_0805 t
    where t.flg<>'final'
        and t.children like 'with_query_script_list%'
        and t.parents like 'with_clause%'
),

r_temporary_table_name_vs_r_with_clause as (
    select *
    from test_liye_0805 t
    where t.flg<>'final'
        and t.children like 'temporary_table_name%'
        and t.parents like 'with_clause%'
),

r_with_clause_vs_r_with_clause_list as (
    select *
    from test_liye_0805 t
    where t.flg<>'final'
        and t.children like 'with_clause%'
        and t.parents like 'with_clause_list%'
),

r_final_query_list_vs_r_query_script_list as (
    select *
    from test_liye_0805 t
    where t.flg<>'final'
        and t.children like 'final_query_list%'
        and t.parents like 'query_script_list%'
),

r_with_clause_list_vs_r_query_script_list as (
    select *
    from test_liye_0805 t
    where t.flg<>'final'
        and t.children like 'with_clause_list%'
        and t.parents like 'query_script_list%'
),

r_query_script_list_vs_r_scripts as (
    select *
    from test_liye_0805 t
    where t.flg<>'final'
        and t.children like 'query_script_list%'
        and t.parents like 'scripts%'
)

-----------------------------------
select *
from final_d_table_alias_vs_r_table_alias t
left outer join final_r_table_alias_vs_r_field t1
    on t.parents = t1.children
left outer join final_d_field_vs_r_field t2
    on t1.parents = t2.parents
left outer join final_r_field_vs_r_colum t3
    on t2.parents = t3.children
left outer join final_r_colum_vs_r_colum_list t4
    on t3.parents = t4.children
left outer join final_r_colum_list_vs_r_select_clause t5
    on t4.parents = t5.children
left outer join final_r_select_clause_vs_r_query_script t6
    on t5.parents = t6.children
left outer join final_r_from_clause_vs_r_query_script t7
    on t6.parents = t7.parents
left outer join final_r_table_name_list_vs_r_from_clause t8
    on t7.children = t8.parents
left outer join final_r_table_name_vs_r_table_name_list t9
    on t8.children = t9.parents
left outer join final_d_table_name_vs_r_table_name t10
    on t9.children = t10.parents





/*
select t.children as d_field,
       t.parents as r_field
from final_d_field_vs_r_field t
*/
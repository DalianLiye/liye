with workflow_task as (
	select distinct
			t.attr_name as workflow_name,
			nvl(t2.attr_taskname,t1.attr_fromtask) as from_task,
			nvl(t3.attr_taskname,t1.attr_totask) as to_task,
			substr(nvl(t5.attr_value,t7.attr_value),instr(nvl(t5.attr_value,t7.attr_value) , ' ' ,-1,1)+1) as next_workflow
	from infa_node_workflow t
     left outer join infa_node_workflowlink t1
        on  t.attr_self_range_start = t1.attr_parent_range_start
        and t.attr_self_range_end = t1.attr_parent_range_end
        and t.attr_node_name = t1.attr_parent_node_name
    left outer join infa_node_taskinstance t2
        on  t.attr_self_range_start = t2.attr_parent_range_start
        and t.attr_self_range_end = t2.attr_parent_range_end
        and t.attr_node_name = t2.attr_parent_node_name
        and (t1.attr_fromtask = t2.attr_name)
    left outer join infa_node_taskinstance t3
        on  t.attr_self_range_start = t3.attr_parent_range_start
        and t.attr_self_range_end = t3.attr_parent_range_end
        and t.attr_node_name = t3.attr_parent_node_name
        and t1.attr_totask = t3.attr_name
    left outer join infa_node_task t4
        on  t.attr_self_range_start = t4.attr_parent_range_start
        and t.attr_self_range_end = t4.attr_parent_range_end
        and t3.attr_taskname = t4.attr_name
        and lower(t4.attr_type) = 'command'
    left outer join INFA_NODE_VALUEPAIR t5
        on  t4.attr_self_range_start = t5.attr_parent_range_start
        and t4.attr_self_range_end = t5.attr_parent_range_end
    left outer join infa_node_task t6
        on t3.attr_taskname = t6.attr_name
        and lower(t6.attr_type) = 'command'
    left outer join INFA_NODE_VALUEPAIR t7
        on  t6.attr_self_range_start = t7.attr_parent_range_start
        and t6.attr_self_range_end = t7.attr_parent_range_end
	order by 1, 2, 3
),


worklet_task as (
	select distinct
			t.attr_name as worklet_name,
			t2.attr_taskname as from_task,
			t3.attr_taskname as to_task
	from infa_node_worklet t
	left outer join infa_node_workflowlink t1
		on t.attr_self_range_start = t1.attr_parent_range_start
		and t.attr_self_range_end = t1.attr_parent_range_end
		and t.attr_node_name = t1.attr_parent_node_name
	left outer join infa_node_taskinstance t2
		on t1.attr_fromtask = t2.attr_name
	left outer join infa_node_taskinstance t3
		on t1.attr_totask = t3.attr_name
	order by 1, 2, 3
),

session_mapping as (
	select t.attr_name as session_name,
		   t.attr_mappingname as mapping_name
	from infa_node_session t
	order by 1, 2
),

mapping_mapplet as (
	select distinct
			t.attr_name as mapping_name,
			t1.attr_transformation_name as mapplet_name
	from infa_node_mapping t
	left outer join infa_node_instance t1
		on  t.attr_self_range_start = t1.attr_parent_range_start
		and t.attr_self_range_end = t1.attr_parent_range_end
		and t.attr_node_name = t1.attr_parent_node_name
	where lower(t1.attr_type) in ('mapplet')
	order by 1, 2
),

mapping_source as (
    select distinct
           t.attr_name as mapping_name,
           t1.attr_transformation_name as source_name,
           t2.attr_name as transformation_name
    from infa_node_mapping t
    left outer join infa_node_instance t1
        on t.attr_self_range_start = t1.attr_parent_range_start
        and t.attr_self_range_end = t1.attr_parent_range_end
        and lower(t1.attr_type) in ('source')
        and lower(t1.attr_dbdname) <> 'flatfile'
    left outer join infa_node_instance t2
        on t.attr_self_range_start = t2.attr_parent_range_start
        and t.attr_self_range_end = t2.attr_parent_range_end
        and lower(t2.attr_transformation_type) in ('source qualifier')
    left outer join infa_node_associated_source_instance t3
        on t2.attr_self_range_start = t3.attr_parent_range_start
        and t2.attr_self_range_end = t3.attr_parent_range_end
	left outer join infa_node_source t4
		on t1.attr_transformation_name = t4.attr_name
	where t1.attr_transformation_name is not null
		and lower(t4.attr_databasetype) <> 'flat file'
		and t1.attr_name = t3.attr_name
	order by 1, 2
),

mapping_source_lookup as (
		select distinct
		 t.attr_name as mapping_name,
		 nvl(nvl(t4.attr_value, t3.attr_value),nvl(t6.attr_value,t7.attr_value)) as source_name,
		 t1.attr_transformation_name as transformation_name
	from infa_node_mapping t
	left outer join infa_node_instance t1
		on t.attr_self_range_start = t1.attr_parent_range_start
		and t.attr_self_range_end = t1.attr_parent_range_end
		and lower(t1.attr_transformation_type) = 'lookup procedure'
	left outer join infa_node_transformation t2
		on  t.attr_self_range_start = t2.attr_parent_range_start
		and t.attr_self_range_end = t2.attr_parent_range_end
		and t1.attr_transformation_name = t2.attr_name
	left outer join infa_node_tableattribute_parse t3
		on t2.attr_self_range_start = t3.attr_parent_range_start
		and t2.attr_self_range_end = t3.attr_parent_range_end
		and lower(t3.attr_name) in ('lookup table name')
	left outer join infa_node_tableattribute_parse t4
		on t2.attr_self_range_start = t4.attr_parent_range_start
		and t2.attr_self_range_end = t4.attr_parent_range_end
		and lower(t4.attr_name) in ('lookup sql override')
    left outer join infa_node_transformation t5
        on lower(t5.attr_reusable) = 'yes'
        and t1.attr_transformation_name = t5.attr_name
    left outer join infa_node_tableattribute_parse t6
		on t5.attr_self_range_start = t6.attr_parent_range_start
		and t5.attr_self_range_end = t6.attr_parent_range_end
		and lower(t6.attr_name) in ('lookup table name')
    left outer join infa_node_tableattribute_parse t7
		on t5.attr_self_range_start = t7.attr_parent_range_start
		and t5.attr_self_range_end = t7.attr_parent_range_end
		and lower(t7.attr_name) in ('lookup sql override')
	where t3.attr_value is not null
		or t4.attr_value is not null
		or t6.attr_value is not null
		or t7.attr_value is not null
	order by 1, 2
),

mapping_source_flatfile as (
	select distinct
		   t.mapping_name,
		   replace (xmlagg (xmlparse (content '/' || flat_file_source wellformed) order by flat_file_source),'//','/') as flat_file_source
	from
	(
		select distinct
			 t.attr_name as session_name,
			 t.attr_mappingname as mapping_name,
			 case
				 when lower(t2.attr_name) in ('source file directory', 'source filename') then t2.attr_value else ''
			 end as flat_file_source
		from infa_node_session t
		left outer join infa_node_sessionextension t1
			on t.attr_self_range_start = t1.attr_parent_range_start
			and t.attr_self_range_end = t1.attr_parent_range_end
			and t.attr_node_name = t1.attr_parent_node_name
		left outer join infa_node_attribute_parse t2
			on t1.attr_self_range_start = t2.attr_parent_range_start
			and t1.attr_self_range_end = t2.attr_parent_range_end
			and t1.attr_node_name = t2.attr_parent_node_name
	) t
	where t.flat_file_source is not null
	group by t.session_name,
			 t.mapping_name
	order by 1, 2
),

mapping_source_procedure as (
	select distinct
			t.attr_name as mapping_name,
			t2.attr_value as source_name,
			t3.attr_value as sp_name
	from infa_node_mapping t
	left outer join infa_node_transformation t1
		on t.attr_self_range_start = t1.attr_parent_range_start
		and t.attr_self_range_end = t1.attr_parent_range_end
		and lower(t1.attr_type) = 'stored procedure'
	left outer join infa_node_tableattribute_parse t2
		on t1.attr_self_range_start = t2.attr_parent_range_start
		and t1.attr_self_range_end = t2.attr_parent_range_end
		and lower(t2.attr_name) in ('stored procedure name')
	left outer join infa_node_tableattribute_parse t3
		on t1.attr_self_range_start = t3.attr_parent_range_start
		and t1.attr_self_range_end = t3.attr_parent_range_end
		and lower(t3.attr_name) in ('Connection Information')
	where t2.attr_value is not null
		and lower(t2.attr_comment) = 'source'
	order by 1, 2
),

mapping_source_sqlquery as (
    select distinct
			t.attr_name as mapping_name,
			t2.attr_value as source_name,
			t1.attr_name as transformation_name
    from infa_node_mapping t
	left outer join infa_node_transformation t1
		on t.attr_self_range_start = t1.attr_parent_range_start
		and t.attr_self_range_end = t1.attr_parent_range_end
		and lower(t1.attr_type) = 'source qualifier'
	left outer join infa_node_tableattribute_parse t2
		on t1.attr_self_range_start = t2.attr_parent_range_start
		and t1.attr_self_range_end = t2.attr_parent_range_end
		and lower(t2.attr_name) in ('sql query')
    where t2.attr_value is not null
    order by 1, 2
),

mapplet_source_lookup as (
    select distinct
         t.attr_name  as mapplet_name,
         nvl(nvl(t4.attr_value, t3.attr_value),nvl(t7.attr_value, t6.attr_value)) as source_name,
         t.attr_name || '.' || t1.attr_transformation_name as transformation_name
    from infa_node_mapplet t
	left outer join infa_node_instance t1
		on t.attr_self_range_start = t1.attr_parent_range_start
		and t.attr_self_range_end = t1.attr_parent_range_end
		and lower(t1.attr_transformation_type) = 'lookup procedure'
	left outer join infa_node_transformation t2
		on t1.attr_transformation_name = t2.attr_name
        and t.attr_self_range_start = t2.attr_parent_range_start
        and t.attr_self_range_end = t2.attr_parent_range_end
	left outer join infa_node_tableattribute_parse t3
		on t2.attr_self_range_start = t3.attr_parent_range_start
		and t2.attr_self_range_end = t3.attr_parent_range_end
		and lower(t3.attr_name) in ('lookup table name')
	left outer join infa_node_tableattribute_parse t4
		on t2.attr_self_range_start = t4.attr_parent_range_start
		and t2.attr_self_range_end = t4.attr_parent_range_end
		and lower(t4.attr_name) in ('lookup sql override')

	left outer join infa_node_transformation t5
		on t1.attr_transformation_name = t5.attr_name
        and lower(t5.attr_reusable) = 'yes'
    left outer join infa_node_tableattribute_parse t6
		on t5.attr_self_range_start = t6.attr_parent_range_start
		and t5.attr_self_range_end = t6.attr_parent_range_end
		and lower(t6.attr_name) in ('lookup table name')
	left outer join infa_node_tableattribute_parse t7
		on t5.attr_self_range_start = t7.attr_parent_range_start
		and t5.attr_self_range_end = t7.attr_parent_range_end
		and lower(t7.attr_name) in ('lookup sql override')

    where nvl(nvl(t4.attr_value, t3.attr_value),nvl(t7.attr_value, t6.attr_value)) is not null
    order by 1, 2
),


mapping_source_all as (
	select distinct
			t.mapping_name,
			nvl(t1.source_name, t.source_name) as source_name,
			t.transformation_name
	from mapping_source  t
	left outer join mapping_source_sqlquery t1
		on t.mapping_name = t1.mapping_name
        and t.transformation_name = t1.transformation_name

	union all

	select t.mapping_name,
		   t.SOURCE_NAME,
		   t.transformation_name as transformation_name
	from mapping_source_lookup t

	union all

	select t.MAPPING_NAME,
		   t.FLAT_FILE_SOURCE,
		   'flat file' as transformation_name
	from mapping_source_flatfile t

	union all

	select t.mapping_name,
		   t1.source_name,
		   t1.transformation_name
	from mapping_mapplet  t
	left outer join mapplet_source_lookup t1
		on t.mapplet_name = t1.mapplet_name
	where t1.source_name is not null

	union all

	select t.mapping_name,
		   t.source_name,
		   t.sp_name as transformation_name
	from mapping_source_procedure t
),

mapping_target_procedure as (
	select distinct
			t.attr_name as mapping_name,
			t2.attr_value as target_name,
			t3.attr_value as transformation_name
	from infa_node_mapping t
	left outer join infa_node_transformation t1
		on t.attr_self_range_start = t1.attr_parent_range_start
		and t.attr_self_range_end = t1.attr_parent_range_end
		and lower(t1.attr_type) = 'stored procedure'
	left outer join infa_node_tableattribute_parse t2
		on t1.attr_self_range_start = t2.attr_parent_range_start
		and t1.attr_self_range_end = t2.attr_parent_range_end
		and lower(t2.attr_name) in ('stored procedure name')
	left outer join infa_node_tableattribute_parse t3
		on t1.attr_self_range_start = t3.attr_parent_range_start
		and t1.attr_self_range_end = t3.attr_parent_range_end
		and lower(t3.attr_name) in ('connection Information')
	where t2.attr_value is not null
		and lower(t2.attr_comment) = 'target'
	order by 1, 2
),

mapping_target_flatfile as (
	select distinct
			t.mapping_name,
			replace(xmlagg (xmlparse (content '/' || flat_file_target wellformed) order by flat_file_target),'//','/') as flat_file_target
	from
	(
		select distinct
			 t.attr_name as session_name,
			 t.attr_mappingname as mapping_name,
			 case
				 when lower(t2.attr_name) in ('output file directory', 'output filename') then t2.attr_value else ''
			 end as flat_file_target
		from infa_node_session t
		left outer join infa_node_sessionextension t1
			on t.attr_self_range_start = t1.attr_parent_range_start
			and t.attr_self_range_end = t1.attr_parent_range_end
			and t.attr_node_name = t1.attr_parent_node_name
		left outer join infa_node_attribute_parse t2
			on t1.attr_self_range_start = t2.attr_parent_range_start
			and t1.attr_self_range_end = t2.attr_parent_range_end
			and t1.attr_node_name = t2.attr_parent_node_name
	) t
	where t.flat_file_target is not null
	group by t.session_name,
			 t.mapping_name
	order by 1, 2
),


mapping_target_all as (
	select distinct
		t.attr_name as mapping_name,
		t1.attr_transformation_name as target_name,
		t1.attr_name as transformation_name
	from infa_node_mapping  t
	left outer join infa_node_instance t1
		on t.attr_self_range_start = t1.attr_parent_range_start
		and t.attr_self_range_end = t1.attr_parent_range_end
		and t.attr_node_name = t1.attr_parent_node_name
		and lower(t1.attr_type) in ('target')
	left outer join infa_node_target t2
		on t1.attr_transformation_name = t2.attr_name
	where lower(t2.attr_databasetype) <> 'flat file'

	union all

	select t.mapping_name,
		   t.target_name,
		   t.transformation_name
	from mapping_target_procedure t

	union all

	select t.MAPPING_NAME,
		   t.FLAT_FILE_TARGET,
		   '' as transformation_name
	from mapping_target_flatfile t
),

view_parse_cnt as (
    select t.view_name,
           1 as cnt
    from (
        select distinct t.view_name
        from view_parse t
    ) t

    union all

    select t.table_name,
          1 as cnt
    from (
        select distinct t.table_name
        from view_parse t
    ) t
),

view_parse_sum as (
    select t.view_name,
           sum(t.cnt) as  cnt
    from view_parse_cnt t
    group by view_name
    order by 2 desc
),

view_parse_result as (
    select distinct
            t.view_name_final,
            t.table_name
    from (
        select t.*,
               connect_by_root t.view_name as view_name_final
        from view_parse t
        start with t.view_name in (select distinct view_name from view_parse_sum where cnt=1)
        connect by prior t.table_name = t.view_name
    ) t
    where t.table_name not in (select distinct view_name from view_parse)
    order by 1,2
),

connection_info as (
    select t.attr_mappingname as mapping_name,
           t1.attr_transformationtype as transformationtype,
           t1.attr_sinstancename as sinstancename,
           t2.attr_connectionname as connectionname,
           t2.attr_connectionsubtype as connectionsubtype
    from infa_node_session t
    left outer join infa_node_sessionextension t1
        on t.attr_self_range_start = t1.attr_parent_range_start
        and t.attr_self_range_end = t1.attr_parent_range_end
    left outer join infa_node_connectionreference t2
        on t1.attr_self_range_start = t2.attr_parent_range_start
        and t1.attr_self_range_end = t2.attr_parent_range_end
),

base as (
    select distinct
           t.workflow_name,
           t.from_task as from_task_workflow,
           t.to_task as to_task_workflow,
		   t.next_workflow,
           t1.worklet_name as worklet_name,
           t1.from_task as from_task_worklet,
           t1.to_task as to_task_worklet,
           t2.session_name,
           t2.mapping_name,
           t3.mapplet_name,
           t4.source_name,
           t4.transformation_name as source_transformation_name,
           t5.target_name,
           t5.transformation_name as target_transformation_name
    from workflow_task t
    left outer join worklet_task t1
        on t.to_task = t1.worklet_name
    left outer join session_mapping t2
        on t.to_task = t2.session_name
        or t1.to_task = t2.session_name
    left outer join mapping_mapplet t3
        on t2.mapping_name = t3.mapping_name
    left outer join mapping_source_all t4
        on t2.mapping_name = t4.mapping_name
    left outer join mapping_target_all t5
        on t2.mapping_name = t5.mapping_name
    order by 1,2,3,4,5,6,7,8,9,10,11
),

base01 as (
    select distinct
       t.workflow_name,
       t.from_task_workflow,
       t.to_task_workflow,
	   t.next_workflow,
       t.worklet_name,
       t.from_task_worklet,
       t.to_task_worklet,
       t.session_name,
       t.mapping_name,
       t.mapplet_name,
       t.source_name,
       t.source_transformation_name,
       t1.table_name,
       t.target_name,
       t.target_transformation_name
    from base t
    left outer join view_parse_result t1
        on upper(t.source_name) = upper(t1.view_name_final)
    order by 1,2,3,4,5,6,7,8,9,10,11,12
),


base02 as (
    select distinct
       t.workflow_name,
       t.from_task_workflow,
       t.to_task_workflow,
	   t.next_workflow,
       t.worklet_name,
       t.from_task_worklet,
       t.to_task_worklet,
       t.session_name,
       t.mapping_name,
       t.mapplet_name,
       t.source_name,
       t.source_transformation_name,
       t.table_name,
       t1.connectionname as source_connectionname,
       t1.connectionsubtype as source_connectionsubtype,
       t.target_name,
       t.target_transformation_name
    from base01 t
    left outer join connection_info t1
        on t.mapping_name = t1.mapping_name
        and t.source_transformation_name = t1.sinstancename
    order by 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15
)

select distinct
       t.workflow_name,
       t.from_task_workflow,
       t.to_task_workflow,
	   t.next_workflow,
       t.worklet_name,
       t.from_task_worklet,
       t.to_task_worklet,
       t.session_name,
       t.mapping_name,
       t.mapplet_name,
       t.source_name,
       t.table_name,
       t.source_connectionname,
       t.source_connectionsubtype,
       t.target_name,
       t1.connectionname as target_connectionname,
       t1.connectionsubtype as target_connectionsubtype
from base02 t
left outer join connection_info t1
    on t.mapping_name = t1.mapping_name
    and t.target_transformation_name = t1.sinstancename

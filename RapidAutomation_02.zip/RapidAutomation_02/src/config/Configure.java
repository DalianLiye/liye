package config;

import java.util.ArrayList;
import java.util.List;

public class Configure {

    final public static String BASE_DIR = "C:\\RapidAutomation\\";

    final public static String OUTPUT_DIR = BASE_DIR + "output\\";

    final public static String INPUT_DIR = BASE_DIR + "input\\";

    final public static String XML_INPUT_DIR = BASE_DIR + "input\\xml\\";

    final public static String DTD_INPUT_DIR = BASE_DIR + "input\\dtd\\";

    final public static String VIEW_DDL_INPUT_DIR = BASE_DIR + "input\\view\\";

    final public static String EXPR_INPUT_DIR = BASE_DIR + "input\\expr\\";

    final public static String XML_OUTPUT_DIR = BASE_DIR + "output\\xml\\";

    final public static String PLSQL_INPUT_DIR = BASE_DIR + "input\\plsql\\";

    final public static String PLSQL_DDL_OUTPUT_DIR = BASE_DIR + "output\\plsql\\ddl\\";

    final public static String VIEW_DDL_OUTPUT_DIR = BASE_DIR + "output\\view\\ddl\\";

    final public static String XML_PARSE_SCRIPT = BASE_DIR + "scripts\\script.sql";

    final public static int PARSE_TARGET_XML = 1;

    final public static int PARSE_TARGET_PLSQL_SQLQUERY = 2;

    final public static int PARSE_TARGET_PLSQL_SP = 3;

    final public static int PARSE_TARGET_PLSQL_PK = 4;

    final public static int PARSE_TARGET_DTD = 5;

    final public static int PARSE_TARGET_EXPR = 6;

    final public static int PARSE_TARGET_PLSQL_SQLQUERY_COLUMN = 7;

    final public static String ACCOUNT_DB = "C190471";

    public  static String PASSWORD_DB = "Qwe,202112Dec";

    final public static String URL_DB = "jdbc:oracle:thin:@ghlxdbrpd01.ap.lilly.com:1545:prd411";

    final public static int PLSQL_PARSE_TYPE_SQLQUERY = 1;

    final public static int PLSQL_PARSE_TYPE_SP = 2;

    final public static int PLSQL_PARSE_TYPE_PK = 3;

    final public static String JOB_NAME_CRM_RETAIL = "wf_手动执行_crm_retail.XML";

    final public static String DTD_FILE = "powrmart.dtd";

    final public static int SYNC_MODE_TRUNC_INSERT = 1; //先将目标表truncate，然后insert数据

    final public static int SYNC_MODE_DROP_INSERT = 2; //先将目标表drop，然后再创建表并insert数据

    final public static String EMPTY_STRING = "";

    final public static String SPACE_STRING = " ";


    //*********************************informatica********************************************
    final public static String[] WORKFLOWLIST = {
            "wf_stg_idc_data_daily"
            /*"wf_手动执行_礼信360_crm"
            "wf_cmds_others",
            "wf_idoctor_stc_daily",
            "wf_mingyuan_stc_daily",
            "wf_nba",
            "wf_pbrc_monthly",
            "wf_push_imeeting_tlmap",
            "wf_weekly12345_cst_survey",
            "wf_weekly12345_组织架构和权限",
            "wf_weekly1_ipatient_dashboard",
            "wf_手动执行_core_team_listing",
            "wf_手动执行_crm_metrics_monthly",
            "wf_手动执行_idoctor_touch_point",
            "wf_手动执行_moe_spp",
            "wf_手动执行_mr_cpa",
            "wf_手动执行_sales_daily_ratio",
            "wf_手动执行_spp_ka",
            "wf_手动执行_spp_sales",
            "wf_手动执行_spp_新架构同期比",
            "wf_手动执行_stg_scorecard",
            "wf_手动执行_td",
            "wf_手动执行_td_by_brand",
            "wf_手动执行_verz_metrics_monthly",
            "wf_手动执行_礼信360_crm",
            "wf_礼信360_meeting_idoctor",
            "wf_礼信360_spp"*/
    };





    final public static String[] CSV_ADDITIONAL_PARSE = {"INFA_NODE_TABLEATTRIBUTE.csv",
            "INFA_NODE_ATTRIBUTE.csv",
            "INFA_NODE_TRANSFORMFIELD.csv"};

    final public static String INFA_ACCOUNT = "c190471";

    final public static String INFA_PASSWORD = "Qwe,20211109Nov";

    final public static String INFA_REPO = "chn-pcrs-prd";

    final public static String INFA_DOM = "chn-dom-prd";

    final public static String INFA_SECURITY_DOM = "Users-Lilly";

    final public static String INFA_CLIENT_LOCAL_PATH = "C:\\Informatica\\10.4.1\\clients\\PowerCenterClient\\client\\bin\\";

}

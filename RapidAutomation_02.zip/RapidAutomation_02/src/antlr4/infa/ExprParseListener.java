// Generated from C:/Users/c190471/Desktop/RapidAutomation/src/antlr4/infa\ExprParse.g4 by ANTLR 4.8
package antlr4.infa;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link ExprParseParser}.
 */
public interface ExprParseListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#expression}.
	 * @param ctx the parse tree
	 */
	void enterExpression(ExprParseParser.ExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#expression}.
	 * @param ctx the parse tree
	 */
	void exitExpression(ExprParseParser.ExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#operator}.
	 * @param ctx the parse tree
	 */
	void enterOperator(ExprParseParser.OperatorContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#operator}.
	 * @param ctx the parse tree
	 */
	void exitOperator(ExprParseParser.OperatorContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#logical_expression}.
	 * @param ctx the parse tree
	 */
	void enterLogical_expression(ExprParseParser.Logical_expressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#logical_expression}.
	 * @param ctx the parse tree
	 */
	void exitLogical_expression(ExprParseParser.Logical_expressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#abort}.
	 * @param ctx the parse tree
	 */
	void enterAbort(ExprParseParser.AbortContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#abort}.
	 * @param ctx the parse tree
	 */
	void exitAbort(ExprParseParser.AbortContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#abs}.
	 * @param ctx the parse tree
	 */
	void enterAbs(ExprParseParser.AbsContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#abs}.
	 * @param ctx the parse tree
	 */
	void exitAbs(ExprParseParser.AbsContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#add_to_date}.
	 * @param ctx the parse tree
	 */
	void enterAdd_to_date(ExprParseParser.Add_to_dateContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#add_to_date}.
	 * @param ctx the parse tree
	 */
	void exitAdd_to_date(ExprParseParser.Add_to_dateContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#aes_decrypt}.
	 * @param ctx the parse tree
	 */
	void enterAes_decrypt(ExprParseParser.Aes_decryptContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#aes_decrypt}.
	 * @param ctx the parse tree
	 */
	void exitAes_decrypt(ExprParseParser.Aes_decryptContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#aes_encrypt}.
	 * @param ctx the parse tree
	 */
	void enterAes_encrypt(ExprParseParser.Aes_encryptContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#aes_encrypt}.
	 * @param ctx the parse tree
	 */
	void exitAes_encrypt(ExprParseParser.Aes_encryptContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#ascii}.
	 * @param ctx the parse tree
	 */
	void enterAscii(ExprParseParser.AsciiContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#ascii}.
	 * @param ctx the parse tree
	 */
	void exitAscii(ExprParseParser.AsciiContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#avg}.
	 * @param ctx the parse tree
	 */
	void enterAvg(ExprParseParser.AvgContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#avg}.
	 * @param ctx the parse tree
	 */
	void exitAvg(ExprParseParser.AvgContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#ceil}.
	 * @param ctx the parse tree
	 */
	void enterCeil(ExprParseParser.CeilContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#ceil}.
	 * @param ctx the parse tree
	 */
	void exitCeil(ExprParseParser.CeilContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#choose}.
	 * @param ctx the parse tree
	 */
	void enterChoose(ExprParseParser.ChooseContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#choose}.
	 * @param ctx the parse tree
	 */
	void exitChoose(ExprParseParser.ChooseContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#chr}.
	 * @param ctx the parse tree
	 */
	void enterChr(ExprParseParser.ChrContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#chr}.
	 * @param ctx the parse tree
	 */
	void exitChr(ExprParseParser.ChrContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#chrcode}.
	 * @param ctx the parse tree
	 */
	void enterChrcode(ExprParseParser.ChrcodeContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#chrcode}.
	 * @param ctx the parse tree
	 */
	void exitChrcode(ExprParseParser.ChrcodeContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#compress}.
	 * @param ctx the parse tree
	 */
	void enterCompress(ExprParseParser.CompressContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#compress}.
	 * @param ctx the parse tree
	 */
	void exitCompress(ExprParseParser.CompressContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#concat}.
	 * @param ctx the parse tree
	 */
	void enterConcat(ExprParseParser.ConcatContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#concat}.
	 * @param ctx the parse tree
	 */
	void exitConcat(ExprParseParser.ConcatContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#convert_base}.
	 * @param ctx the parse tree
	 */
	void enterConvert_base(ExprParseParser.Convert_baseContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#convert_base}.
	 * @param ctx the parse tree
	 */
	void exitConvert_base(ExprParseParser.Convert_baseContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#cos}.
	 * @param ctx the parse tree
	 */
	void enterCos(ExprParseParser.CosContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#cos}.
	 * @param ctx the parse tree
	 */
	void exitCos(ExprParseParser.CosContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#cosh}.
	 * @param ctx the parse tree
	 */
	void enterCosh(ExprParseParser.CoshContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#cosh}.
	 * @param ctx the parse tree
	 */
	void exitCosh(ExprParseParser.CoshContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#count}.
	 * @param ctx the parse tree
	 */
	void enterCount(ExprParseParser.CountContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#count}.
	 * @param ctx the parse tree
	 */
	void exitCount(ExprParseParser.CountContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#crc32}.
	 * @param ctx the parse tree
	 */
	void enterCrc32(ExprParseParser.Crc32Context ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#crc32}.
	 * @param ctx the parse tree
	 */
	void exitCrc32(ExprParseParser.Crc32Context ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#cume}.
	 * @param ctx the parse tree
	 */
	void enterCume(ExprParseParser.CumeContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#cume}.
	 * @param ctx the parse tree
	 */
	void exitCume(ExprParseParser.CumeContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#date_compare}.
	 * @param ctx the parse tree
	 */
	void enterDate_compare(ExprParseParser.Date_compareContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#date_compare}.
	 * @param ctx the parse tree
	 */
	void exitDate_compare(ExprParseParser.Date_compareContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#date_diff}.
	 * @param ctx the parse tree
	 */
	void enterDate_diff(ExprParseParser.Date_diffContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#date_diff}.
	 * @param ctx the parse tree
	 */
	void exitDate_diff(ExprParseParser.Date_diffContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#dec_base64}.
	 * @param ctx the parse tree
	 */
	void enterDec_base64(ExprParseParser.Dec_base64Context ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#dec_base64}.
	 * @param ctx the parse tree
	 */
	void exitDec_base64(ExprParseParser.Dec_base64Context ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#decode}.
	 * @param ctx the parse tree
	 */
	void enterDecode(ExprParseParser.DecodeContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#decode}.
	 * @param ctx the parse tree
	 */
	void exitDecode(ExprParseParser.DecodeContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#decompress}.
	 * @param ctx the parse tree
	 */
	void enterDecompress(ExprParseParser.DecompressContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#decompress}.
	 * @param ctx the parse tree
	 */
	void exitDecompress(ExprParseParser.DecompressContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#enc_base64}.
	 * @param ctx the parse tree
	 */
	void enterEnc_base64(ExprParseParser.Enc_base64Context ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#enc_base64}.
	 * @param ctx the parse tree
	 */
	void exitEnc_base64(ExprParseParser.Enc_base64Context ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#error}.
	 * @param ctx the parse tree
	 */
	void enterError(ExprParseParser.ErrorContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#error}.
	 * @param ctx the parse tree
	 */
	void exitError(ExprParseParser.ErrorContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterExp(ExprParseParser.ExpContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitExp(ExprParseParser.ExpContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#first}.
	 * @param ctx the parse tree
	 */
	void enterFirst(ExprParseParser.FirstContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#first}.
	 * @param ctx the parse tree
	 */
	void exitFirst(ExprParseParser.FirstContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#floor}.
	 * @param ctx the parse tree
	 */
	void enterFloor(ExprParseParser.FloorContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#floor}.
	 * @param ctx the parse tree
	 */
	void exitFloor(ExprParseParser.FloorContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#fv}.
	 * @param ctx the parse tree
	 */
	void enterFv(ExprParseParser.FvContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#fv}.
	 * @param ctx the parse tree
	 */
	void exitFv(ExprParseParser.FvContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#get_date_part}.
	 * @param ctx the parse tree
	 */
	void enterGet_date_part(ExprParseParser.Get_date_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#get_date_part}.
	 * @param ctx the parse tree
	 */
	void exitGet_date_part(ExprParseParser.Get_date_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#greatest}.
	 * @param ctx the parse tree
	 */
	void enterGreatest(ExprParseParser.GreatestContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#greatest}.
	 * @param ctx the parse tree
	 */
	void exitGreatest(ExprParseParser.GreatestContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#iif}.
	 * @param ctx the parse tree
	 */
	void enterIif(ExprParseParser.IifContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#iif}.
	 * @param ctx the parse tree
	 */
	void exitIif(ExprParseParser.IifContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#in}.
	 * @param ctx the parse tree
	 */
	void enterIn(ExprParseParser.InContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#in}.
	 * @param ctx the parse tree
	 */
	void exitIn(ExprParseParser.InContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#indexof}.
	 * @param ctx the parse tree
	 */
	void enterIndexof(ExprParseParser.IndexofContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#indexof}.
	 * @param ctx the parse tree
	 */
	void exitIndexof(ExprParseParser.IndexofContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#initcap}.
	 * @param ctx the parse tree
	 */
	void enterInitcap(ExprParseParser.InitcapContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#initcap}.
	 * @param ctx the parse tree
	 */
	void exitInitcap(ExprParseParser.InitcapContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#instr}.
	 * @param ctx the parse tree
	 */
	void enterInstr(ExprParseParser.InstrContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#instr}.
	 * @param ctx the parse tree
	 */
	void exitInstr(ExprParseParser.InstrContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#isnull}.
	 * @param ctx the parse tree
	 */
	void enterIsnull(ExprParseParser.IsnullContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#isnull}.
	 * @param ctx the parse tree
	 */
	void exitIsnull(ExprParseParser.IsnullContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#is_date}.
	 * @param ctx the parse tree
	 */
	void enterIs_date(ExprParseParser.Is_dateContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#is_date}.
	 * @param ctx the parse tree
	 */
	void exitIs_date(ExprParseParser.Is_dateContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#is_number}.
	 * @param ctx the parse tree
	 */
	void enterIs_number(ExprParseParser.Is_numberContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#is_number}.
	 * @param ctx the parse tree
	 */
	void exitIs_number(ExprParseParser.Is_numberContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#is_spaces}.
	 * @param ctx the parse tree
	 */
	void enterIs_spaces(ExprParseParser.Is_spacesContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#is_spaces}.
	 * @param ctx the parse tree
	 */
	void exitIs_spaces(ExprParseParser.Is_spacesContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#lag}.
	 * @param ctx the parse tree
	 */
	void enterLag(ExprParseParser.LagContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#lag}.
	 * @param ctx the parse tree
	 */
	void exitLag(ExprParseParser.LagContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#last}.
	 * @param ctx the parse tree
	 */
	void enterLast(ExprParseParser.LastContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#last}.
	 * @param ctx the parse tree
	 */
	void exitLast(ExprParseParser.LastContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#last_day}.
	 * @param ctx the parse tree
	 */
	void enterLast_day(ExprParseParser.Last_dayContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#last_day}.
	 * @param ctx the parse tree
	 */
	void exitLast_day(ExprParseParser.Last_dayContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#lead}.
	 * @param ctx the parse tree
	 */
	void enterLead(ExprParseParser.LeadContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#lead}.
	 * @param ctx the parse tree
	 */
	void exitLead(ExprParseParser.LeadContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#least}.
	 * @param ctx the parse tree
	 */
	void enterLeast(ExprParseParser.LeastContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#least}.
	 * @param ctx the parse tree
	 */
	void exitLeast(ExprParseParser.LeastContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#length}.
	 * @param ctx the parse tree
	 */
	void enterLength(ExprParseParser.LengthContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#length}.
	 * @param ctx the parse tree
	 */
	void exitLength(ExprParseParser.LengthContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#ln}.
	 * @param ctx the parse tree
	 */
	void enterLn(ExprParseParser.LnContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#ln}.
	 * @param ctx the parse tree
	 */
	void exitLn(ExprParseParser.LnContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#log}.
	 * @param ctx the parse tree
	 */
	void enterLog(ExprParseParser.LogContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#log}.
	 * @param ctx the parse tree
	 */
	void exitLog(ExprParseParser.LogContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#lookup}.
	 * @param ctx the parse tree
	 */
	void enterLookup(ExprParseParser.LookupContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#lookup}.
	 * @param ctx the parse tree
	 */
	void exitLookup(ExprParseParser.LookupContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#lower}.
	 * @param ctx the parse tree
	 */
	void enterLower(ExprParseParser.LowerContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#lower}.
	 * @param ctx the parse tree
	 */
	void exitLower(ExprParseParser.LowerContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#lpad}.
	 * @param ctx the parse tree
	 */
	void enterLpad(ExprParseParser.LpadContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#lpad}.
	 * @param ctx the parse tree
	 */
	void exitLpad(ExprParseParser.LpadContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#ltrim}.
	 * @param ctx the parse tree
	 */
	void enterLtrim(ExprParseParser.LtrimContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#ltrim}.
	 * @param ctx the parse tree
	 */
	void exitLtrim(ExprParseParser.LtrimContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#make_date_time}.
	 * @param ctx the parse tree
	 */
	void enterMake_date_time(ExprParseParser.Make_date_timeContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#make_date_time}.
	 * @param ctx the parse tree
	 */
	void exitMake_date_time(ExprParseParser.Make_date_timeContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#max}.
	 * @param ctx the parse tree
	 */
	void enterMax(ExprParseParser.MaxContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#max}.
	 * @param ctx the parse tree
	 */
	void exitMax(ExprParseParser.MaxContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#md5}.
	 * @param ctx the parse tree
	 */
	void enterMd5(ExprParseParser.Md5Context ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#md5}.
	 * @param ctx the parse tree
	 */
	void exitMd5(ExprParseParser.Md5Context ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#median}.
	 * @param ctx the parse tree
	 */
	void enterMedian(ExprParseParser.MedianContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#median}.
	 * @param ctx the parse tree
	 */
	void exitMedian(ExprParseParser.MedianContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#metaphone}.
	 * @param ctx the parse tree
	 */
	void enterMetaphone(ExprParseParser.MetaphoneContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#metaphone}.
	 * @param ctx the parse tree
	 */
	void exitMetaphone(ExprParseParser.MetaphoneContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#min}.
	 * @param ctx the parse tree
	 */
	void enterMin(ExprParseParser.MinContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#min}.
	 * @param ctx the parse tree
	 */
	void exitMin(ExprParseParser.MinContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#mod}.
	 * @param ctx the parse tree
	 */
	void enterMod(ExprParseParser.ModContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#mod}.
	 * @param ctx the parse tree
	 */
	void exitMod(ExprParseParser.ModContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#movingavg}.
	 * @param ctx the parse tree
	 */
	void enterMovingavg(ExprParseParser.MovingavgContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#movingavg}.
	 * @param ctx the parse tree
	 */
	void exitMovingavg(ExprParseParser.MovingavgContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#movingsum}.
	 * @param ctx the parse tree
	 */
	void enterMovingsum(ExprParseParser.MovingsumContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#movingsum}.
	 * @param ctx the parse tree
	 */
	void exitMovingsum(ExprParseParser.MovingsumContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#nper}.
	 * @param ctx the parse tree
	 */
	void enterNper(ExprParseParser.NperContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#nper}.
	 * @param ctx the parse tree
	 */
	void exitNper(ExprParseParser.NperContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#percentile}.
	 * @param ctx the parse tree
	 */
	void enterPercentile(ExprParseParser.PercentileContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#percentile}.
	 * @param ctx the parse tree
	 */
	void exitPercentile(ExprParseParser.PercentileContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#pmt}.
	 * @param ctx the parse tree
	 */
	void enterPmt(ExprParseParser.PmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#pmt}.
	 * @param ctx the parse tree
	 */
	void exitPmt(ExprParseParser.PmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#power}.
	 * @param ctx the parse tree
	 */
	void enterPower(ExprParseParser.PowerContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#power}.
	 * @param ctx the parse tree
	 */
	void exitPower(ExprParseParser.PowerContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#pv}.
	 * @param ctx the parse tree
	 */
	void enterPv(ExprParseParser.PvContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#pv}.
	 * @param ctx the parse tree
	 */
	void exitPv(ExprParseParser.PvContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#rand}.
	 * @param ctx the parse tree
	 */
	void enterRand(ExprParseParser.RandContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#rand}.
	 * @param ctx the parse tree
	 */
	void exitRand(ExprParseParser.RandContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#rate}.
	 * @param ctx the parse tree
	 */
	void enterRate(ExprParseParser.RateContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#rate}.
	 * @param ctx the parse tree
	 */
	void exitRate(ExprParseParser.RateContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#reg_extract}.
	 * @param ctx the parse tree
	 */
	void enterReg_extract(ExprParseParser.Reg_extractContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#reg_extract}.
	 * @param ctx the parse tree
	 */
	void exitReg_extract(ExprParseParser.Reg_extractContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#reg_match}.
	 * @param ctx the parse tree
	 */
	void enterReg_match(ExprParseParser.Reg_matchContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#reg_match}.
	 * @param ctx the parse tree
	 */
	void exitReg_match(ExprParseParser.Reg_matchContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#reg_replace}.
	 * @param ctx the parse tree
	 */
	void enterReg_replace(ExprParseParser.Reg_replaceContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#reg_replace}.
	 * @param ctx the parse tree
	 */
	void exitReg_replace(ExprParseParser.Reg_replaceContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#replacechr}.
	 * @param ctx the parse tree
	 */
	void enterReplacechr(ExprParseParser.ReplacechrContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#replacechr}.
	 * @param ctx the parse tree
	 */
	void exitReplacechr(ExprParseParser.ReplacechrContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#replacestr}.
	 * @param ctx the parse tree
	 */
	void enterReplacestr(ExprParseParser.ReplacestrContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#replacestr}.
	 * @param ctx the parse tree
	 */
	void exitReplacestr(ExprParseParser.ReplacestrContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#reverse}.
	 * @param ctx the parse tree
	 */
	void enterReverse(ExprParseParser.ReverseContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#reverse}.
	 * @param ctx the parse tree
	 */
	void exitReverse(ExprParseParser.ReverseContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#round}.
	 * @param ctx the parse tree
	 */
	void enterRound(ExprParseParser.RoundContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#round}.
	 * @param ctx the parse tree
	 */
	void exitRound(ExprParseParser.RoundContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#rpad}.
	 * @param ctx the parse tree
	 */
	void enterRpad(ExprParseParser.RpadContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#rpad}.
	 * @param ctx the parse tree
	 */
	void exitRpad(ExprParseParser.RpadContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#rtrim}.
	 * @param ctx the parse tree
	 */
	void enterRtrim(ExprParseParser.RtrimContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#rtrim}.
	 * @param ctx the parse tree
	 */
	void exitRtrim(ExprParseParser.RtrimContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#setcountvariable}.
	 * @param ctx the parse tree
	 */
	void enterSetcountvariable(ExprParseParser.SetcountvariableContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#setcountvariable}.
	 * @param ctx the parse tree
	 */
	void exitSetcountvariable(ExprParseParser.SetcountvariableContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#set_date_part}.
	 * @param ctx the parse tree
	 */
	void enterSet_date_part(ExprParseParser.Set_date_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#set_date_part}.
	 * @param ctx the parse tree
	 */
	void exitSet_date_part(ExprParseParser.Set_date_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#setmaxvariable}.
	 * @param ctx the parse tree
	 */
	void enterSetmaxvariable(ExprParseParser.SetmaxvariableContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#setmaxvariable}.
	 * @param ctx the parse tree
	 */
	void exitSetmaxvariable(ExprParseParser.SetmaxvariableContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#setminvariable}.
	 * @param ctx the parse tree
	 */
	void enterSetminvariable(ExprParseParser.SetminvariableContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#setminvariable}.
	 * @param ctx the parse tree
	 */
	void exitSetminvariable(ExprParseParser.SetminvariableContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#setvariable}.
	 * @param ctx the parse tree
	 */
	void enterSetvariable(ExprParseParser.SetvariableContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#setvariable}.
	 * @param ctx the parse tree
	 */
	void exitSetvariable(ExprParseParser.SetvariableContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#sign}.
	 * @param ctx the parse tree
	 */
	void enterSign(ExprParseParser.SignContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#sign}.
	 * @param ctx the parse tree
	 */
	void exitSign(ExprParseParser.SignContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#sin}.
	 * @param ctx the parse tree
	 */
	void enterSin(ExprParseParser.SinContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#sin}.
	 * @param ctx the parse tree
	 */
	void exitSin(ExprParseParser.SinContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#sinh}.
	 * @param ctx the parse tree
	 */
	void enterSinh(ExprParseParser.SinhContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#sinh}.
	 * @param ctx the parse tree
	 */
	void exitSinh(ExprParseParser.SinhContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#soundex}.
	 * @param ctx the parse tree
	 */
	void enterSoundex(ExprParseParser.SoundexContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#soundex}.
	 * @param ctx the parse tree
	 */
	void exitSoundex(ExprParseParser.SoundexContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#sqrt}.
	 * @param ctx the parse tree
	 */
	void enterSqrt(ExprParseParser.SqrtContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#sqrt}.
	 * @param ctx the parse tree
	 */
	void exitSqrt(ExprParseParser.SqrtContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#stddev}.
	 * @param ctx the parse tree
	 */
	void enterStddev(ExprParseParser.StddevContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#stddev}.
	 * @param ctx the parse tree
	 */
	void exitStddev(ExprParseParser.StddevContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#substr}.
	 * @param ctx the parse tree
	 */
	void enterSubstr(ExprParseParser.SubstrContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#substr}.
	 * @param ctx the parse tree
	 */
	void exitSubstr(ExprParseParser.SubstrContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#sum}.
	 * @param ctx the parse tree
	 */
	void enterSum(ExprParseParser.SumContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#sum}.
	 * @param ctx the parse tree
	 */
	void exitSum(ExprParseParser.SumContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#systimestamp}.
	 * @param ctx the parse tree
	 */
	void enterSystimestamp(ExprParseParser.SystimestampContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#systimestamp}.
	 * @param ctx the parse tree
	 */
	void exitSystimestamp(ExprParseParser.SystimestampContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#tan}.
	 * @param ctx the parse tree
	 */
	void enterTan(ExprParseParser.TanContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#tan}.
	 * @param ctx the parse tree
	 */
	void exitTan(ExprParseParser.TanContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#tanh}.
	 * @param ctx the parse tree
	 */
	void enterTanh(ExprParseParser.TanhContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#tanh}.
	 * @param ctx the parse tree
	 */
	void exitTanh(ExprParseParser.TanhContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#to_bigint}.
	 * @param ctx the parse tree
	 */
	void enterTo_bigint(ExprParseParser.To_bigintContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#to_bigint}.
	 * @param ctx the parse tree
	 */
	void exitTo_bigint(ExprParseParser.To_bigintContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#to_char}.
	 * @param ctx the parse tree
	 */
	void enterTo_char(ExprParseParser.To_charContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#to_char}.
	 * @param ctx the parse tree
	 */
	void exitTo_char(ExprParseParser.To_charContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#to_date}.
	 * @param ctx the parse tree
	 */
	void enterTo_date(ExprParseParser.To_dateContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#to_date}.
	 * @param ctx the parse tree
	 */
	void exitTo_date(ExprParseParser.To_dateContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#to_decimal}.
	 * @param ctx the parse tree
	 */
	void enterTo_decimal(ExprParseParser.To_decimalContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#to_decimal}.
	 * @param ctx the parse tree
	 */
	void exitTo_decimal(ExprParseParser.To_decimalContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#to_float}.
	 * @param ctx the parse tree
	 */
	void enterTo_float(ExprParseParser.To_floatContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#to_float}.
	 * @param ctx the parse tree
	 */
	void exitTo_float(ExprParseParser.To_floatContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#to_integer}.
	 * @param ctx the parse tree
	 */
	void enterTo_integer(ExprParseParser.To_integerContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#to_integer}.
	 * @param ctx the parse tree
	 */
	void exitTo_integer(ExprParseParser.To_integerContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#trunc}.
	 * @param ctx the parse tree
	 */
	void enterTrunc(ExprParseParser.TruncContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#trunc}.
	 * @param ctx the parse tree
	 */
	void exitTrunc(ExprParseParser.TruncContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#upper}.
	 * @param ctx the parse tree
	 */
	void enterUpper(ExprParseParser.UpperContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#upper}.
	 * @param ctx the parse tree
	 */
	void exitUpper(ExprParseParser.UpperContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#variance}.
	 * @param ctx the parse tree
	 */
	void enterVariance(ExprParseParser.VarianceContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#variance}.
	 * @param ctx the parse tree
	 */
	void exitVariance(ExprParseParser.VarianceContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#parms}.
	 * @param ctx the parse tree
	 */
	void enterParms(ExprParseParser.ParmsContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#parms}.
	 * @param ctx the parse tree
	 */
	void exitParms(ExprParseParser.ParmsContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#parm}.
	 * @param ctx the parse tree
	 */
	void enterParm(ExprParseParser.ParmContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#parm}.
	 * @param ctx the parse tree
	 */
	void exitParm(ExprParseParser.ParmContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#port}.
	 * @param ctx the parse tree
	 */
	void enterPort(ExprParseParser.PortContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#port}.
	 * @param ctx the parse tree
	 */
	void exitPort(ExprParseParser.PortContext ctx);
	/**
	 * Enter a parse tree produced by {@link ExprParseParser#hard_code}.
	 * @param ctx the parse tree
	 */
	void enterHard_code(ExprParseParser.Hard_codeContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExprParseParser#hard_code}.
	 * @param ctx the parse tree
	 */
	void exitHard_code(ExprParseParser.Hard_codeContext ctx);
}
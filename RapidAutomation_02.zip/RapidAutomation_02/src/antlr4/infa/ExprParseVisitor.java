// Generated from C:/Users/c190471/Desktop/RapidAutomation/src/antlr4/infa\ExprParse.g4 by ANTLR 4.8
package antlr4.infa;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link ExprParseParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface ExprParseVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpression(ExprParseParser.ExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#operator}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOperator(ExprParseParser.OperatorContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#logical_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLogical_expression(ExprParseParser.Logical_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#abort}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAbort(ExprParseParser.AbortContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#abs}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAbs(ExprParseParser.AbsContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#add_to_date}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAdd_to_date(ExprParseParser.Add_to_dateContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#aes_decrypt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAes_decrypt(ExprParseParser.Aes_decryptContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#aes_encrypt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAes_encrypt(ExprParseParser.Aes_encryptContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#ascii}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAscii(ExprParseParser.AsciiContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#avg}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAvg(ExprParseParser.AvgContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#ceil}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCeil(ExprParseParser.CeilContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#choose}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitChoose(ExprParseParser.ChooseContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#chr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitChr(ExprParseParser.ChrContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#chrcode}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitChrcode(ExprParseParser.ChrcodeContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#compress}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCompress(ExprParseParser.CompressContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#concat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConcat(ExprParseParser.ConcatContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#convert_base}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConvert_base(ExprParseParser.Convert_baseContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#cos}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCos(ExprParseParser.CosContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#cosh}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCosh(ExprParseParser.CoshContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#count}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCount(ExprParseParser.CountContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#crc32}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCrc32(ExprParseParser.Crc32Context ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#cume}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCume(ExprParseParser.CumeContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#date_compare}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDate_compare(ExprParseParser.Date_compareContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#date_diff}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDate_diff(ExprParseParser.Date_diffContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#dec_base64}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDec_base64(ExprParseParser.Dec_base64Context ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#decode}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDecode(ExprParseParser.DecodeContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#decompress}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDecompress(ExprParseParser.DecompressContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#enc_base64}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEnc_base64(ExprParseParser.Enc_base64Context ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#error}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitError(ExprParseParser.ErrorContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#exp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExp(ExprParseParser.ExpContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#first}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFirst(ExprParseParser.FirstContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#floor}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFloor(ExprParseParser.FloorContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#fv}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFv(ExprParseParser.FvContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#get_date_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGet_date_part(ExprParseParser.Get_date_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#greatest}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGreatest(ExprParseParser.GreatestContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#iif}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIif(ExprParseParser.IifContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#in}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIn(ExprParseParser.InContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#indexof}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIndexof(ExprParseParser.IndexofContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#initcap}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInitcap(ExprParseParser.InitcapContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#instr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInstr(ExprParseParser.InstrContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#isnull}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIsnull(ExprParseParser.IsnullContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#is_date}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIs_date(ExprParseParser.Is_dateContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#is_number}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIs_number(ExprParseParser.Is_numberContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#is_spaces}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIs_spaces(ExprParseParser.Is_spacesContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#lag}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLag(ExprParseParser.LagContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#last}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLast(ExprParseParser.LastContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#last_day}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLast_day(ExprParseParser.Last_dayContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#lead}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLead(ExprParseParser.LeadContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#least}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLeast(ExprParseParser.LeastContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#length}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLength(ExprParseParser.LengthContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#ln}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLn(ExprParseParser.LnContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#log}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLog(ExprParseParser.LogContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#lookup}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLookup(ExprParseParser.LookupContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#lower}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLower(ExprParseParser.LowerContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#lpad}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLpad(ExprParseParser.LpadContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#ltrim}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLtrim(ExprParseParser.LtrimContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#make_date_time}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMake_date_time(ExprParseParser.Make_date_timeContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#max}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMax(ExprParseParser.MaxContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#md5}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMd5(ExprParseParser.Md5Context ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#median}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMedian(ExprParseParser.MedianContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#metaphone}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMetaphone(ExprParseParser.MetaphoneContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#min}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMin(ExprParseParser.MinContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#mod}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMod(ExprParseParser.ModContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#movingavg}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMovingavg(ExprParseParser.MovingavgContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#movingsum}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMovingsum(ExprParseParser.MovingsumContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#nper}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNper(ExprParseParser.NperContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#percentile}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPercentile(ExprParseParser.PercentileContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#pmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPmt(ExprParseParser.PmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#power}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPower(ExprParseParser.PowerContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#pv}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPv(ExprParseParser.PvContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#rand}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRand(ExprParseParser.RandContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#rate}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRate(ExprParseParser.RateContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#reg_extract}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReg_extract(ExprParseParser.Reg_extractContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#reg_match}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReg_match(ExprParseParser.Reg_matchContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#reg_replace}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReg_replace(ExprParseParser.Reg_replaceContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#replacechr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReplacechr(ExprParseParser.ReplacechrContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#replacestr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReplacestr(ExprParseParser.ReplacestrContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#reverse}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReverse(ExprParseParser.ReverseContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#round}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRound(ExprParseParser.RoundContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#rpad}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRpad(ExprParseParser.RpadContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#rtrim}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRtrim(ExprParseParser.RtrimContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#setcountvariable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSetcountvariable(ExprParseParser.SetcountvariableContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#set_date_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSet_date_part(ExprParseParser.Set_date_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#setmaxvariable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSetmaxvariable(ExprParseParser.SetmaxvariableContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#setminvariable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSetminvariable(ExprParseParser.SetminvariableContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#setvariable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSetvariable(ExprParseParser.SetvariableContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#sign}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSign(ExprParseParser.SignContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#sin}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSin(ExprParseParser.SinContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#sinh}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSinh(ExprParseParser.SinhContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#soundex}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSoundex(ExprParseParser.SoundexContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#sqrt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSqrt(ExprParseParser.SqrtContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#stddev}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStddev(ExprParseParser.StddevContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#substr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubstr(ExprParseParser.SubstrContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#sum}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSum(ExprParseParser.SumContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#systimestamp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSystimestamp(ExprParseParser.SystimestampContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#tan}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTan(ExprParseParser.TanContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#tanh}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTanh(ExprParseParser.TanhContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#to_bigint}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTo_bigint(ExprParseParser.To_bigintContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#to_char}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTo_char(ExprParseParser.To_charContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#to_date}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTo_date(ExprParseParser.To_dateContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#to_decimal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTo_decimal(ExprParseParser.To_decimalContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#to_float}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTo_float(ExprParseParser.To_floatContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#to_integer}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTo_integer(ExprParseParser.To_integerContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#trunc}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTrunc(ExprParseParser.TruncContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#upper}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUpper(ExprParseParser.UpperContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#variance}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVariance(ExprParseParser.VarianceContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#parms}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParms(ExprParseParser.ParmsContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#parm}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParm(ExprParseParser.ParmContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#port}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPort(ExprParseParser.PortContext ctx);
	/**
	 * Visit a parse tree produced by {@link ExprParseParser#hard_code}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHard_code(ExprParseParser.Hard_codeContext ctx);
}
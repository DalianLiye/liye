// Generated from C:/Users/c190471/Desktop/Projects/java/RapidAutomation/src/antlr4/test\tableColumn.g4 by ANTLR 4.8
package antlr4.test;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link tableColumnParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface tableColumnVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#scripts}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitScripts(tableColumnParser.ScriptsContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#query_script_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitQuery_script_list(tableColumnParser.Query_script_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#with_clause_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWith_clause_list(tableColumnParser.With_clause_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#with_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWith_clause(tableColumnParser.With_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#with_query_script_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWith_query_script_list(tableColumnParser.With_query_script_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#final_query_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFinal_query_list(tableColumnParser.Final_query_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#query_script}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitQuery_script(tableColumnParser.Query_scriptContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#select_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelect_clause(tableColumnParser.Select_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#colum_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitColum_list(tableColumnParser.Colum_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#colum}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitColum(tableColumnParser.ColumContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#from_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFrom_clause(tableColumnParser.From_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#from_query_script_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFrom_query_script_list(tableColumnParser.From_query_script_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#table_name_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTable_name_list(tableColumnParser.Table_name_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#table_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTable_name(tableColumnParser.Table_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#join_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJoin_clause(tableColumnParser.Join_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#left_join_clase}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLeft_join_clase(tableColumnParser.Left_join_claseContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#right_join_clase}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRight_join_clase(tableColumnParser.Right_join_claseContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#full_join_clase}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFull_join_clase(tableColumnParser.Full_join_claseContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#inner_join_clase}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInner_join_clase(tableColumnParser.Inner_join_claseContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#left_join_query_script_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLeft_join_query_script_list(tableColumnParser.Left_join_query_script_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#right_join_query_script_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRight_join_query_script_list(tableColumnParser.Right_join_query_script_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#full_join_query_script_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFull_join_query_script_list(tableColumnParser.Full_join_query_script_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#inner_join_query_script_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInner_join_query_script_list(tableColumnParser.Inner_join_query_script_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#left_join_clause_condition_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLeft_join_clause_condition_list(tableColumnParser.Left_join_clause_condition_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#right_join_clause_condition_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRight_join_clause_condition_list(tableColumnParser.Right_join_clause_condition_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#full_join_clause_condition_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFull_join_clause_condition_list(tableColumnParser.Full_join_clause_condition_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#inner_join_clause_condition_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInner_join_clause_condition_list(tableColumnParser.Inner_join_clause_condition_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#left_join}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLeft_join(tableColumnParser.Left_joinContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#right_join}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRight_join(tableColumnParser.Right_joinContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#full_join}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFull_join(tableColumnParser.Full_joinContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#inner_join}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInner_join(tableColumnParser.Inner_joinContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#join_clause_condition_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJoin_clause_condition_list(tableColumnParser.Join_clause_condition_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#where_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhere_clause(tableColumnParser.Where_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#where_clause_condition_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhere_clause_condition_list(tableColumnParser.Where_clause_condition_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#group_by_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGroup_by_clause(tableColumnParser.Group_by_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#group_by_key_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGroup_by_key_list(tableColumnParser.Group_by_key_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#group_by_key}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGroup_by_key(tableColumnParser.Group_by_keyContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#group_key_factor}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGroup_key_factor(tableColumnParser.Group_key_factorContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#function}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction(tableColumnParser.FunctionContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#function_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_name(tableColumnParser.Function_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#condition_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCondition_list(tableColumnParser.Condition_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#condition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCondition(tableColumnParser.ConditionContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#parm_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParm_list(tableColumnParser.Parm_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#parm_xmlparse}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParm_xmlparse(tableColumnParser.Parm_xmlparseContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#parm}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParm(tableColumnParser.ParmContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#field}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitField(tableColumnParser.FieldContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#hard_code}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHard_code(tableColumnParser.Hard_codeContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#set_operator}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSet_operator(tableColumnParser.Set_operatorContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#operator}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOperator(tableColumnParser.OperatorContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#temporary_table_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTemporary_table_name(tableColumnParser.Temporary_table_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#parenthese}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParenthese(tableColumnParser.ParentheseContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#column_alias}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitColumn_alias(tableColumnParser.Column_aliasContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#schema}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSchema(tableColumnParser.SchemaContext ctx);
	/**
	 * Visit a parse tree produced by {@link tableColumnParser#table_alias}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTable_alias(tableColumnParser.Table_aliasContext ctx);
}
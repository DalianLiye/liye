// Generated from C:/Users/c190471/Desktop/Projects/java/RapidAutomation/src/antlr4/test\tableColumn.g4 by ANTLR 4.8
package antlr4.test;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class tableColumnParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.8", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, T__4=5, T__5=6, T__6=7, T__7=8, T__8=9, 
		T__9=10, T__10=11, T__11=12, T__12=13, T__13=14, T__14=15, T__15=16, T__16=17, 
		T__17=18, T__18=19, T__19=20, T__20=21, T__21=22, T__22=23, T__23=24, 
		T__24=25, T__25=26, T__26=27, T__27=28, T__28=29, T__29=30, T__30=31, 
		T__31=32, T__32=33, T__33=34, T__34=35, T__35=36, T__36=37, T__37=38, 
		T__38=39, T__39=40, T__40=41, T__41=42, T__42=43, T__43=44, T__44=45, 
		T__45=46, T__46=47, T__47=48, T__48=49, T__49=50, T__50=51, T__51=52, 
		T__52=53, T__53=54, T__54=55, T__55=56, T__56=57, T__57=58, T__58=59, 
		T__59=60, T__60=61, T__61=62, T__62=63, T__63=64, T__64=65, T__65=66, 
		T__66=67, STRING=68, SINGLE_LINE_COMMENT=69, MULTI_LINE_COMMENT=70, SPACES=71;
	public static final int
		RULE_scripts = 0, RULE_query_script_list = 1, RULE_with_clause_list = 2, 
		RULE_with_clause = 3, RULE_with_query_script_list = 4, RULE_final_query_list = 5, 
		RULE_query_script = 6, RULE_select_clause = 7, RULE_colum_list = 8, RULE_colum = 9, 
		RULE_from_clause = 10, RULE_from_query_script_list = 11, RULE_table_name_list = 12, 
		RULE_table_name = 13, RULE_join_clause = 14, RULE_left_join_clase = 15, 
		RULE_right_join_clase = 16, RULE_full_join_clase = 17, RULE_inner_join_clase = 18, 
		RULE_left_join_query_script_list = 19, RULE_right_join_query_script_list = 20, 
		RULE_full_join_query_script_list = 21, RULE_inner_join_query_script_list = 22, 
		RULE_left_join_clause_condition_list = 23, RULE_right_join_clause_condition_list = 24, 
		RULE_full_join_clause_condition_list = 25, RULE_inner_join_clause_condition_list = 26, 
		RULE_left_join = 27, RULE_right_join = 28, RULE_full_join = 29, RULE_inner_join = 30, 
		RULE_join_clause_condition_list = 31, RULE_where_clause = 32, RULE_where_clause_condition_list = 33, 
		RULE_group_by_clause = 34, RULE_group_by_key_list = 35, RULE_group_by_key = 36, 
		RULE_group_key_factor = 37, RULE_function = 38, RULE_function_name = 39, 
		RULE_condition_list = 40, RULE_condition = 41, RULE_parm_list = 42, RULE_parm_xmlparse = 43, 
		RULE_parm = 44, RULE_field = 45, RULE_hard_code = 46, RULE_set_operator = 47, 
		RULE_operator = 48, RULE_temporary_table_name = 49, RULE_parenthese = 50, 
		RULE_column_alias = 51, RULE_schema = 52, RULE_table_alias = 53;
	private static String[] makeRuleNames() {
		return new String[] {
			"scripts", "query_script_list", "with_clause_list", "with_clause", "with_query_script_list", 
			"final_query_list", "query_script", "select_clause", "colum_list", "colum", 
			"from_clause", "from_query_script_list", "table_name_list", "table_name", 
			"join_clause", "left_join_clase", "right_join_clase", "full_join_clase", 
			"inner_join_clase", "left_join_query_script_list", "right_join_query_script_list", 
			"full_join_query_script_list", "inner_join_query_script_list", "left_join_clause_condition_list", 
			"right_join_clause_condition_list", "full_join_clause_condition_list", 
			"inner_join_clause_condition_list", "left_join", "right_join", "full_join", 
			"inner_join", "join_clause_condition_list", "where_clause", "where_clause_condition_list", 
			"group_by_clause", "group_by_key_list", "group_by_key", "group_key_factor", 
			"function", "function_name", "condition_list", "condition", "parm_list", 
			"parm_xmlparse", "parm", "field", "hard_code", "set_operator", "operator", 
			"temporary_table_name", "parenthese", "column_alias", "schema", "table_alias"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "','", "'with'", "'as'", "'('", "')'", "'select'", "'distinct'", 
			"'from'", "'.'", "'on'", "'left'", "'outer'", "'join'", "'right'", "'full'", 
			"'inner'", "'where'", "'group'", "'by'", "'order'", "'over'", "'partition'", 
			"'asc'", "'desc'", "'case'", "'when'", "'then'", "'else'", "'end'", "'.getclobval'", 
			"'within'", "'to_char'", "'row_number'", "'nvl'", "'sum'", "'max'", "'xmlparse'", 
			"'xmlagg'", "'dbms_lob.substr'", "'listagg'", "'count'", "'||'", "'content'", 
			"'wellformed'", "'*'", "'null'", "'''", "';'", "'minus'", "'union'", 
			"'all'", "'>'", "'<'", "'='", "'>='", "'<='", "'<>'", "'and'", "'or'", 
			"'+'", "'-'", "'/'", "'%'", "'is'", "'not'", "'in'", "'()'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, "STRING", "SINGLE_LINE_COMMENT", 
			"MULTI_LINE_COMMENT", "SPACES"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "tableColumn.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public tableColumnParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	public static class ScriptsContext extends ParserRuleContext {
		public Query_script_listContext query_script_list() {
			return getRuleContext(Query_script_listContext.class,0);
		}
		public ScriptsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_scripts; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterScripts(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitScripts(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitScripts(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ScriptsContext scripts() throws RecognitionException {
		ScriptsContext _localctx = new ScriptsContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_scripts);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(108);
			query_script_list();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Query_script_listContext extends ParserRuleContext {
		public Final_query_listContext final_query_list() {
			return getRuleContext(Final_query_listContext.class,0);
		}
		public List<With_clause_listContext> with_clause_list() {
			return getRuleContexts(With_clause_listContext.class);
		}
		public With_clause_listContext with_clause_list(int i) {
			return getRuleContext(With_clause_listContext.class,i);
		}
		public Query_script_listContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_query_script_list; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterQuery_script_list(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitQuery_script_list(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitQuery_script_list(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Query_script_listContext query_script_list() throws RecognitionException {
		Query_script_listContext _localctx = new Query_script_listContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_query_script_list);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(113);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__1 || _la==STRING) {
				{
				{
				setState(110);
				with_clause_list();
				}
				}
				setState(115);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(116);
			final_query_list();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class With_clause_listContext extends ParserRuleContext {
		public List<With_clauseContext> with_clause() {
			return getRuleContexts(With_clauseContext.class);
		}
		public With_clauseContext with_clause(int i) {
			return getRuleContext(With_clauseContext.class,i);
		}
		public With_clause_listContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_with_clause_list; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterWith_clause_list(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitWith_clause_list(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitWith_clause_list(this);
			else return visitor.visitChildren(this);
		}
	}

	public final With_clause_listContext with_clause_list() throws RecognitionException {
		With_clause_listContext _localctx = new With_clause_listContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_with_clause_list);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(118);
			with_clause();
			setState(123);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(119);
				match(T__0);
				setState(120);
				with_clause();
				}
				}
				setState(125);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class With_clauseContext extends ParserRuleContext {
		public Temporary_table_nameContext temporary_table_name() {
			return getRuleContext(Temporary_table_nameContext.class,0);
		}
		public With_query_script_listContext with_query_script_list() {
			return getRuleContext(With_query_script_listContext.class,0);
		}
		public With_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_with_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterWith_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitWith_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitWith_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final With_clauseContext with_clause() throws RecognitionException {
		With_clauseContext _localctx = new With_clauseContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_with_clause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(127);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__1) {
				{
				setState(126);
				match(T__1);
				}
			}

			setState(129);
			temporary_table_name();
			setState(130);
			match(T__2);
			setState(131);
			match(T__3);
			setState(132);
			with_query_script_list();
			setState(133);
			match(T__4);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class With_query_script_listContext extends ParserRuleContext {
		public List<Query_scriptContext> query_script() {
			return getRuleContexts(Query_scriptContext.class);
		}
		public Query_scriptContext query_script(int i) {
			return getRuleContext(Query_scriptContext.class,i);
		}
		public List<Set_operatorContext> set_operator() {
			return getRuleContexts(Set_operatorContext.class);
		}
		public Set_operatorContext set_operator(int i) {
			return getRuleContext(Set_operatorContext.class,i);
		}
		public With_query_script_listContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_with_query_script_list; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterWith_query_script_list(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitWith_query_script_list(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitWith_query_script_list(this);
			else return visitor.visitChildren(this);
		}
	}

	public final With_query_script_listContext with_query_script_list() throws RecognitionException {
		With_query_script_listContext _localctx = new With_query_script_listContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_with_query_script_list);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(135);
			query_script();
			setState(141);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__48 || _la==T__49) {
				{
				{
				setState(136);
				set_operator();
				setState(137);
				query_script();
				}
				}
				setState(143);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Final_query_listContext extends ParserRuleContext {
		public List<Query_scriptContext> query_script() {
			return getRuleContexts(Query_scriptContext.class);
		}
		public Query_scriptContext query_script(int i) {
			return getRuleContext(Query_scriptContext.class,i);
		}
		public List<Set_operatorContext> set_operator() {
			return getRuleContexts(Set_operatorContext.class);
		}
		public Set_operatorContext set_operator(int i) {
			return getRuleContext(Set_operatorContext.class,i);
		}
		public Final_query_listContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_final_query_list; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterFinal_query_list(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitFinal_query_list(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitFinal_query_list(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Final_query_listContext final_query_list() throws RecognitionException {
		Final_query_listContext _localctx = new Final_query_listContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_final_query_list);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(144);
			query_script();
			setState(150);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__48 || _la==T__49) {
				{
				{
				setState(145);
				set_operator();
				setState(146);
				query_script();
				}
				}
				setState(152);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Query_scriptContext extends ParserRuleContext {
		public Select_clauseContext select_clause() {
			return getRuleContext(Select_clauseContext.class,0);
		}
		public From_clauseContext from_clause() {
			return getRuleContext(From_clauseContext.class,0);
		}
		public List<Join_clauseContext> join_clause() {
			return getRuleContexts(Join_clauseContext.class);
		}
		public Join_clauseContext join_clause(int i) {
			return getRuleContext(Join_clauseContext.class,i);
		}
		public List<Where_clauseContext> where_clause() {
			return getRuleContexts(Where_clauseContext.class);
		}
		public Where_clauseContext where_clause(int i) {
			return getRuleContext(Where_clauseContext.class,i);
		}
		public List<Group_by_clauseContext> group_by_clause() {
			return getRuleContexts(Group_by_clauseContext.class);
		}
		public Group_by_clauseContext group_by_clause(int i) {
			return getRuleContext(Group_by_clauseContext.class,i);
		}
		public Query_scriptContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_query_script; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterQuery_script(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitQuery_script(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitQuery_script(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Query_scriptContext query_script() throws RecognitionException {
		Query_scriptContext _localctx = new Query_scriptContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_query_script);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(154);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__3) {
				{
				setState(153);
				match(T__3);
				}
			}

			setState(156);
			select_clause();
			setState(157);
			from_clause();
			setState(161);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__10) | (1L << T__13) | (1L << T__14) | (1L << T__15))) != 0)) {
				{
				{
				setState(158);
				join_clause();
				}
				}
				setState(163);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(167);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__16) {
				{
				{
				setState(164);
				where_clause();
				}
				}
				setState(169);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(173);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__17) {
				{
				{
				setState(170);
				group_by_clause();
				}
				}
				setState(175);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(177);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,9,_ctx) ) {
			case 1:
				{
				setState(176);
				match(T__4);
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Select_clauseContext extends ParserRuleContext {
		public Colum_listContext colum_list() {
			return getRuleContext(Colum_listContext.class,0);
		}
		public Select_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_select_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterSelect_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitSelect_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitSelect_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Select_clauseContext select_clause() throws RecognitionException {
		Select_clauseContext _localctx = new Select_clauseContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_select_clause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(179);
			match(T__5);
			setState(181);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__6) {
				{
				setState(180);
				match(T__6);
				}
			}

			setState(183);
			colum_list();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Colum_listContext extends ParserRuleContext {
		public List<ColumContext> colum() {
			return getRuleContexts(ColumContext.class);
		}
		public ColumContext colum(int i) {
			return getRuleContext(ColumContext.class,i);
		}
		public Colum_listContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_colum_list; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterColum_list(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitColum_list(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitColum_list(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Colum_listContext colum_list() throws RecognitionException {
		Colum_listContext _localctx = new Colum_listContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_colum_list);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(185);
			colum();
			setState(190);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(186);
				match(T__0);
				setState(187);
				colum();
				}
				}
				setState(192);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ColumContext extends ParserRuleContext {
		public List<FieldContext> field() {
			return getRuleContexts(FieldContext.class);
		}
		public FieldContext field(int i) {
			return getRuleContext(FieldContext.class,i);
		}
		public List<OperatorContext> operator() {
			return getRuleContexts(OperatorContext.class);
		}
		public OperatorContext operator(int i) {
			return getRuleContext(OperatorContext.class,i);
		}
		public Column_aliasContext column_alias() {
			return getRuleContext(Column_aliasContext.class,0);
		}
		public ColumContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_colum; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterColum(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitColum(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitColum(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ColumContext colum() throws RecognitionException {
		ColumContext _localctx = new ColumContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_colum);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(193);
			field();
			setState(199);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (((((_la - 42)) & ~0x3f) == 0 && ((1L << (_la - 42)) & ((1L << (T__41 - 42)) | (1L << (T__44 - 42)) | (1L << (T__51 - 42)) | (1L << (T__52 - 42)) | (1L << (T__53 - 42)) | (1L << (T__54 - 42)) | (1L << (T__55 - 42)) | (1L << (T__56 - 42)) | (1L << (T__57 - 42)) | (1L << (T__58 - 42)) | (1L << (T__59 - 42)) | (1L << (T__60 - 42)) | (1L << (T__61 - 42)) | (1L << (T__62 - 42)) | (1L << (T__63 - 42)) | (1L << (T__64 - 42)) | (1L << (T__65 - 42)))) != 0)) {
				{
				{
				setState(194);
				operator();
				setState(195);
				field();
				}
				}
				setState(201);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(203);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__2) {
				{
				setState(202);
				match(T__2);
				}
			}

			setState(206);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__46 || _la==STRING) {
				{
				setState(205);
				column_alias();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class From_clauseContext extends ParserRuleContext {
		public Table_name_listContext table_name_list() {
			return getRuleContext(Table_name_listContext.class,0);
		}
		public List<From_query_script_listContext> from_query_script_list() {
			return getRuleContexts(From_query_script_listContext.class);
		}
		public From_query_script_listContext from_query_script_list(int i) {
			return getRuleContext(From_query_script_listContext.class,i);
		}
		public List<Table_aliasContext> table_alias() {
			return getRuleContexts(Table_aliasContext.class);
		}
		public Table_aliasContext table_alias(int i) {
			return getRuleContext(Table_aliasContext.class,i);
		}
		public From_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_from_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterFrom_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitFrom_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitFrom_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final From_clauseContext from_clause() throws RecognitionException {
		From_clauseContext _localctx = new From_clauseContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_from_clause);
		int _la;
		try {
			setState(229);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,18,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(208);
				match(T__7);
				setState(209);
				table_name_list();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(210);
				match(T__7);
				setState(211);
				match(T__3);
				setState(212);
				from_query_script_list();
				setState(213);
				match(T__4);
				setState(215);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==STRING) {
					{
					setState(214);
					table_alias();
					}
				}

				setState(226);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__0) {
					{
					{
					setState(217);
					match(T__0);
					setState(218);
					match(T__3);
					setState(219);
					from_query_script_list();
					setState(220);
					match(T__4);
					setState(222);
					_errHandler.sync(this);
					_la = _input.LA(1);
					if (_la==STRING) {
						{
						setState(221);
						table_alias();
						}
					}

					}
					}
					setState(228);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class From_query_script_listContext extends ParserRuleContext {
		public List<Query_scriptContext> query_script() {
			return getRuleContexts(Query_scriptContext.class);
		}
		public Query_scriptContext query_script(int i) {
			return getRuleContext(Query_scriptContext.class,i);
		}
		public List<Set_operatorContext> set_operator() {
			return getRuleContexts(Set_operatorContext.class);
		}
		public Set_operatorContext set_operator(int i) {
			return getRuleContext(Set_operatorContext.class,i);
		}
		public From_query_script_listContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_from_query_script_list; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterFrom_query_script_list(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitFrom_query_script_list(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitFrom_query_script_list(this);
			else return visitor.visitChildren(this);
		}
	}

	public final From_query_script_listContext from_query_script_list() throws RecognitionException {
		From_query_script_listContext _localctx = new From_query_script_listContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_from_query_script_list);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(231);
			query_script();
			setState(237);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__48 || _la==T__49) {
				{
				{
				setState(232);
				set_operator();
				setState(233);
				query_script();
				}
				}
				setState(239);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Table_name_listContext extends ParserRuleContext {
		public List<Table_nameContext> table_name() {
			return getRuleContexts(Table_nameContext.class);
		}
		public Table_nameContext table_name(int i) {
			return getRuleContext(Table_nameContext.class,i);
		}
		public Table_name_listContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_table_name_list; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterTable_name_list(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitTable_name_list(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitTable_name_list(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Table_name_listContext table_name_list() throws RecognitionException {
		Table_name_listContext _localctx = new Table_name_listContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_table_name_list);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(241);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__3) {
				{
				setState(240);
				match(T__3);
				}
			}

			setState(243);
			table_name();
			setState(245);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,21,_ctx) ) {
			case 1:
				{
				setState(244);
				match(T__4);
				}
				break;
			}
			setState(257);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(247);
				match(T__0);
				setState(249);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==T__3) {
					{
					setState(248);
					match(T__3);
					}
				}

				setState(251);
				table_name();
				setState(253);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,23,_ctx) ) {
				case 1:
					{
					setState(252);
					match(T__4);
					}
					break;
				}
				}
				}
				setState(259);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Table_nameContext extends ParserRuleContext {
		public TerminalNode STRING() { return getToken(tableColumnParser.STRING, 0); }
		public SchemaContext schema() {
			return getRuleContext(SchemaContext.class,0);
		}
		public Table_aliasContext table_alias() {
			return getRuleContext(Table_aliasContext.class,0);
		}
		public Table_nameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_table_name; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterTable_name(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitTable_name(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitTable_name(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Table_nameContext table_name() throws RecognitionException {
		Table_nameContext _localctx = new Table_nameContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_table_name);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(263);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,25,_ctx) ) {
			case 1:
				{
				setState(260);
				schema();
				setState(261);
				match(T__8);
				}
				break;
			}
			setState(265);
			match(STRING);
			setState(267);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==STRING) {
				{
				setState(266);
				table_alias();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Join_clauseContext extends ParserRuleContext {
		public Full_join_claseContext full_join_clase() {
			return getRuleContext(Full_join_claseContext.class,0);
		}
		public Right_join_claseContext right_join_clase() {
			return getRuleContext(Right_join_claseContext.class,0);
		}
		public Left_join_claseContext left_join_clase() {
			return getRuleContext(Left_join_claseContext.class,0);
		}
		public Inner_join_claseContext inner_join_clase() {
			return getRuleContext(Inner_join_claseContext.class,0);
		}
		public Join_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_join_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterJoin_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitJoin_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitJoin_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Join_clauseContext join_clause() throws RecognitionException {
		Join_clauseContext _localctx = new Join_clauseContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_join_clause);
		try {
			setState(273);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__14:
				enterOuterAlt(_localctx, 1);
				{
				setState(269);
				full_join_clase();
				}
				break;
			case T__13:
				enterOuterAlt(_localctx, 2);
				{
				setState(270);
				right_join_clase();
				}
				break;
			case T__10:
				enterOuterAlt(_localctx, 3);
				{
				setState(271);
				left_join_clase();
				}
				break;
			case T__15:
				enterOuterAlt(_localctx, 4);
				{
				setState(272);
				inner_join_clase();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Left_join_claseContext extends ParserRuleContext {
		public Left_joinContext left_join() {
			return getRuleContext(Left_joinContext.class,0);
		}
		public Left_join_clause_condition_listContext left_join_clause_condition_list() {
			return getRuleContext(Left_join_clause_condition_listContext.class,0);
		}
		public Table_nameContext table_name() {
			return getRuleContext(Table_nameContext.class,0);
		}
		public Left_join_query_script_listContext left_join_query_script_list() {
			return getRuleContext(Left_join_query_script_listContext.class,0);
		}
		public Table_aliasContext table_alias() {
			return getRuleContext(Table_aliasContext.class,0);
		}
		public Left_join_claseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_left_join_clase; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterLeft_join_clase(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitLeft_join_clase(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitLeft_join_clase(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Left_join_claseContext left_join_clase() throws RecognitionException {
		Left_join_claseContext _localctx = new Left_join_claseContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_left_join_clase);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(275);
			left_join();
			setState(282);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case STRING:
				{
				setState(276);
				table_name();
				}
				break;
			case T__3:
				{
				setState(277);
				match(T__3);
				setState(278);
				left_join_query_script_list();
				setState(279);
				match(T__4);
				setState(280);
				table_alias();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(284);
			match(T__9);
			setState(285);
			left_join_clause_condition_list();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Right_join_claseContext extends ParserRuleContext {
		public Right_joinContext right_join() {
			return getRuleContext(Right_joinContext.class,0);
		}
		public Right_join_clause_condition_listContext right_join_clause_condition_list() {
			return getRuleContext(Right_join_clause_condition_listContext.class,0);
		}
		public Table_nameContext table_name() {
			return getRuleContext(Table_nameContext.class,0);
		}
		public Right_join_query_script_listContext right_join_query_script_list() {
			return getRuleContext(Right_join_query_script_listContext.class,0);
		}
		public Table_aliasContext table_alias() {
			return getRuleContext(Table_aliasContext.class,0);
		}
		public Right_join_claseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_right_join_clase; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterRight_join_clase(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitRight_join_clase(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitRight_join_clase(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Right_join_claseContext right_join_clase() throws RecognitionException {
		Right_join_claseContext _localctx = new Right_join_claseContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_right_join_clase);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(287);
			right_join();
			setState(294);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case STRING:
				{
				setState(288);
				table_name();
				}
				break;
			case T__3:
				{
				setState(289);
				match(T__3);
				setState(290);
				right_join_query_script_list();
				setState(291);
				match(T__4);
				setState(292);
				table_alias();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(296);
			match(T__9);
			setState(297);
			right_join_clause_condition_list();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Full_join_claseContext extends ParserRuleContext {
		public Full_joinContext full_join() {
			return getRuleContext(Full_joinContext.class,0);
		}
		public Full_join_clause_condition_listContext full_join_clause_condition_list() {
			return getRuleContext(Full_join_clause_condition_listContext.class,0);
		}
		public Table_nameContext table_name() {
			return getRuleContext(Table_nameContext.class,0);
		}
		public Full_join_query_script_listContext full_join_query_script_list() {
			return getRuleContext(Full_join_query_script_listContext.class,0);
		}
		public Table_aliasContext table_alias() {
			return getRuleContext(Table_aliasContext.class,0);
		}
		public Full_join_claseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_full_join_clase; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterFull_join_clase(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitFull_join_clase(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitFull_join_clase(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Full_join_claseContext full_join_clase() throws RecognitionException {
		Full_join_claseContext _localctx = new Full_join_claseContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_full_join_clase);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(299);
			full_join();
			setState(306);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case STRING:
				{
				setState(300);
				table_name();
				}
				break;
			case T__3:
				{
				setState(301);
				match(T__3);
				setState(302);
				full_join_query_script_list();
				setState(303);
				match(T__4);
				setState(304);
				table_alias();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(308);
			match(T__9);
			setState(309);
			full_join_clause_condition_list();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Inner_join_claseContext extends ParserRuleContext {
		public Inner_joinContext inner_join() {
			return getRuleContext(Inner_joinContext.class,0);
		}
		public Inner_join_clause_condition_listContext inner_join_clause_condition_list() {
			return getRuleContext(Inner_join_clause_condition_listContext.class,0);
		}
		public Table_nameContext table_name() {
			return getRuleContext(Table_nameContext.class,0);
		}
		public Inner_join_query_script_listContext inner_join_query_script_list() {
			return getRuleContext(Inner_join_query_script_listContext.class,0);
		}
		public Table_aliasContext table_alias() {
			return getRuleContext(Table_aliasContext.class,0);
		}
		public Inner_join_claseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_inner_join_clase; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterInner_join_clase(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitInner_join_clase(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitInner_join_clase(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Inner_join_claseContext inner_join_clase() throws RecognitionException {
		Inner_join_claseContext _localctx = new Inner_join_claseContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_inner_join_clase);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(311);
			inner_join();
			setState(318);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case STRING:
				{
				setState(312);
				table_name();
				}
				break;
			case T__3:
				{
				setState(313);
				match(T__3);
				setState(314);
				inner_join_query_script_list();
				setState(315);
				match(T__4);
				setState(316);
				table_alias();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(320);
			match(T__9);
			setState(321);
			inner_join_clause_condition_list();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Left_join_query_script_listContext extends ParserRuleContext {
		public List<Query_scriptContext> query_script() {
			return getRuleContexts(Query_scriptContext.class);
		}
		public Query_scriptContext query_script(int i) {
			return getRuleContext(Query_scriptContext.class,i);
		}
		public List<Set_operatorContext> set_operator() {
			return getRuleContexts(Set_operatorContext.class);
		}
		public Set_operatorContext set_operator(int i) {
			return getRuleContext(Set_operatorContext.class,i);
		}
		public Left_join_query_script_listContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_left_join_query_script_list; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterLeft_join_query_script_list(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitLeft_join_query_script_list(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitLeft_join_query_script_list(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Left_join_query_script_listContext left_join_query_script_list() throws RecognitionException {
		Left_join_query_script_listContext _localctx = new Left_join_query_script_listContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_left_join_query_script_list);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(323);
			query_script();
			setState(329);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__48 || _la==T__49) {
				{
				{
				setState(324);
				set_operator();
				setState(325);
				query_script();
				}
				}
				setState(331);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Right_join_query_script_listContext extends ParserRuleContext {
		public List<Query_scriptContext> query_script() {
			return getRuleContexts(Query_scriptContext.class);
		}
		public Query_scriptContext query_script(int i) {
			return getRuleContext(Query_scriptContext.class,i);
		}
		public List<Set_operatorContext> set_operator() {
			return getRuleContexts(Set_operatorContext.class);
		}
		public Set_operatorContext set_operator(int i) {
			return getRuleContext(Set_operatorContext.class,i);
		}
		public Right_join_query_script_listContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_right_join_query_script_list; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterRight_join_query_script_list(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitRight_join_query_script_list(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitRight_join_query_script_list(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Right_join_query_script_listContext right_join_query_script_list() throws RecognitionException {
		Right_join_query_script_listContext _localctx = new Right_join_query_script_listContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_right_join_query_script_list);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(332);
			query_script();
			setState(338);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__48 || _la==T__49) {
				{
				{
				setState(333);
				set_operator();
				setState(334);
				query_script();
				}
				}
				setState(340);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Full_join_query_script_listContext extends ParserRuleContext {
		public List<Query_scriptContext> query_script() {
			return getRuleContexts(Query_scriptContext.class);
		}
		public Query_scriptContext query_script(int i) {
			return getRuleContext(Query_scriptContext.class,i);
		}
		public List<Set_operatorContext> set_operator() {
			return getRuleContexts(Set_operatorContext.class);
		}
		public Set_operatorContext set_operator(int i) {
			return getRuleContext(Set_operatorContext.class,i);
		}
		public Full_join_query_script_listContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_full_join_query_script_list; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterFull_join_query_script_list(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitFull_join_query_script_list(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitFull_join_query_script_list(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Full_join_query_script_listContext full_join_query_script_list() throws RecognitionException {
		Full_join_query_script_listContext _localctx = new Full_join_query_script_listContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_full_join_query_script_list);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(341);
			query_script();
			setState(347);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__48 || _la==T__49) {
				{
				{
				setState(342);
				set_operator();
				setState(343);
				query_script();
				}
				}
				setState(349);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Inner_join_query_script_listContext extends ParserRuleContext {
		public List<Query_scriptContext> query_script() {
			return getRuleContexts(Query_scriptContext.class);
		}
		public Query_scriptContext query_script(int i) {
			return getRuleContext(Query_scriptContext.class,i);
		}
		public List<Set_operatorContext> set_operator() {
			return getRuleContexts(Set_operatorContext.class);
		}
		public Set_operatorContext set_operator(int i) {
			return getRuleContext(Set_operatorContext.class,i);
		}
		public Inner_join_query_script_listContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_inner_join_query_script_list; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterInner_join_query_script_list(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitInner_join_query_script_list(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitInner_join_query_script_list(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Inner_join_query_script_listContext inner_join_query_script_list() throws RecognitionException {
		Inner_join_query_script_listContext _localctx = new Inner_join_query_script_listContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_inner_join_query_script_list);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(350);
			query_script();
			setState(356);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__48 || _la==T__49) {
				{
				{
				setState(351);
				set_operator();
				setState(352);
				query_script();
				}
				}
				setState(358);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Left_join_clause_condition_listContext extends ParserRuleContext {
		public Join_clause_condition_listContext join_clause_condition_list() {
			return getRuleContext(Join_clause_condition_listContext.class,0);
		}
		public Left_join_clause_condition_listContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_left_join_clause_condition_list; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterLeft_join_clause_condition_list(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitLeft_join_clause_condition_list(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitLeft_join_clause_condition_list(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Left_join_clause_condition_listContext left_join_clause_condition_list() throws RecognitionException {
		Left_join_clause_condition_listContext _localctx = new Left_join_clause_condition_listContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_left_join_clause_condition_list);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(359);
			join_clause_condition_list();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Right_join_clause_condition_listContext extends ParserRuleContext {
		public Join_clause_condition_listContext join_clause_condition_list() {
			return getRuleContext(Join_clause_condition_listContext.class,0);
		}
		public Right_join_clause_condition_listContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_right_join_clause_condition_list; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterRight_join_clause_condition_list(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitRight_join_clause_condition_list(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitRight_join_clause_condition_list(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Right_join_clause_condition_listContext right_join_clause_condition_list() throws RecognitionException {
		Right_join_clause_condition_listContext _localctx = new Right_join_clause_condition_listContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_right_join_clause_condition_list);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(361);
			join_clause_condition_list();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Full_join_clause_condition_listContext extends ParserRuleContext {
		public Join_clause_condition_listContext join_clause_condition_list() {
			return getRuleContext(Join_clause_condition_listContext.class,0);
		}
		public Full_join_clause_condition_listContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_full_join_clause_condition_list; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterFull_join_clause_condition_list(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitFull_join_clause_condition_list(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitFull_join_clause_condition_list(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Full_join_clause_condition_listContext full_join_clause_condition_list() throws RecognitionException {
		Full_join_clause_condition_listContext _localctx = new Full_join_clause_condition_listContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_full_join_clause_condition_list);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(363);
			join_clause_condition_list();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Inner_join_clause_condition_listContext extends ParserRuleContext {
		public Join_clause_condition_listContext join_clause_condition_list() {
			return getRuleContext(Join_clause_condition_listContext.class,0);
		}
		public Inner_join_clause_condition_listContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_inner_join_clause_condition_list; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterInner_join_clause_condition_list(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitInner_join_clause_condition_list(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitInner_join_clause_condition_list(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Inner_join_clause_condition_listContext inner_join_clause_condition_list() throws RecognitionException {
		Inner_join_clause_condition_listContext _localctx = new Inner_join_clause_condition_listContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_inner_join_clause_condition_list);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(365);
			join_clause_condition_list();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Left_joinContext extends ParserRuleContext {
		public Left_joinContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_left_join; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterLeft_join(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitLeft_join(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitLeft_join(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Left_joinContext left_join() throws RecognitionException {
		Left_joinContext _localctx = new Left_joinContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_left_join);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(367);
			match(T__10);
			setState(369);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__11) {
				{
				setState(368);
				match(T__11);
				}
			}

			setState(371);
			match(T__12);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Right_joinContext extends ParserRuleContext {
		public Right_joinContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_right_join; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterRight_join(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitRight_join(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitRight_join(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Right_joinContext right_join() throws RecognitionException {
		Right_joinContext _localctx = new Right_joinContext(_ctx, getState());
		enterRule(_localctx, 56, RULE_right_join);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(373);
			match(T__13);
			setState(375);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__11) {
				{
				setState(374);
				match(T__11);
				}
			}

			setState(377);
			match(T__12);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Full_joinContext extends ParserRuleContext {
		public Full_joinContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_full_join; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterFull_join(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitFull_join(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitFull_join(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Full_joinContext full_join() throws RecognitionException {
		Full_joinContext _localctx = new Full_joinContext(_ctx, getState());
		enterRule(_localctx, 58, RULE_full_join);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(379);
			match(T__14);
			setState(381);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__11) {
				{
				setState(380);
				match(T__11);
				}
			}

			setState(383);
			match(T__12);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Inner_joinContext extends ParserRuleContext {
		public Inner_joinContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_inner_join; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterInner_join(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitInner_join(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitInner_join(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Inner_joinContext inner_join() throws RecognitionException {
		Inner_joinContext _localctx = new Inner_joinContext(_ctx, getState());
		enterRule(_localctx, 60, RULE_inner_join);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(385);
			match(T__15);
			setState(386);
			match(T__12);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Join_clause_condition_listContext extends ParserRuleContext {
		public Condition_listContext condition_list() {
			return getRuleContext(Condition_listContext.class,0);
		}
		public Join_clause_condition_listContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_join_clause_condition_list; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterJoin_clause_condition_list(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitJoin_clause_condition_list(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitJoin_clause_condition_list(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Join_clause_condition_listContext join_clause_condition_list() throws RecognitionException {
		Join_clause_condition_listContext _localctx = new Join_clause_condition_listContext(_ctx, getState());
		enterRule(_localctx, 62, RULE_join_clause_condition_list);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(388);
			condition_list();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Where_clauseContext extends ParserRuleContext {
		public Where_clause_condition_listContext where_clause_condition_list() {
			return getRuleContext(Where_clause_condition_listContext.class,0);
		}
		public Where_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_where_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterWhere_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitWhere_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitWhere_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Where_clauseContext where_clause() throws RecognitionException {
		Where_clauseContext _localctx = new Where_clauseContext(_ctx, getState());
		enterRule(_localctx, 64, RULE_where_clause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(390);
			match(T__16);
			setState(391);
			where_clause_condition_list();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Where_clause_condition_listContext extends ParserRuleContext {
		public Condition_listContext condition_list() {
			return getRuleContext(Condition_listContext.class,0);
		}
		public Where_clause_condition_listContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_where_clause_condition_list; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterWhere_clause_condition_list(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitWhere_clause_condition_list(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitWhere_clause_condition_list(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Where_clause_condition_listContext where_clause_condition_list() throws RecognitionException {
		Where_clause_condition_listContext _localctx = new Where_clause_condition_listContext(_ctx, getState());
		enterRule(_localctx, 66, RULE_where_clause_condition_list);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(393);
			condition_list();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Group_by_clauseContext extends ParserRuleContext {
		public Group_by_key_listContext group_by_key_list() {
			return getRuleContext(Group_by_key_listContext.class,0);
		}
		public Group_by_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_group_by_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterGroup_by_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitGroup_by_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitGroup_by_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Group_by_clauseContext group_by_clause() throws RecognitionException {
		Group_by_clauseContext _localctx = new Group_by_clauseContext(_ctx, getState());
		enterRule(_localctx, 68, RULE_group_by_clause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(395);
			match(T__17);
			setState(396);
			match(T__18);
			setState(397);
			group_by_key_list();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Group_by_key_listContext extends ParserRuleContext {
		public List<Group_by_keyContext> group_by_key() {
			return getRuleContexts(Group_by_keyContext.class);
		}
		public Group_by_keyContext group_by_key(int i) {
			return getRuleContext(Group_by_keyContext.class,i);
		}
		public Group_by_key_listContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_group_by_key_list; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterGroup_by_key_list(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitGroup_by_key_list(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitGroup_by_key_list(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Group_by_key_listContext group_by_key_list() throws RecognitionException {
		Group_by_key_listContext _localctx = new Group_by_key_listContext(_ctx, getState());
		enterRule(_localctx, 70, RULE_group_by_key_list);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(399);
			group_by_key();
			setState(404);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(400);
				match(T__0);
				setState(401);
				group_by_key();
				}
				}
				setState(406);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Group_by_keyContext extends ParserRuleContext {
		public List<Group_key_factorContext> group_key_factor() {
			return getRuleContexts(Group_key_factorContext.class);
		}
		public Group_key_factorContext group_key_factor(int i) {
			return getRuleContext(Group_key_factorContext.class,i);
		}
		public List<OperatorContext> operator() {
			return getRuleContexts(OperatorContext.class);
		}
		public OperatorContext operator(int i) {
			return getRuleContext(OperatorContext.class,i);
		}
		public Group_by_keyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_group_by_key; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterGroup_by_key(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitGroup_by_key(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitGroup_by_key(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Group_by_keyContext group_by_key() throws RecognitionException {
		Group_by_keyContext _localctx = new Group_by_keyContext(_ctx, getState());
		enterRule(_localctx, 72, RULE_group_by_key);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(407);
			group_key_factor();
			setState(413);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (((((_la - 42)) & ~0x3f) == 0 && ((1L << (_la - 42)) & ((1L << (T__41 - 42)) | (1L << (T__44 - 42)) | (1L << (T__51 - 42)) | (1L << (T__52 - 42)) | (1L << (T__53 - 42)) | (1L << (T__54 - 42)) | (1L << (T__55 - 42)) | (1L << (T__56 - 42)) | (1L << (T__57 - 42)) | (1L << (T__58 - 42)) | (1L << (T__59 - 42)) | (1L << (T__60 - 42)) | (1L << (T__61 - 42)) | (1L << (T__62 - 42)) | (1L << (T__63 - 42)) | (1L << (T__64 - 42)) | (1L << (T__65 - 42)))) != 0)) {
				{
				{
				setState(408);
				operator();
				setState(409);
				group_key_factor();
				}
				}
				setState(415);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Group_key_factorContext extends ParserRuleContext {
		public FieldContext field() {
			return getRuleContext(FieldContext.class,0);
		}
		public FunctionContext function() {
			return getRuleContext(FunctionContext.class,0);
		}
		public Hard_codeContext hard_code() {
			return getRuleContext(Hard_codeContext.class,0);
		}
		public Group_key_factorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_group_key_factor; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterGroup_key_factor(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitGroup_key_factor(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitGroup_key_factor(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Group_key_factorContext group_key_factor() throws RecognitionException {
		Group_key_factorContext _localctx = new Group_key_factorContext(_ctx, getState());
		enterRule(_localctx, 74, RULE_group_key_factor);
		try {
			setState(419);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,41,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(416);
				field();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(417);
				function();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(418);
				hard_code();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FunctionContext extends ParserRuleContext {
		public Function_nameContext function_name() {
			return getRuleContext(Function_nameContext.class,0);
		}
		public List<Parm_listContext> parm_list() {
			return getRuleContexts(Parm_listContext.class);
		}
		public Parm_listContext parm_list(int i) {
			return getRuleContext(Parm_listContext.class,i);
		}
		public ParentheseContext parenthese() {
			return getRuleContext(ParentheseContext.class,0);
		}
		public List<Condition_listContext> condition_list() {
			return getRuleContexts(Condition_listContext.class);
		}
		public Condition_listContext condition_list(int i) {
			return getRuleContext(Condition_listContext.class,i);
		}
		public FunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_function; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FunctionContext function() throws RecognitionException {
		FunctionContext _localctx = new FunctionContext(_ctx, getState());
		enterRule(_localctx, 76, RULE_function);
		int _la;
		try {
			setState(496);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,50,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(421);
				function_name();
				setState(422);
				match(T__3);
				setState(423);
				parm_list();
				setState(427);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==T__19) {
					{
					setState(424);
					match(T__19);
					setState(425);
					match(T__18);
					setState(426);
					parm_list();
					}
				}

				setState(429);
				match(T__4);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(431);
				function_name();
				setState(440);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,44,_ctx) ) {
				case 1:
					{
					setState(432);
					parenthese();
					}
					break;
				case 2:
					{
					setState(433);
					match(T__3);
					setState(435);
					_errHandler.sync(this);
					_la = _input.LA(1);
					if (_la==T__6) {
						{
						setState(434);
						match(T__6);
						}
					}

					setState(437);
					parm_list();
					setState(438);
					match(T__4);
					}
					break;
				}
				setState(442);
				match(T__20);
				setState(443);
				match(T__3);
				setState(447);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==T__21) {
					{
					setState(444);
					match(T__21);
					setState(445);
					match(T__18);
					setState(446);
					parm_list();
					}
				}

				setState(455);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==T__19) {
					{
					setState(449);
					match(T__19);
					setState(450);
					match(T__18);
					setState(451);
					parm_list();
					setState(453);
					_errHandler.sync(this);
					_la = _input.LA(1);
					if (_la==T__22 || _la==T__23) {
						{
						setState(452);
						_la = _input.LA(1);
						if ( !(_la==T__22 || _la==T__23) ) {
						_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						}
					}

					}
				}

				setState(457);
				match(T__4);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(459);
				match(T__24);
				setState(465); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(460);
					match(T__25);
					setState(461);
					condition_list();
					setState(462);
					match(T__26);
					setState(463);
					parm_list();
					}
					}
					setState(467); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( _la==T__25 );
				setState(471);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==T__27) {
					{
					setState(469);
					match(T__27);
					setState(470);
					parm_list();
					}
				}

				setState(473);
				match(T__28);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(475);
				function_name();
				setState(476);
				match(T__3);
				setState(477);
				parm_list();
				setState(478);
				match(T__29);
				setState(479);
				parenthese();
				setState(480);
				match(T__0);
				setState(481);
				parm_list();
				setState(482);
				match(T__4);
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(484);
				function_name();
				setState(485);
				match(T__3);
				setState(486);
				parm_list();
				setState(487);
				match(T__4);
				setState(488);
				match(T__30);
				setState(489);
				match(T__17);
				setState(490);
				match(T__3);
				setState(491);
				match(T__19);
				setState(492);
				match(T__18);
				setState(493);
				parm_list();
				setState(494);
				match(T__4);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Function_nameContext extends ParserRuleContext {
		public Function_nameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_function_name; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterFunction_name(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitFunction_name(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitFunction_name(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Function_nameContext function_name() throws RecognitionException {
		Function_nameContext _localctx = new Function_nameContext(_ctx, getState());
		enterRule(_localctx, 78, RULE_function_name);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(498);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__31) | (1L << T__32) | (1L << T__33) | (1L << T__34) | (1L << T__35) | (1L << T__36) | (1L << T__37) | (1L << T__38) | (1L << T__39) | (1L << T__40))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Condition_listContext extends ParserRuleContext {
		public List<ConditionContext> condition() {
			return getRuleContexts(ConditionContext.class);
		}
		public ConditionContext condition(int i) {
			return getRuleContext(ConditionContext.class,i);
		}
		public List<OperatorContext> operator() {
			return getRuleContexts(OperatorContext.class);
		}
		public OperatorContext operator(int i) {
			return getRuleContext(OperatorContext.class,i);
		}
		public Condition_listContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_condition_list; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterCondition_list(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitCondition_list(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitCondition_list(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Condition_listContext condition_list() throws RecognitionException {
		Condition_listContext _localctx = new Condition_listContext(_ctx, getState());
		enterRule(_localctx, 80, RULE_condition_list);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(501);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__3) {
				{
				setState(500);
				match(T__3);
				}
			}

			setState(503);
			condition();
			setState(514);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (((((_la - 42)) & ~0x3f) == 0 && ((1L << (_la - 42)) & ((1L << (T__41 - 42)) | (1L << (T__44 - 42)) | (1L << (T__51 - 42)) | (1L << (T__52 - 42)) | (1L << (T__53 - 42)) | (1L << (T__54 - 42)) | (1L << (T__55 - 42)) | (1L << (T__56 - 42)) | (1L << (T__57 - 42)) | (1L << (T__58 - 42)) | (1L << (T__59 - 42)) | (1L << (T__60 - 42)) | (1L << (T__61 - 42)) | (1L << (T__62 - 42)) | (1L << (T__63 - 42)) | (1L << (T__64 - 42)) | (1L << (T__65 - 42)))) != 0)) {
				{
				{
				setState(504);
				operator();
				setState(506);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==T__3) {
					{
					setState(505);
					match(T__3);
					}
				}

				setState(508);
				condition();
				setState(510);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,53,_ctx) ) {
				case 1:
					{
					setState(509);
					match(T__4);
					}
					break;
				}
				}
				}
				setState(516);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ConditionContext extends ParserRuleContext {
		public List<FieldContext> field() {
			return getRuleContexts(FieldContext.class);
		}
		public FieldContext field(int i) {
			return getRuleContext(FieldContext.class,i);
		}
		public OperatorContext operator() {
			return getRuleContext(OperatorContext.class,0);
		}
		public Parm_listContext parm_list() {
			return getRuleContext(Parm_listContext.class,0);
		}
		public Query_script_listContext query_script_list() {
			return getRuleContext(Query_script_listContext.class,0);
		}
		public ConditionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_condition; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterCondition(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitCondition(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitCondition(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ConditionContext condition() throws RecognitionException {
		ConditionContext _localctx = new ConditionContext(_ctx, getState());
		enterRule(_localctx, 82, RULE_condition);
		try {
			setState(531);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,57,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(517);
				field();
				setState(518);
				operator();
				setState(520);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,55,_ctx) ) {
				case 1:
					{
					setState(519);
					field();
					}
					break;
				}
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(522);
				field();
				setState(523);
				operator();
				setState(524);
				match(T__3);
				setState(527);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,56,_ctx) ) {
				case 1:
					{
					setState(525);
					parm_list();
					}
					break;
				case 2:
					{
					setState(526);
					query_script_list();
					}
					break;
				}
				setState(529);
				match(T__4);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Parm_listContext extends ParserRuleContext {
		public List<ParmContext> parm() {
			return getRuleContexts(ParmContext.class);
		}
		public ParmContext parm(int i) {
			return getRuleContext(ParmContext.class,i);
		}
		public List<Parm_xmlparseContext> parm_xmlparse() {
			return getRuleContexts(Parm_xmlparseContext.class);
		}
		public Parm_xmlparseContext parm_xmlparse(int i) {
			return getRuleContext(Parm_xmlparseContext.class,i);
		}
		public Parm_listContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parm_list; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterParm_list(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitParm_list(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitParm_list(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Parm_listContext parm_list() throws RecognitionException {
		Parm_listContext _localctx = new Parm_listContext(_ctx, getState());
		enterRule(_localctx, 84, RULE_parm_list);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(535);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,58,_ctx) ) {
			case 1:
				{
				setState(533);
				parm();
				}
				break;
			case 2:
				{
				setState(534);
				parm_xmlparse();
				}
				break;
			}
			setState(544);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0 || _la==T__41) {
				{
				{
				setState(537);
				_la = _input.LA(1);
				if ( !(_la==T__0 || _la==T__41) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(540);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,59,_ctx) ) {
				case 1:
					{
					setState(538);
					parm();
					}
					break;
				case 2:
					{
					setState(539);
					parm_xmlparse();
					}
					break;
				}
				}
				}
				setState(546);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Parm_xmlparseContext extends ParserRuleContext {
		public ParmContext parm() {
			return getRuleContext(ParmContext.class,0);
		}
		public Parm_xmlparseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parm_xmlparse; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterParm_xmlparse(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitParm_xmlparse(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitParm_xmlparse(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Parm_xmlparseContext parm_xmlparse() throws RecognitionException {
		Parm_xmlparseContext _localctx = new Parm_xmlparseContext(_ctx, getState());
		enterRule(_localctx, 86, RULE_parm_xmlparse);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(548);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__42) {
				{
				setState(547);
				match(T__42);
				}
			}

			setState(550);
			parm();
			setState(552);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__43) {
				{
				setState(551);
				match(T__43);
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ParmContext extends ParserRuleContext {
		public FieldContext field() {
			return getRuleContext(FieldContext.class,0);
		}
		public ParmContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parm; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterParm(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitParm(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitParm(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ParmContext parm() throws RecognitionException {
		ParmContext _localctx = new ParmContext(_ctx, getState());
		enterRule(_localctx, 88, RULE_parm);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(554);
			field();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FieldContext extends ParserRuleContext {
		public TerminalNode STRING() { return getToken(tableColumnParser.STRING, 0); }
		public Hard_codeContext hard_code() {
			return getRuleContext(Hard_codeContext.class,0);
		}
		public FunctionContext function() {
			return getRuleContext(FunctionContext.class,0);
		}
		public Table_aliasContext table_alias() {
			return getRuleContext(Table_aliasContext.class,0);
		}
		public FieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_field; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FieldContext field() throws RecognitionException {
		FieldContext _localctx = new FieldContext(_ctx, getState());
		enterRule(_localctx, 90, RULE_field);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(559);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,63,_ctx) ) {
			case 1:
				{
				setState(556);
				table_alias();
				setState(557);
				match(T__8);
				}
				break;
			}
			setState(566);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__44:
				{
				setState(561);
				match(T__44);
				}
				break;
			case STRING:
				{
				setState(562);
				match(STRING);
				}
				break;
			case T__45:
				{
				setState(563);
				match(T__45);
				}
				break;
			case T__46:
				{
				setState(564);
				hard_code();
				}
				break;
			case T__24:
			case T__31:
			case T__32:
			case T__33:
			case T__34:
			case T__35:
			case T__36:
			case T__37:
			case T__38:
			case T__39:
			case T__40:
				{
				setState(565);
				function();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Hard_codeContext extends ParserRuleContext {
		public Hard_codeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_hard_code; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterHard_code(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitHard_code(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitHard_code(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Hard_codeContext hard_code() throws RecognitionException {
		Hard_codeContext _localctx = new Hard_codeContext(_ctx, getState());
		enterRule(_localctx, 92, RULE_hard_code);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(568);
			match(T__46);
			setState(573);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << T__1) | (1L << T__2) | (1L << T__3) | (1L << T__4) | (1L << T__5) | (1L << T__6) | (1L << T__7) | (1L << T__8) | (1L << T__9) | (1L << T__10) | (1L << T__11) | (1L << T__12) | (1L << T__13) | (1L << T__14) | (1L << T__15) | (1L << T__16) | (1L << T__17) | (1L << T__18) | (1L << T__19) | (1L << T__20) | (1L << T__21) | (1L << T__22) | (1L << T__23) | (1L << T__24) | (1L << T__25) | (1L << T__26) | (1L << T__27) | (1L << T__28) | (1L << T__29) | (1L << T__30) | (1L << T__31) | (1L << T__32) | (1L << T__33) | (1L << T__34) | (1L << T__35) | (1L << T__36) | (1L << T__37) | (1L << T__38) | (1L << T__39) | (1L << T__40) | (1L << T__41) | (1L << T__42) | (1L << T__43) | (1L << T__44) | (1L << T__45) | (1L << T__47) | (1L << T__48) | (1L << T__49) | (1L << T__50) | (1L << T__51) | (1L << T__52) | (1L << T__53) | (1L << T__54) | (1L << T__55) | (1L << T__56) | (1L << T__57) | (1L << T__58) | (1L << T__59) | (1L << T__60) | (1L << T__61) | (1L << T__62))) != 0) || ((((_la - 64)) & ~0x3f) == 0 && ((1L << (_la - 64)) & ((1L << (T__63 - 64)) | (1L << (T__64 - 64)) | (1L << (T__65 - 64)) | (1L << (T__66 - 64)) | (1L << (STRING - 64)) | (1L << (SINGLE_LINE_COMMENT - 64)) | (1L << (MULTI_LINE_COMMENT - 64)) | (1L << (SPACES - 64)))) != 0)) {
				{
				setState(571);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case T__0:
				case T__1:
				case T__2:
				case T__3:
				case T__4:
				case T__5:
				case T__6:
				case T__7:
				case T__8:
				case T__9:
				case T__10:
				case T__11:
				case T__12:
				case T__13:
				case T__14:
				case T__15:
				case T__16:
				case T__17:
				case T__18:
				case T__19:
				case T__20:
				case T__21:
				case T__22:
				case T__23:
				case T__24:
				case T__25:
				case T__26:
				case T__27:
				case T__28:
				case T__29:
				case T__30:
				case T__31:
				case T__32:
				case T__33:
				case T__34:
				case T__35:
				case T__36:
				case T__37:
				case T__38:
				case T__39:
				case T__40:
				case T__41:
				case T__42:
				case T__43:
				case T__44:
				case T__45:
				case T__48:
				case T__49:
				case T__50:
				case T__51:
				case T__52:
				case T__53:
				case T__54:
				case T__55:
				case T__56:
				case T__57:
				case T__58:
				case T__59:
				case T__60:
				case T__61:
				case T__62:
				case T__63:
				case T__64:
				case T__65:
				case T__66:
				case STRING:
				case SINGLE_LINE_COMMENT:
				case MULTI_LINE_COMMENT:
				case SPACES:
					{
					setState(569);
					_la = _input.LA(1);
					if ( _la <= 0 || (_la==T__46 || _la==T__47) ) {
					_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					}
					break;
				case T__47:
					{
					setState(570);
					match(T__47);
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				setState(575);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(576);
			match(T__46);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Set_operatorContext extends ParserRuleContext {
		public Set_operatorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_set_operator; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterSet_operator(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitSet_operator(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitSet_operator(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Set_operatorContext set_operator() throws RecognitionException {
		Set_operatorContext _localctx = new Set_operatorContext(_ctx, getState());
		enterRule(_localctx, 94, RULE_set_operator);
		try {
			setState(582);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,67,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(578);
				match(T__48);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(579);
				match(T__49);
				setState(580);
				match(T__50);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(581);
				match(T__49);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class OperatorContext extends ParserRuleContext {
		public OperatorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_operator; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterOperator(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitOperator(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitOperator(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OperatorContext operator() throws RecognitionException {
		OperatorContext _localctx = new OperatorContext(_ctx, getState());
		enterRule(_localctx, 96, RULE_operator);
		int _la;
		try {
			setState(607);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__51:
				enterOuterAlt(_localctx, 1);
				{
				setState(584);
				match(T__51);
				}
				break;
			case T__52:
				enterOuterAlt(_localctx, 2);
				{
				setState(585);
				match(T__52);
				}
				break;
			case T__53:
				enterOuterAlt(_localctx, 3);
				{
				setState(586);
				match(T__53);
				}
				break;
			case T__54:
				enterOuterAlt(_localctx, 4);
				{
				setState(587);
				match(T__54);
				}
				break;
			case T__55:
				enterOuterAlt(_localctx, 5);
				{
				setState(588);
				match(T__55);
				}
				break;
			case T__56:
				enterOuterAlt(_localctx, 6);
				{
				setState(589);
				match(T__56);
				}
				break;
			case T__57:
				enterOuterAlt(_localctx, 7);
				{
				setState(590);
				match(T__57);
				}
				break;
			case T__58:
				enterOuterAlt(_localctx, 8);
				{
				setState(591);
				match(T__58);
				}
				break;
			case T__59:
				enterOuterAlt(_localctx, 9);
				{
				setState(592);
				match(T__59);
				}
				break;
			case T__60:
				enterOuterAlt(_localctx, 10);
				{
				setState(593);
				match(T__60);
				}
				break;
			case T__44:
				enterOuterAlt(_localctx, 11);
				{
				setState(594);
				match(T__44);
				}
				break;
			case T__61:
				enterOuterAlt(_localctx, 12);
				{
				setState(595);
				match(T__61);
				}
				break;
			case T__62:
				enterOuterAlt(_localctx, 13);
				{
				setState(596);
				match(T__62);
				}
				break;
			case T__63:
				enterOuterAlt(_localctx, 14);
				{
				setState(597);
				match(T__63);
				setState(599);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==T__64) {
					{
					setState(598);
					match(T__64);
					}
				}

				setState(601);
				match(T__45);
				}
				break;
			case T__64:
			case T__65:
				enterOuterAlt(_localctx, 15);
				{
				setState(603);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==T__64) {
					{
					setState(602);
					match(T__64);
					}
				}

				setState(605);
				match(T__65);
				}
				break;
			case T__41:
				enterOuterAlt(_localctx, 16);
				{
				setState(606);
				match(T__41);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Temporary_table_nameContext extends ParserRuleContext {
		public TerminalNode STRING() { return getToken(tableColumnParser.STRING, 0); }
		public Temporary_table_nameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_temporary_table_name; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterTemporary_table_name(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitTemporary_table_name(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitTemporary_table_name(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Temporary_table_nameContext temporary_table_name() throws RecognitionException {
		Temporary_table_nameContext _localctx = new Temporary_table_nameContext(_ctx, getState());
		enterRule(_localctx, 98, RULE_temporary_table_name);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(609);
			match(STRING);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ParentheseContext extends ParserRuleContext {
		public ParentheseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parenthese; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterParenthese(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitParenthese(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitParenthese(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ParentheseContext parenthese() throws RecognitionException {
		ParentheseContext _localctx = new ParentheseContext(_ctx, getState());
		enterRule(_localctx, 100, RULE_parenthese);
		try {
			setState(614);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__3:
				enterOuterAlt(_localctx, 1);
				{
				setState(611);
				match(T__3);
				setState(612);
				match(T__4);
				}
				break;
			case T__66:
				enterOuterAlt(_localctx, 2);
				{
				setState(613);
				match(T__66);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Column_aliasContext extends ParserRuleContext {
		public TerminalNode STRING() { return getToken(tableColumnParser.STRING, 0); }
		public Column_aliasContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_column_alias; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterColumn_alias(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitColumn_alias(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitColumn_alias(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Column_aliasContext column_alias() throws RecognitionException {
		Column_aliasContext _localctx = new Column_aliasContext(_ctx, getState());
		enterRule(_localctx, 102, RULE_column_alias);
		try {
			setState(620);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case STRING:
				enterOuterAlt(_localctx, 1);
				{
				setState(616);
				match(STRING);
				}
				break;
			case T__46:
				enterOuterAlt(_localctx, 2);
				{
				setState(617);
				match(T__46);
				setState(618);
				match(STRING);
				setState(619);
				match(T__46);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SchemaContext extends ParserRuleContext {
		public TerminalNode STRING() { return getToken(tableColumnParser.STRING, 0); }
		public SchemaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_schema; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterSchema(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitSchema(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitSchema(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SchemaContext schema() throws RecognitionException {
		SchemaContext _localctx = new SchemaContext(_ctx, getState());
		enterRule(_localctx, 104, RULE_schema);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(622);
			match(STRING);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Table_aliasContext extends ParserRuleContext {
		public TerminalNode STRING() { return getToken(tableColumnParser.STRING, 0); }
		public Table_aliasContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_table_alias; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).enterTable_alias(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof tableColumnListener ) ((tableColumnListener)listener).exitTable_alias(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof tableColumnVisitor ) return ((tableColumnVisitor<? extends T>)visitor).visitTable_alias(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Table_aliasContext table_alias() throws RecognitionException {
		Table_aliasContext _localctx = new Table_aliasContext(_ctx, getState());
		enterRule(_localctx, 106, RULE_table_alias);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(624);
			match(STRING);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3I\u0275\4\2\t\2\4"+
		"\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t"+
		"\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\4\31\t\31"+
		"\4\32\t\32\4\33\t\33\4\34\t\34\4\35\t\35\4\36\t\36\4\37\t\37\4 \t \4!"+
		"\t!\4\"\t\"\4#\t#\4$\t$\4%\t%\4&\t&\4\'\t\'\4(\t(\4)\t)\4*\t*\4+\t+\4"+
		",\t,\4-\t-\4.\t.\4/\t/\4\60\t\60\4\61\t\61\4\62\t\62\4\63\t\63\4\64\t"+
		"\64\4\65\t\65\4\66\t\66\4\67\t\67\3\2\3\2\3\3\7\3r\n\3\f\3\16\3u\13\3"+
		"\3\3\3\3\3\4\3\4\3\4\7\4|\n\4\f\4\16\4\177\13\4\3\5\5\5\u0082\n\5\3\5"+
		"\3\5\3\5\3\5\3\5\3\5\3\6\3\6\3\6\3\6\7\6\u008e\n\6\f\6\16\6\u0091\13\6"+
		"\3\7\3\7\3\7\3\7\7\7\u0097\n\7\f\7\16\7\u009a\13\7\3\b\5\b\u009d\n\b\3"+
		"\b\3\b\3\b\7\b\u00a2\n\b\f\b\16\b\u00a5\13\b\3\b\7\b\u00a8\n\b\f\b\16"+
		"\b\u00ab\13\b\3\b\7\b\u00ae\n\b\f\b\16\b\u00b1\13\b\3\b\5\b\u00b4\n\b"+
		"\3\t\3\t\5\t\u00b8\n\t\3\t\3\t\3\n\3\n\3\n\7\n\u00bf\n\n\f\n\16\n\u00c2"+
		"\13\n\3\13\3\13\3\13\3\13\7\13\u00c8\n\13\f\13\16\13\u00cb\13\13\3\13"+
		"\5\13\u00ce\n\13\3\13\5\13\u00d1\n\13\3\f\3\f\3\f\3\f\3\f\3\f\3\f\5\f"+
		"\u00da\n\f\3\f\3\f\3\f\3\f\3\f\5\f\u00e1\n\f\7\f\u00e3\n\f\f\f\16\f\u00e6"+
		"\13\f\5\f\u00e8\n\f\3\r\3\r\3\r\3\r\7\r\u00ee\n\r\f\r\16\r\u00f1\13\r"+
		"\3\16\5\16\u00f4\n\16\3\16\3\16\5\16\u00f8\n\16\3\16\3\16\5\16\u00fc\n"+
		"\16\3\16\3\16\5\16\u0100\n\16\7\16\u0102\n\16\f\16\16\16\u0105\13\16\3"+
		"\17\3\17\3\17\5\17\u010a\n\17\3\17\3\17\5\17\u010e\n\17\3\20\3\20\3\20"+
		"\3\20\5\20\u0114\n\20\3\21\3\21\3\21\3\21\3\21\3\21\3\21\5\21\u011d\n"+
		"\21\3\21\3\21\3\21\3\22\3\22\3\22\3\22\3\22\3\22\3\22\5\22\u0129\n\22"+
		"\3\22\3\22\3\22\3\23\3\23\3\23\3\23\3\23\3\23\3\23\5\23\u0135\n\23\3\23"+
		"\3\23\3\23\3\24\3\24\3\24\3\24\3\24\3\24\3\24\5\24\u0141\n\24\3\24\3\24"+
		"\3\24\3\25\3\25\3\25\3\25\7\25\u014a\n\25\f\25\16\25\u014d\13\25\3\26"+
		"\3\26\3\26\3\26\7\26\u0153\n\26\f\26\16\26\u0156\13\26\3\27\3\27\3\27"+
		"\3\27\7\27\u015c\n\27\f\27\16\27\u015f\13\27\3\30\3\30\3\30\3\30\7\30"+
		"\u0165\n\30\f\30\16\30\u0168\13\30\3\31\3\31\3\32\3\32\3\33\3\33\3\34"+
		"\3\34\3\35\3\35\5\35\u0174\n\35\3\35\3\35\3\36\3\36\5\36\u017a\n\36\3"+
		"\36\3\36\3\37\3\37\5\37\u0180\n\37\3\37\3\37\3 \3 \3 \3!\3!\3\"\3\"\3"+
		"\"\3#\3#\3$\3$\3$\3$\3%\3%\3%\7%\u0195\n%\f%\16%\u0198\13%\3&\3&\3&\3"+
		"&\7&\u019e\n&\f&\16&\u01a1\13&\3\'\3\'\3\'\5\'\u01a6\n\'\3(\3(\3(\3(\3"+
		"(\3(\5(\u01ae\n(\3(\3(\3(\3(\3(\3(\5(\u01b6\n(\3(\3(\3(\5(\u01bb\n(\3"+
		"(\3(\3(\3(\3(\5(\u01c2\n(\3(\3(\3(\3(\5(\u01c8\n(\5(\u01ca\n(\3(\3(\3"+
		"(\3(\3(\3(\3(\3(\6(\u01d4\n(\r(\16(\u01d5\3(\3(\5(\u01da\n(\3(\3(\3(\3"+
		"(\3(\3(\3(\3(\3(\3(\3(\3(\3(\3(\3(\3(\3(\3(\3(\3(\3(\3(\3(\5(\u01f3\n"+
		"(\3)\3)\3*\5*\u01f8\n*\3*\3*\3*\5*\u01fd\n*\3*\3*\5*\u0201\n*\7*\u0203"+
		"\n*\f*\16*\u0206\13*\3+\3+\3+\5+\u020b\n+\3+\3+\3+\3+\3+\5+\u0212\n+\3"+
		"+\3+\5+\u0216\n+\3,\3,\5,\u021a\n,\3,\3,\3,\5,\u021f\n,\7,\u0221\n,\f"+
		",\16,\u0224\13,\3-\5-\u0227\n-\3-\3-\5-\u022b\n-\3.\3.\3/\3/\3/\5/\u0232"+
		"\n/\3/\3/\3/\3/\3/\5/\u0239\n/\3\60\3\60\3\60\7\60\u023e\n\60\f\60\16"+
		"\60\u0241\13\60\3\60\3\60\3\61\3\61\3\61\3\61\5\61\u0249\n\61\3\62\3\62"+
		"\3\62\3\62\3\62\3\62\3\62\3\62\3\62\3\62\3\62\3\62\3\62\3\62\3\62\5\62"+
		"\u025a\n\62\3\62\3\62\5\62\u025e\n\62\3\62\3\62\5\62\u0262\n\62\3\63\3"+
		"\63\3\64\3\64\3\64\5\64\u0269\n\64\3\65\3\65\3\65\3\65\5\65\u026f\n\65"+
		"\3\66\3\66\3\67\3\67\3\67\2\28\2\4\6\b\n\f\16\20\22\24\26\30\32\34\36"+
		" \"$&(*,.\60\62\64\668:<>@BDFHJLNPRTVXZ\\^`bdfhjl\2\6\3\2\31\32\3\2\""+
		"+\4\2\3\3,,\3\2\61\62\2\u029f\2n\3\2\2\2\4s\3\2\2\2\6x\3\2\2\2\b\u0081"+
		"\3\2\2\2\n\u0089\3\2\2\2\f\u0092\3\2\2\2\16\u009c\3\2\2\2\20\u00b5\3\2"+
		"\2\2\22\u00bb\3\2\2\2\24\u00c3\3\2\2\2\26\u00e7\3\2\2\2\30\u00e9\3\2\2"+
		"\2\32\u00f3\3\2\2\2\34\u0109\3\2\2\2\36\u0113\3\2\2\2 \u0115\3\2\2\2\""+
		"\u0121\3\2\2\2$\u012d\3\2\2\2&\u0139\3\2\2\2(\u0145\3\2\2\2*\u014e\3\2"+
		"\2\2,\u0157\3\2\2\2.\u0160\3\2\2\2\60\u0169\3\2\2\2\62\u016b\3\2\2\2\64"+
		"\u016d\3\2\2\2\66\u016f\3\2\2\28\u0171\3\2\2\2:\u0177\3\2\2\2<\u017d\3"+
		"\2\2\2>\u0183\3\2\2\2@\u0186\3\2\2\2B\u0188\3\2\2\2D\u018b\3\2\2\2F\u018d"+
		"\3\2\2\2H\u0191\3\2\2\2J\u0199\3\2\2\2L\u01a5\3\2\2\2N\u01f2\3\2\2\2P"+
		"\u01f4\3\2\2\2R\u01f7\3\2\2\2T\u0215\3\2\2\2V\u0219\3\2\2\2X\u0226\3\2"+
		"\2\2Z\u022c\3\2\2\2\\\u0231\3\2\2\2^\u023a\3\2\2\2`\u0248\3\2\2\2b\u0261"+
		"\3\2\2\2d\u0263\3\2\2\2f\u0268\3\2\2\2h\u026e\3\2\2\2j\u0270\3\2\2\2l"+
		"\u0272\3\2\2\2no\5\4\3\2o\3\3\2\2\2pr\5\6\4\2qp\3\2\2\2ru\3\2\2\2sq\3"+
		"\2\2\2st\3\2\2\2tv\3\2\2\2us\3\2\2\2vw\5\f\7\2w\5\3\2\2\2x}\5\b\5\2yz"+
		"\7\3\2\2z|\5\b\5\2{y\3\2\2\2|\177\3\2\2\2}{\3\2\2\2}~\3\2\2\2~\7\3\2\2"+
		"\2\177}\3\2\2\2\u0080\u0082\7\4\2\2\u0081\u0080\3\2\2\2\u0081\u0082\3"+
		"\2\2\2\u0082\u0083\3\2\2\2\u0083\u0084\5d\63\2\u0084\u0085\7\5\2\2\u0085"+
		"\u0086\7\6\2\2\u0086\u0087\5\n\6\2\u0087\u0088\7\7\2\2\u0088\t\3\2\2\2"+
		"\u0089\u008f\5\16\b\2\u008a\u008b\5`\61\2\u008b\u008c\5\16\b\2\u008c\u008e"+
		"\3\2\2\2\u008d\u008a\3\2\2\2\u008e\u0091\3\2\2\2\u008f\u008d\3\2\2\2\u008f"+
		"\u0090\3\2\2\2\u0090\13\3\2\2\2\u0091\u008f\3\2\2\2\u0092\u0098\5\16\b"+
		"\2\u0093\u0094\5`\61\2\u0094\u0095\5\16\b\2\u0095\u0097\3\2\2\2\u0096"+
		"\u0093\3\2\2\2\u0097\u009a\3\2\2\2\u0098\u0096\3\2\2\2\u0098\u0099\3\2"+
		"\2\2\u0099\r\3\2\2\2\u009a\u0098\3\2\2\2\u009b\u009d\7\6\2\2\u009c\u009b"+
		"\3\2\2\2\u009c\u009d\3\2\2\2\u009d\u009e\3\2\2\2\u009e\u009f\5\20\t\2"+
		"\u009f\u00a3\5\26\f\2\u00a0\u00a2\5\36\20\2\u00a1\u00a0\3\2\2\2\u00a2"+
		"\u00a5\3\2\2\2\u00a3\u00a1\3\2\2\2\u00a3\u00a4\3\2\2\2\u00a4\u00a9\3\2"+
		"\2\2\u00a5\u00a3\3\2\2\2\u00a6\u00a8\5B\"\2\u00a7\u00a6\3\2\2\2\u00a8"+
		"\u00ab\3\2\2\2\u00a9\u00a7\3\2\2\2\u00a9\u00aa\3\2\2\2\u00aa\u00af\3\2"+
		"\2\2\u00ab\u00a9\3\2\2\2\u00ac\u00ae\5F$\2\u00ad\u00ac\3\2\2\2\u00ae\u00b1"+
		"\3\2\2\2\u00af\u00ad\3\2\2\2\u00af\u00b0\3\2\2\2\u00b0\u00b3\3\2\2\2\u00b1"+
		"\u00af\3\2\2\2\u00b2\u00b4\7\7\2\2\u00b3\u00b2\3\2\2\2\u00b3\u00b4\3\2"+
		"\2\2\u00b4\17\3\2\2\2\u00b5\u00b7\7\b\2\2\u00b6\u00b8\7\t\2\2\u00b7\u00b6"+
		"\3\2\2\2\u00b7\u00b8\3\2\2\2\u00b8\u00b9\3\2\2\2\u00b9\u00ba\5\22\n\2"+
		"\u00ba\21\3\2\2\2\u00bb\u00c0\5\24\13\2\u00bc\u00bd\7\3\2\2\u00bd\u00bf"+
		"\5\24\13\2\u00be\u00bc\3\2\2\2\u00bf\u00c2\3\2\2\2\u00c0\u00be\3\2\2\2"+
		"\u00c0\u00c1\3\2\2\2\u00c1\23\3\2\2\2\u00c2\u00c0\3\2\2\2\u00c3\u00c9"+
		"\5\\/\2\u00c4\u00c5\5b\62\2\u00c5\u00c6\5\\/\2\u00c6\u00c8\3\2\2\2\u00c7"+
		"\u00c4\3\2\2\2\u00c8\u00cb\3\2\2\2\u00c9\u00c7\3\2\2\2\u00c9\u00ca\3\2"+
		"\2\2\u00ca\u00cd\3\2\2\2\u00cb\u00c9\3\2\2\2\u00cc\u00ce\7\5\2\2\u00cd"+
		"\u00cc\3\2\2\2\u00cd\u00ce\3\2\2\2\u00ce\u00d0\3\2\2\2\u00cf\u00d1\5h"+
		"\65\2\u00d0\u00cf\3\2\2\2\u00d0\u00d1\3\2\2\2\u00d1\25\3\2\2\2\u00d2\u00d3"+
		"\7\n\2\2\u00d3\u00e8\5\32\16\2\u00d4\u00d5\7\n\2\2\u00d5\u00d6\7\6\2\2"+
		"\u00d6\u00d7\5\30\r\2\u00d7\u00d9\7\7\2\2\u00d8\u00da\5l\67\2\u00d9\u00d8"+
		"\3\2\2\2\u00d9\u00da\3\2\2\2\u00da\u00e4\3\2\2\2\u00db\u00dc\7\3\2\2\u00dc"+
		"\u00dd\7\6\2\2\u00dd\u00de\5\30\r\2\u00de\u00e0\7\7\2\2\u00df\u00e1\5"+
		"l\67\2\u00e0\u00df\3\2\2\2\u00e0\u00e1\3\2\2\2\u00e1\u00e3\3\2\2\2\u00e2"+
		"\u00db\3\2\2\2\u00e3\u00e6\3\2\2\2\u00e4\u00e2\3\2\2\2\u00e4\u00e5\3\2"+
		"\2\2\u00e5\u00e8\3\2\2\2\u00e6\u00e4\3\2\2\2\u00e7\u00d2\3\2\2\2\u00e7"+
		"\u00d4\3\2\2\2\u00e8\27\3\2\2\2\u00e9\u00ef\5\16\b\2\u00ea\u00eb\5`\61"+
		"\2\u00eb\u00ec\5\16\b\2\u00ec\u00ee\3\2\2\2\u00ed\u00ea\3\2\2\2\u00ee"+
		"\u00f1\3\2\2\2\u00ef\u00ed\3\2\2\2\u00ef\u00f0\3\2\2\2\u00f0\31\3\2\2"+
		"\2\u00f1\u00ef\3\2\2\2\u00f2\u00f4\7\6\2\2\u00f3\u00f2\3\2\2\2\u00f3\u00f4"+
		"\3\2\2\2\u00f4\u00f5\3\2\2\2\u00f5\u00f7\5\34\17\2\u00f6\u00f8\7\7\2\2"+
		"\u00f7\u00f6\3\2\2\2\u00f7\u00f8\3\2\2\2\u00f8\u0103\3\2\2\2\u00f9\u00fb"+
		"\7\3\2\2\u00fa\u00fc\7\6\2\2\u00fb\u00fa\3\2\2\2\u00fb\u00fc\3\2\2\2\u00fc"+
		"\u00fd\3\2\2\2\u00fd\u00ff\5\34\17\2\u00fe\u0100\7\7\2\2\u00ff\u00fe\3"+
		"\2\2\2\u00ff\u0100\3\2\2\2\u0100\u0102\3\2\2\2\u0101\u00f9\3\2\2\2\u0102"+
		"\u0105\3\2\2\2\u0103\u0101\3\2\2\2\u0103\u0104\3\2\2\2\u0104\33\3\2\2"+
		"\2\u0105\u0103\3\2\2\2\u0106\u0107\5j\66\2\u0107\u0108\7\13\2\2\u0108"+
		"\u010a\3\2\2\2\u0109\u0106\3\2\2\2\u0109\u010a\3\2\2\2\u010a\u010b\3\2"+
		"\2\2\u010b\u010d\7F\2\2\u010c\u010e\5l\67\2\u010d\u010c\3\2\2\2\u010d"+
		"\u010e\3\2\2\2\u010e\35\3\2\2\2\u010f\u0114\5$\23\2\u0110\u0114\5\"\22"+
		"\2\u0111\u0114\5 \21\2\u0112\u0114\5&\24\2\u0113\u010f\3\2\2\2\u0113\u0110"+
		"\3\2\2\2\u0113\u0111\3\2\2\2\u0113\u0112\3\2\2\2\u0114\37\3\2\2\2\u0115"+
		"\u011c\58\35\2\u0116\u011d\5\34\17\2\u0117\u0118\7\6\2\2\u0118\u0119\5"+
		"(\25\2\u0119\u011a\7\7\2\2\u011a\u011b\5l\67\2\u011b\u011d\3\2\2\2\u011c"+
		"\u0116\3\2\2\2\u011c\u0117\3\2\2\2\u011d\u011e\3\2\2\2\u011e\u011f\7\f"+
		"\2\2\u011f\u0120\5\60\31\2\u0120!\3\2\2\2\u0121\u0128\5:\36\2\u0122\u0129"+
		"\5\34\17\2\u0123\u0124\7\6\2\2\u0124\u0125\5*\26\2\u0125\u0126\7\7\2\2"+
		"\u0126\u0127\5l\67\2\u0127\u0129\3\2\2\2\u0128\u0122\3\2\2\2\u0128\u0123"+
		"\3\2\2\2\u0129\u012a\3\2\2\2\u012a\u012b\7\f\2\2\u012b\u012c\5\62\32\2"+
		"\u012c#\3\2\2\2\u012d\u0134\5<\37\2\u012e\u0135\5\34\17\2\u012f\u0130"+
		"\7\6\2\2\u0130\u0131\5,\27\2\u0131\u0132\7\7\2\2\u0132\u0133\5l\67\2\u0133"+
		"\u0135\3\2\2\2\u0134\u012e\3\2\2\2\u0134\u012f\3\2\2\2\u0135\u0136\3\2"+
		"\2\2\u0136\u0137\7\f\2\2\u0137\u0138\5\64\33\2\u0138%\3\2\2\2\u0139\u0140"+
		"\5> \2\u013a\u0141\5\34\17\2\u013b\u013c\7\6\2\2\u013c\u013d\5.\30\2\u013d"+
		"\u013e\7\7\2\2\u013e\u013f\5l\67\2\u013f\u0141\3\2\2\2\u0140\u013a\3\2"+
		"\2\2\u0140\u013b\3\2\2\2\u0141\u0142\3\2\2\2\u0142\u0143\7\f\2\2\u0143"+
		"\u0144\5\66\34\2\u0144\'\3\2\2\2\u0145\u014b\5\16\b\2\u0146\u0147\5`\61"+
		"\2\u0147\u0148\5\16\b\2\u0148\u014a\3\2\2\2\u0149\u0146\3\2\2\2\u014a"+
		"\u014d\3\2\2\2\u014b\u0149\3\2\2\2\u014b\u014c\3\2\2\2\u014c)\3\2\2\2"+
		"\u014d\u014b\3\2\2\2\u014e\u0154\5\16\b\2\u014f\u0150\5`\61\2\u0150\u0151"+
		"\5\16\b\2\u0151\u0153\3\2\2\2\u0152\u014f\3\2\2\2\u0153\u0156\3\2\2\2"+
		"\u0154\u0152\3\2\2\2\u0154\u0155\3\2\2\2\u0155+\3\2\2\2\u0156\u0154\3"+
		"\2\2\2\u0157\u015d\5\16\b\2\u0158\u0159\5`\61\2\u0159\u015a\5\16\b\2\u015a"+
		"\u015c\3\2\2\2\u015b\u0158\3\2\2\2\u015c\u015f\3\2\2\2\u015d\u015b\3\2"+
		"\2\2\u015d\u015e\3\2\2\2\u015e-\3\2\2\2\u015f\u015d\3\2\2\2\u0160\u0166"+
		"\5\16\b\2\u0161\u0162\5`\61\2\u0162\u0163\5\16\b\2\u0163\u0165\3\2\2\2"+
		"\u0164\u0161\3\2\2\2\u0165\u0168\3\2\2\2\u0166\u0164\3\2\2\2\u0166\u0167"+
		"\3\2\2\2\u0167/\3\2\2\2\u0168\u0166\3\2\2\2\u0169\u016a\5@!\2\u016a\61"+
		"\3\2\2\2\u016b\u016c\5@!\2\u016c\63\3\2\2\2\u016d\u016e\5@!\2\u016e\65"+
		"\3\2\2\2\u016f\u0170\5@!\2\u0170\67\3\2\2\2\u0171\u0173\7\r\2\2\u0172"+
		"\u0174\7\16\2\2\u0173\u0172\3\2\2\2\u0173\u0174\3\2\2\2\u0174\u0175\3"+
		"\2\2\2\u0175\u0176\7\17\2\2\u01769\3\2\2\2\u0177\u0179\7\20\2\2\u0178"+
		"\u017a\7\16\2\2\u0179\u0178\3\2\2\2\u0179\u017a\3\2\2\2\u017a\u017b\3"+
		"\2\2\2\u017b\u017c\7\17\2\2\u017c;\3\2\2\2\u017d\u017f\7\21\2\2\u017e"+
		"\u0180\7\16\2\2\u017f\u017e\3\2\2\2\u017f\u0180\3\2\2\2\u0180\u0181\3"+
		"\2\2\2\u0181\u0182\7\17\2\2\u0182=\3\2\2\2\u0183\u0184\7\22\2\2\u0184"+
		"\u0185\7\17\2\2\u0185?\3\2\2\2\u0186\u0187\5R*\2\u0187A\3\2\2\2\u0188"+
		"\u0189\7\23\2\2\u0189\u018a\5D#\2\u018aC\3\2\2\2\u018b\u018c\5R*\2\u018c"+
		"E\3\2\2\2\u018d\u018e\7\24\2\2\u018e\u018f\7\25\2\2\u018f\u0190\5H%\2"+
		"\u0190G\3\2\2\2\u0191\u0196\5J&\2\u0192\u0193\7\3\2\2\u0193\u0195\5J&"+
		"\2\u0194\u0192\3\2\2\2\u0195\u0198\3\2\2\2\u0196\u0194\3\2\2\2\u0196\u0197"+
		"\3\2\2\2\u0197I\3\2\2\2\u0198\u0196\3\2\2\2\u0199\u019f\5L\'\2\u019a\u019b"+
		"\5b\62\2\u019b\u019c\5L\'\2\u019c\u019e\3\2\2\2\u019d\u019a\3\2\2\2\u019e"+
		"\u01a1\3\2\2\2\u019f\u019d\3\2\2\2\u019f\u01a0\3\2\2\2\u01a0K\3\2\2\2"+
		"\u01a1\u019f\3\2\2\2\u01a2\u01a6\5\\/\2\u01a3\u01a6\5N(\2\u01a4\u01a6"+
		"\5^\60\2\u01a5\u01a2\3\2\2\2\u01a5\u01a3\3\2\2\2\u01a5\u01a4\3\2\2\2\u01a6"+
		"M\3\2\2\2\u01a7\u01a8\5P)\2\u01a8\u01a9\7\6\2\2\u01a9\u01ad\5V,\2\u01aa"+
		"\u01ab\7\26\2\2\u01ab\u01ac\7\25\2\2\u01ac\u01ae\5V,\2\u01ad\u01aa\3\2"+
		"\2\2\u01ad\u01ae\3\2\2\2\u01ae\u01af\3\2\2\2\u01af\u01b0\7\7\2\2\u01b0"+
		"\u01f3\3\2\2\2\u01b1\u01ba\5P)\2\u01b2\u01bb\5f\64\2\u01b3\u01b5\7\6\2"+
		"\2\u01b4\u01b6\7\t\2\2\u01b5\u01b4\3\2\2\2\u01b5\u01b6\3\2\2\2\u01b6\u01b7"+
		"\3\2\2\2\u01b7\u01b8\5V,\2\u01b8\u01b9\7\7\2\2\u01b9\u01bb\3\2\2\2\u01ba"+
		"\u01b2\3\2\2\2\u01ba\u01b3\3\2\2\2\u01bb\u01bc\3\2\2\2\u01bc\u01bd\7\27"+
		"\2\2\u01bd\u01c1\7\6\2\2\u01be\u01bf\7\30\2\2\u01bf\u01c0\7\25\2\2\u01c0"+
		"\u01c2\5V,\2\u01c1\u01be\3\2\2\2\u01c1\u01c2\3\2\2\2\u01c2\u01c9\3\2\2"+
		"\2\u01c3\u01c4\7\26\2\2\u01c4\u01c5\7\25\2\2\u01c5\u01c7\5V,\2\u01c6\u01c8"+
		"\t\2\2\2\u01c7\u01c6\3\2\2\2\u01c7\u01c8\3\2\2\2\u01c8\u01ca\3\2\2\2\u01c9"+
		"\u01c3\3\2\2\2\u01c9\u01ca\3\2\2\2\u01ca\u01cb\3\2\2\2\u01cb\u01cc\7\7"+
		"\2\2\u01cc\u01f3\3\2\2\2\u01cd\u01d3\7\33\2\2\u01ce\u01cf\7\34\2\2\u01cf"+
		"\u01d0\5R*\2\u01d0\u01d1\7\35\2\2\u01d1\u01d2\5V,\2\u01d2\u01d4\3\2\2"+
		"\2\u01d3\u01ce\3\2\2\2\u01d4\u01d5\3\2\2\2\u01d5\u01d3\3\2\2\2\u01d5\u01d6"+
		"\3\2\2\2\u01d6\u01d9\3\2\2\2\u01d7\u01d8\7\36\2\2\u01d8\u01da\5V,\2\u01d9"+
		"\u01d7\3\2\2\2\u01d9\u01da\3\2\2\2\u01da\u01db\3\2\2\2\u01db\u01dc\7\37"+
		"\2\2\u01dc\u01f3\3\2\2\2\u01dd\u01de\5P)\2\u01de\u01df\7\6\2\2\u01df\u01e0"+
		"\5V,\2\u01e0\u01e1\7 \2\2\u01e1\u01e2\5f\64\2\u01e2\u01e3\7\3\2\2\u01e3"+
		"\u01e4\5V,\2\u01e4\u01e5\7\7\2\2\u01e5\u01f3\3\2\2\2\u01e6\u01e7\5P)\2"+
		"\u01e7\u01e8\7\6\2\2\u01e8\u01e9\5V,\2\u01e9\u01ea\7\7\2\2\u01ea\u01eb"+
		"\7!\2\2\u01eb\u01ec\7\24\2\2\u01ec\u01ed\7\6\2\2\u01ed\u01ee\7\26\2\2"+
		"\u01ee\u01ef\7\25\2\2\u01ef\u01f0\5V,\2\u01f0\u01f1\7\7\2\2\u01f1\u01f3"+
		"\3\2\2\2\u01f2\u01a7\3\2\2\2\u01f2\u01b1\3\2\2\2\u01f2\u01cd\3\2\2\2\u01f2"+
		"\u01dd\3\2\2\2\u01f2\u01e6\3\2\2\2\u01f3O\3\2\2\2\u01f4\u01f5\t\3\2\2"+
		"\u01f5Q\3\2\2\2\u01f6\u01f8\7\6\2\2\u01f7\u01f6\3\2\2\2\u01f7\u01f8\3"+
		"\2\2\2\u01f8\u01f9\3\2\2\2\u01f9\u0204\5T+\2\u01fa\u01fc\5b\62\2\u01fb"+
		"\u01fd\7\6\2\2\u01fc\u01fb\3\2\2\2\u01fc\u01fd\3\2\2\2\u01fd\u01fe\3\2"+
		"\2\2\u01fe\u0200\5T+\2\u01ff\u0201\7\7\2\2\u0200\u01ff\3\2\2\2\u0200\u0201"+
		"\3\2\2\2\u0201\u0203\3\2\2\2\u0202\u01fa\3\2\2\2\u0203\u0206\3\2\2\2\u0204"+
		"\u0202\3\2\2\2\u0204\u0205\3\2\2\2\u0205S\3\2\2\2\u0206\u0204\3\2\2\2"+
		"\u0207\u0208\5\\/\2\u0208\u020a\5b\62\2\u0209\u020b\5\\/\2\u020a\u0209"+
		"\3\2\2\2\u020a\u020b\3\2\2\2\u020b\u0216\3\2\2\2\u020c\u020d\5\\/\2\u020d"+
		"\u020e\5b\62\2\u020e\u0211\7\6\2\2\u020f\u0212\5V,\2\u0210\u0212\5\4\3"+
		"\2\u0211\u020f\3\2\2\2\u0211\u0210\3\2\2\2\u0212\u0213\3\2\2\2\u0213\u0214"+
		"\7\7\2\2\u0214\u0216\3\2\2\2\u0215\u0207\3\2\2\2\u0215\u020c\3\2\2\2\u0216"+
		"U\3\2\2\2\u0217\u021a\5Z.\2\u0218\u021a\5X-\2\u0219\u0217\3\2\2\2\u0219"+
		"\u0218\3\2\2\2\u021a\u0222\3\2\2\2\u021b\u021e\t\4\2\2\u021c\u021f\5Z"+
		".\2\u021d\u021f\5X-\2\u021e\u021c\3\2\2\2\u021e\u021d\3\2\2\2\u021f\u0221"+
		"\3\2\2\2\u0220\u021b\3\2\2\2\u0221\u0224\3\2\2\2\u0222\u0220\3\2\2\2\u0222"+
		"\u0223\3\2\2\2\u0223W\3\2\2\2\u0224\u0222\3\2\2\2\u0225\u0227\7-\2\2\u0226"+
		"\u0225\3\2\2\2\u0226\u0227\3\2\2\2\u0227\u0228\3\2\2\2\u0228\u022a\5Z"+
		".\2\u0229\u022b\7.\2\2\u022a\u0229\3\2\2\2\u022a\u022b\3\2\2\2\u022bY"+
		"\3\2\2\2\u022c\u022d\5\\/\2\u022d[\3\2\2\2\u022e\u022f\5l\67\2\u022f\u0230"+
		"\7\13\2\2\u0230\u0232\3\2\2\2\u0231\u022e\3\2\2\2\u0231\u0232\3\2\2\2"+
		"\u0232\u0238\3\2\2\2\u0233\u0239\7/\2\2\u0234\u0239\7F\2\2\u0235\u0239"+
		"\7\60\2\2\u0236\u0239\5^\60\2\u0237\u0239\5N(\2\u0238\u0233\3\2\2\2\u0238"+
		"\u0234\3\2\2\2\u0238\u0235\3\2\2\2\u0238\u0236\3\2\2\2\u0238\u0237\3\2"+
		"\2\2\u0239]\3\2\2\2\u023a\u023f\7\61\2\2\u023b\u023e\n\5\2\2\u023c\u023e"+
		"\7\62\2\2\u023d\u023b\3\2\2\2\u023d\u023c\3\2\2\2\u023e\u0241\3\2\2\2"+
		"\u023f\u023d\3\2\2\2\u023f\u0240\3\2\2\2\u0240\u0242\3\2\2\2\u0241\u023f"+
		"\3\2\2\2\u0242\u0243\7\61\2\2\u0243_\3\2\2\2\u0244\u0249\7\63\2\2\u0245"+
		"\u0246\7\64\2\2\u0246\u0249\7\65\2\2\u0247\u0249\7\64\2\2\u0248\u0244"+
		"\3\2\2\2\u0248\u0245\3\2\2\2\u0248\u0247\3\2\2\2\u0249a\3\2\2\2\u024a"+
		"\u0262\7\66\2\2\u024b\u0262\7\67\2\2\u024c\u0262\78\2\2\u024d\u0262\7"+
		"9\2\2\u024e\u0262\7:\2\2\u024f\u0262\7;\2\2\u0250\u0262\7<\2\2\u0251\u0262"+
		"\7=\2\2\u0252\u0262\7>\2\2\u0253\u0262\7?\2\2\u0254\u0262\7/\2\2\u0255"+
		"\u0262\7@\2\2\u0256\u0262\7A\2\2\u0257\u0259\7B\2\2\u0258\u025a\7C\2\2"+
		"\u0259\u0258\3\2\2\2\u0259\u025a\3\2\2\2\u025a\u025b\3\2\2\2\u025b\u0262"+
		"\7\60\2\2\u025c\u025e\7C\2\2\u025d\u025c\3\2\2\2\u025d\u025e\3\2\2\2\u025e"+
		"\u025f\3\2\2\2\u025f\u0262\7D\2\2\u0260\u0262\7,\2\2\u0261\u024a\3\2\2"+
		"\2\u0261\u024b\3\2\2\2\u0261\u024c\3\2\2\2\u0261\u024d\3\2\2\2\u0261\u024e"+
		"\3\2\2\2\u0261\u024f\3\2\2\2\u0261\u0250\3\2\2\2\u0261\u0251\3\2\2\2\u0261"+
		"\u0252\3\2\2\2\u0261\u0253\3\2\2\2\u0261\u0254\3\2\2\2\u0261\u0255\3\2"+
		"\2\2\u0261\u0256\3\2\2\2\u0261\u0257\3\2\2\2\u0261\u025d\3\2\2\2\u0261"+
		"\u0260\3\2\2\2\u0262c\3\2\2\2\u0263\u0264\7F\2\2\u0264e\3\2\2\2\u0265"+
		"\u0266\7\6\2\2\u0266\u0269\7\7\2\2\u0267\u0269\7E\2\2\u0268\u0265\3\2"+
		"\2\2\u0268\u0267\3\2\2\2\u0269g\3\2\2\2\u026a\u026f\7F\2\2\u026b\u026c"+
		"\7\61\2\2\u026c\u026d\7F\2\2\u026d\u026f\7\61\2\2\u026e\u026a\3\2\2\2"+
		"\u026e\u026b\3\2\2\2\u026fi\3\2\2\2\u0270\u0271\7F\2\2\u0271k\3\2\2\2"+
		"\u0272\u0273\7F\2\2\u0273m\3\2\2\2Ks}\u0081\u008f\u0098\u009c\u00a3\u00a9"+
		"\u00af\u00b3\u00b7\u00c0\u00c9\u00cd\u00d0\u00d9\u00e0\u00e4\u00e7\u00ef"+
		"\u00f3\u00f7\u00fb\u00ff\u0103\u0109\u010d\u0113\u011c\u0128\u0134\u0140"+
		"\u014b\u0154\u015d\u0166\u0173\u0179\u017f\u0196\u019f\u01a5\u01ad\u01b5"+
		"\u01ba\u01c1\u01c7\u01c9\u01d5\u01d9\u01f2\u01f7\u01fc\u0200\u0204\u020a"+
		"\u0211\u0215\u0219\u021e\u0222\u0226\u022a\u0231\u0238\u023d\u023f\u0248"+
		"\u0259\u025d\u0261\u0268\u026e";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}
// Generated from C:/Users/c190471/Desktop/Projects/java/RapidAutomation/src/antlr4/test\tableColumn.g4 by ANTLR 4.8
package antlr4.test;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link tableColumnParser}.
 */
public interface tableColumnListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#scripts}.
	 * @param ctx the parse tree
	 */
	void enterScripts(tableColumnParser.ScriptsContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#scripts}.
	 * @param ctx the parse tree
	 */
	void exitScripts(tableColumnParser.ScriptsContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#query_script_list}.
	 * @param ctx the parse tree
	 */
	void enterQuery_script_list(tableColumnParser.Query_script_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#query_script_list}.
	 * @param ctx the parse tree
	 */
	void exitQuery_script_list(tableColumnParser.Query_script_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#with_clause_list}.
	 * @param ctx the parse tree
	 */
	void enterWith_clause_list(tableColumnParser.With_clause_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#with_clause_list}.
	 * @param ctx the parse tree
	 */
	void exitWith_clause_list(tableColumnParser.With_clause_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#with_clause}.
	 * @param ctx the parse tree
	 */
	void enterWith_clause(tableColumnParser.With_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#with_clause}.
	 * @param ctx the parse tree
	 */
	void exitWith_clause(tableColumnParser.With_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#with_query_script_list}.
	 * @param ctx the parse tree
	 */
	void enterWith_query_script_list(tableColumnParser.With_query_script_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#with_query_script_list}.
	 * @param ctx the parse tree
	 */
	void exitWith_query_script_list(tableColumnParser.With_query_script_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#final_query_list}.
	 * @param ctx the parse tree
	 */
	void enterFinal_query_list(tableColumnParser.Final_query_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#final_query_list}.
	 * @param ctx the parse tree
	 */
	void exitFinal_query_list(tableColumnParser.Final_query_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#query_script}.
	 * @param ctx the parse tree
	 */
	void enterQuery_script(tableColumnParser.Query_scriptContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#query_script}.
	 * @param ctx the parse tree
	 */
	void exitQuery_script(tableColumnParser.Query_scriptContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#select_clause}.
	 * @param ctx the parse tree
	 */
	void enterSelect_clause(tableColumnParser.Select_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#select_clause}.
	 * @param ctx the parse tree
	 */
	void exitSelect_clause(tableColumnParser.Select_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#colum_list}.
	 * @param ctx the parse tree
	 */
	void enterColum_list(tableColumnParser.Colum_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#colum_list}.
	 * @param ctx the parse tree
	 */
	void exitColum_list(tableColumnParser.Colum_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#colum}.
	 * @param ctx the parse tree
	 */
	void enterColum(tableColumnParser.ColumContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#colum}.
	 * @param ctx the parse tree
	 */
	void exitColum(tableColumnParser.ColumContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#from_clause}.
	 * @param ctx the parse tree
	 */
	void enterFrom_clause(tableColumnParser.From_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#from_clause}.
	 * @param ctx the parse tree
	 */
	void exitFrom_clause(tableColumnParser.From_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#from_query_script_list}.
	 * @param ctx the parse tree
	 */
	void enterFrom_query_script_list(tableColumnParser.From_query_script_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#from_query_script_list}.
	 * @param ctx the parse tree
	 */
	void exitFrom_query_script_list(tableColumnParser.From_query_script_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#table_name_list}.
	 * @param ctx the parse tree
	 */
	void enterTable_name_list(tableColumnParser.Table_name_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#table_name_list}.
	 * @param ctx the parse tree
	 */
	void exitTable_name_list(tableColumnParser.Table_name_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#table_name}.
	 * @param ctx the parse tree
	 */
	void enterTable_name(tableColumnParser.Table_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#table_name}.
	 * @param ctx the parse tree
	 */
	void exitTable_name(tableColumnParser.Table_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#join_clause}.
	 * @param ctx the parse tree
	 */
	void enterJoin_clause(tableColumnParser.Join_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#join_clause}.
	 * @param ctx the parse tree
	 */
	void exitJoin_clause(tableColumnParser.Join_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#left_join_clase}.
	 * @param ctx the parse tree
	 */
	void enterLeft_join_clase(tableColumnParser.Left_join_claseContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#left_join_clase}.
	 * @param ctx the parse tree
	 */
	void exitLeft_join_clase(tableColumnParser.Left_join_claseContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#right_join_clase}.
	 * @param ctx the parse tree
	 */
	void enterRight_join_clase(tableColumnParser.Right_join_claseContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#right_join_clase}.
	 * @param ctx the parse tree
	 */
	void exitRight_join_clase(tableColumnParser.Right_join_claseContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#full_join_clase}.
	 * @param ctx the parse tree
	 */
	void enterFull_join_clase(tableColumnParser.Full_join_claseContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#full_join_clase}.
	 * @param ctx the parse tree
	 */
	void exitFull_join_clase(tableColumnParser.Full_join_claseContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#inner_join_clase}.
	 * @param ctx the parse tree
	 */
	void enterInner_join_clase(tableColumnParser.Inner_join_claseContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#inner_join_clase}.
	 * @param ctx the parse tree
	 */
	void exitInner_join_clase(tableColumnParser.Inner_join_claseContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#left_join_query_script_list}.
	 * @param ctx the parse tree
	 */
	void enterLeft_join_query_script_list(tableColumnParser.Left_join_query_script_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#left_join_query_script_list}.
	 * @param ctx the parse tree
	 */
	void exitLeft_join_query_script_list(tableColumnParser.Left_join_query_script_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#right_join_query_script_list}.
	 * @param ctx the parse tree
	 */
	void enterRight_join_query_script_list(tableColumnParser.Right_join_query_script_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#right_join_query_script_list}.
	 * @param ctx the parse tree
	 */
	void exitRight_join_query_script_list(tableColumnParser.Right_join_query_script_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#full_join_query_script_list}.
	 * @param ctx the parse tree
	 */
	void enterFull_join_query_script_list(tableColumnParser.Full_join_query_script_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#full_join_query_script_list}.
	 * @param ctx the parse tree
	 */
	void exitFull_join_query_script_list(tableColumnParser.Full_join_query_script_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#inner_join_query_script_list}.
	 * @param ctx the parse tree
	 */
	void enterInner_join_query_script_list(tableColumnParser.Inner_join_query_script_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#inner_join_query_script_list}.
	 * @param ctx the parse tree
	 */
	void exitInner_join_query_script_list(tableColumnParser.Inner_join_query_script_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#left_join_clause_condition_list}.
	 * @param ctx the parse tree
	 */
	void enterLeft_join_clause_condition_list(tableColumnParser.Left_join_clause_condition_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#left_join_clause_condition_list}.
	 * @param ctx the parse tree
	 */
	void exitLeft_join_clause_condition_list(tableColumnParser.Left_join_clause_condition_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#right_join_clause_condition_list}.
	 * @param ctx the parse tree
	 */
	void enterRight_join_clause_condition_list(tableColumnParser.Right_join_clause_condition_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#right_join_clause_condition_list}.
	 * @param ctx the parse tree
	 */
	void exitRight_join_clause_condition_list(tableColumnParser.Right_join_clause_condition_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#full_join_clause_condition_list}.
	 * @param ctx the parse tree
	 */
	void enterFull_join_clause_condition_list(tableColumnParser.Full_join_clause_condition_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#full_join_clause_condition_list}.
	 * @param ctx the parse tree
	 */
	void exitFull_join_clause_condition_list(tableColumnParser.Full_join_clause_condition_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#inner_join_clause_condition_list}.
	 * @param ctx the parse tree
	 */
	void enterInner_join_clause_condition_list(tableColumnParser.Inner_join_clause_condition_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#inner_join_clause_condition_list}.
	 * @param ctx the parse tree
	 */
	void exitInner_join_clause_condition_list(tableColumnParser.Inner_join_clause_condition_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#left_join}.
	 * @param ctx the parse tree
	 */
	void enterLeft_join(tableColumnParser.Left_joinContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#left_join}.
	 * @param ctx the parse tree
	 */
	void exitLeft_join(tableColumnParser.Left_joinContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#right_join}.
	 * @param ctx the parse tree
	 */
	void enterRight_join(tableColumnParser.Right_joinContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#right_join}.
	 * @param ctx the parse tree
	 */
	void exitRight_join(tableColumnParser.Right_joinContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#full_join}.
	 * @param ctx the parse tree
	 */
	void enterFull_join(tableColumnParser.Full_joinContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#full_join}.
	 * @param ctx the parse tree
	 */
	void exitFull_join(tableColumnParser.Full_joinContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#inner_join}.
	 * @param ctx the parse tree
	 */
	void enterInner_join(tableColumnParser.Inner_joinContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#inner_join}.
	 * @param ctx the parse tree
	 */
	void exitInner_join(tableColumnParser.Inner_joinContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#join_clause_condition_list}.
	 * @param ctx the parse tree
	 */
	void enterJoin_clause_condition_list(tableColumnParser.Join_clause_condition_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#join_clause_condition_list}.
	 * @param ctx the parse tree
	 */
	void exitJoin_clause_condition_list(tableColumnParser.Join_clause_condition_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#where_clause}.
	 * @param ctx the parse tree
	 */
	void enterWhere_clause(tableColumnParser.Where_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#where_clause}.
	 * @param ctx the parse tree
	 */
	void exitWhere_clause(tableColumnParser.Where_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#where_clause_condition_list}.
	 * @param ctx the parse tree
	 */
	void enterWhere_clause_condition_list(tableColumnParser.Where_clause_condition_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#where_clause_condition_list}.
	 * @param ctx the parse tree
	 */
	void exitWhere_clause_condition_list(tableColumnParser.Where_clause_condition_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#group_by_clause}.
	 * @param ctx the parse tree
	 */
	void enterGroup_by_clause(tableColumnParser.Group_by_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#group_by_clause}.
	 * @param ctx the parse tree
	 */
	void exitGroup_by_clause(tableColumnParser.Group_by_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#group_by_key_list}.
	 * @param ctx the parse tree
	 */
	void enterGroup_by_key_list(tableColumnParser.Group_by_key_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#group_by_key_list}.
	 * @param ctx the parse tree
	 */
	void exitGroup_by_key_list(tableColumnParser.Group_by_key_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#group_by_key}.
	 * @param ctx the parse tree
	 */
	void enterGroup_by_key(tableColumnParser.Group_by_keyContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#group_by_key}.
	 * @param ctx the parse tree
	 */
	void exitGroup_by_key(tableColumnParser.Group_by_keyContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#group_key_factor}.
	 * @param ctx the parse tree
	 */
	void enterGroup_key_factor(tableColumnParser.Group_key_factorContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#group_key_factor}.
	 * @param ctx the parse tree
	 */
	void exitGroup_key_factor(tableColumnParser.Group_key_factorContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#function}.
	 * @param ctx the parse tree
	 */
	void enterFunction(tableColumnParser.FunctionContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#function}.
	 * @param ctx the parse tree
	 */
	void exitFunction(tableColumnParser.FunctionContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#function_name}.
	 * @param ctx the parse tree
	 */
	void enterFunction_name(tableColumnParser.Function_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#function_name}.
	 * @param ctx the parse tree
	 */
	void exitFunction_name(tableColumnParser.Function_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#condition_list}.
	 * @param ctx the parse tree
	 */
	void enterCondition_list(tableColumnParser.Condition_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#condition_list}.
	 * @param ctx the parse tree
	 */
	void exitCondition_list(tableColumnParser.Condition_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#condition}.
	 * @param ctx the parse tree
	 */
	void enterCondition(tableColumnParser.ConditionContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#condition}.
	 * @param ctx the parse tree
	 */
	void exitCondition(tableColumnParser.ConditionContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#parm_list}.
	 * @param ctx the parse tree
	 */
	void enterParm_list(tableColumnParser.Parm_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#parm_list}.
	 * @param ctx the parse tree
	 */
	void exitParm_list(tableColumnParser.Parm_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#parm_xmlparse}.
	 * @param ctx the parse tree
	 */
	void enterParm_xmlparse(tableColumnParser.Parm_xmlparseContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#parm_xmlparse}.
	 * @param ctx the parse tree
	 */
	void exitParm_xmlparse(tableColumnParser.Parm_xmlparseContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#parm}.
	 * @param ctx the parse tree
	 */
	void enterParm(tableColumnParser.ParmContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#parm}.
	 * @param ctx the parse tree
	 */
	void exitParm(tableColumnParser.ParmContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#field}.
	 * @param ctx the parse tree
	 */
	void enterField(tableColumnParser.FieldContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#field}.
	 * @param ctx the parse tree
	 */
	void exitField(tableColumnParser.FieldContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#hard_code}.
	 * @param ctx the parse tree
	 */
	void enterHard_code(tableColumnParser.Hard_codeContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#hard_code}.
	 * @param ctx the parse tree
	 */
	void exitHard_code(tableColumnParser.Hard_codeContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#set_operator}.
	 * @param ctx the parse tree
	 */
	void enterSet_operator(tableColumnParser.Set_operatorContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#set_operator}.
	 * @param ctx the parse tree
	 */
	void exitSet_operator(tableColumnParser.Set_operatorContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#operator}.
	 * @param ctx the parse tree
	 */
	void enterOperator(tableColumnParser.OperatorContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#operator}.
	 * @param ctx the parse tree
	 */
	void exitOperator(tableColumnParser.OperatorContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#temporary_table_name}.
	 * @param ctx the parse tree
	 */
	void enterTemporary_table_name(tableColumnParser.Temporary_table_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#temporary_table_name}.
	 * @param ctx the parse tree
	 */
	void exitTemporary_table_name(tableColumnParser.Temporary_table_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#parenthese}.
	 * @param ctx the parse tree
	 */
	void enterParenthese(tableColumnParser.ParentheseContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#parenthese}.
	 * @param ctx the parse tree
	 */
	void exitParenthese(tableColumnParser.ParentheseContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#column_alias}.
	 * @param ctx the parse tree
	 */
	void enterColumn_alias(tableColumnParser.Column_aliasContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#column_alias}.
	 * @param ctx the parse tree
	 */
	void exitColumn_alias(tableColumnParser.Column_aliasContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#schema}.
	 * @param ctx the parse tree
	 */
	void enterSchema(tableColumnParser.SchemaContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#schema}.
	 * @param ctx the parse tree
	 */
	void exitSchema(tableColumnParser.SchemaContext ctx);
	/**
	 * Enter a parse tree produced by {@link tableColumnParser#table_alias}.
	 * @param ctx the parse tree
	 */
	void enterTable_alias(tableColumnParser.Table_aliasContext ctx);
	/**
	 * Exit a parse tree produced by {@link tableColumnParser#table_alias}.
	 * @param ctx the parse tree
	 */
	void exitTable_alias(tableColumnParser.Table_aliasContext ctx);
}
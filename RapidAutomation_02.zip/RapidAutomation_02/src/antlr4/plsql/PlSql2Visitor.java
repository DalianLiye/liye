// Generated from C:/Users/c190471/Desktop/Projects/java/RapidAutomation/src/antlr4/plsql\PlSql2.g4 by ANTLR 4.8
package antlr4.plsql;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link PlSql2Parser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface PlSql2Visitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#swallow_to_semi}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSwallow_to_semi(PlSql2Parser.Swallow_to_semiContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#compilation_unit}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCompilation_unit(PlSql2Parser.Compilation_unitContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#sql_script}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSql_script(PlSql2Parser.Sql_scriptContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#sql_explain}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSql_explain(PlSql2Parser.Sql_explainContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#unit_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnit_statement(PlSql2Parser.Unit_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#unit_statement_body}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnit_statement_body(PlSql2Parser.Unit_statement_bodyContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#create_role}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCreate_role(PlSql2Parser.Create_roleContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#role_option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRole_option(PlSql2Parser.Role_optionContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#refresh_materialized_view}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRefresh_materialized_view(PlSql2Parser.Refresh_materialized_viewContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#create_materialized_view}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCreate_materialized_view(PlSql2Parser.Create_materialized_viewContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#create_mv_refresh}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCreate_mv_refresh(PlSql2Parser.Create_mv_refreshContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#build_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBuild_clause(PlSql2Parser.Build_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#alter_permission}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAlter_permission(PlSql2Parser.Alter_permissionContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#permission_options}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPermission_options(PlSql2Parser.Permission_optionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#create_view}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCreate_view(PlSql2Parser.Create_viewContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#view_options}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitView_options(PlSql2Parser.View_optionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#view_alias_constraint}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitView_alias_constraint(PlSql2Parser.View_alias_constraintContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#create_index}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCreate_index(PlSql2Parser.Create_indexContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#cluster_index_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCluster_index_clause(PlSql2Parser.Cluster_index_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#cluster_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCluster_name(PlSql2Parser.Cluster_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#index_attributes}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIndex_attributes(PlSql2Parser.Index_attributesContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#tablespace}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTablespace(PlSql2Parser.TablespaceContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#key_compression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitKey_compression(PlSql2Parser.Key_compressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#sort_or_nosort}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSort_or_nosort(PlSql2Parser.Sort_or_nosortContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#visible_or_invisible}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVisible_or_invisible(PlSql2Parser.Visible_or_invisibleContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#parallel_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParallel_clause(PlSql2Parser.Parallel_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#table_index_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTable_index_clause(PlSql2Parser.Table_index_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#index_expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIndex_expr(PlSql2Parser.Index_exprContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#index_properties}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIndex_properties(PlSql2Parser.Index_propertiesContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#global_partitioned_index}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGlobal_partitioned_index(PlSql2Parser.Global_partitioned_indexContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#index_partitioning_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIndex_partitioning_clause(PlSql2Parser.Index_partitioning_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#partition_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPartition_name(PlSql2Parser.Partition_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#literal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLiteral(PlSql2Parser.LiteralContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#string_function}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitString_function(PlSql2Parser.String_functionContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#expressions}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpressions(PlSql2Parser.ExpressionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#individual_hash_partitions}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIndividual_hash_partitions(PlSql2Parser.Individual_hash_partitionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#partitioning_storage_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPartitioning_storage_clause(PlSql2Parser.Partitioning_storage_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#table_compression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTable_compression(PlSql2Parser.Table_compressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#lob_partitioning_storage}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLob_partitioning_storage(PlSql2Parser.Lob_partitioning_storageContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#lob_item}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLob_item(PlSql2Parser.Lob_itemContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#lob_segname}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLob_segname(PlSql2Parser.Lob_segnameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#varray_item}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVarray_item(PlSql2Parser.Varray_itemContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#hash_partitions_by_quantity}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHash_partitions_by_quantity(PlSql2Parser.Hash_partitions_by_quantityContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#hash_partition_quantity}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHash_partition_quantity(PlSql2Parser.Hash_partition_quantityContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#local_partitioned_index}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLocal_partitioned_index(PlSql2Parser.Local_partitioned_indexContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#on_range_partitioned_table}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOn_range_partitioned_table(PlSql2Parser.On_range_partitioned_tableContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#on_list_partitioned_table}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOn_list_partitioned_table(PlSql2Parser.On_list_partitioned_tableContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#on_hash_partitioned_table}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOn_hash_partitioned_table(PlSql2Parser.On_hash_partitioned_tableContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#on_comp_partitioned_table}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOn_comp_partitioned_table(PlSql2Parser.On_comp_partitioned_tableContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#index_subpartition_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIndex_subpartition_clause(PlSql2Parser.Index_subpartition_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#subpartition_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubpartition_name(PlSql2Parser.Subpartition_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#domain_index_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDomain_index_clause(PlSql2Parser.Domain_index_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#indextype}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIndextype(PlSql2Parser.IndextypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#odci_parameters}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOdci_parameters(PlSql2Parser.Odci_parametersContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#local_domain_index_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLocal_domain_index_clause(PlSql2Parser.Local_domain_index_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#xmlindex_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitXmlindex_clause(PlSql2Parser.Xmlindex_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#local_xmlindex_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLocal_xmlindex_clause(PlSql2Parser.Local_xmlindex_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#bitmap_join_index_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBitmap_join_index_clause(PlSql2Parser.Bitmap_join_index_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#create_table}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCreate_table(PlSql2Parser.Create_tableContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#relational_table}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRelational_table(PlSql2Parser.Relational_tableContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#relational_properties}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRelational_properties(PlSql2Parser.Relational_propertiesContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#column_definition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitColumn_definition(PlSql2Parser.Column_definitionContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#inline_ref_constraint}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInline_ref_constraint(PlSql2Parser.Inline_ref_constraintContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#virtual_column_definition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVirtual_column_definition(PlSql2Parser.Virtual_column_definitionContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#out_of_line_constraint}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOut_of_line_constraint(PlSql2Parser.Out_of_line_constraintContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#foreign_key_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitForeign_key_clause(PlSql2Parser.Foreign_key_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#on_delete_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOn_delete_clause(PlSql2Parser.On_delete_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#out_of_line_ref_constraint}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOut_of_line_ref_constraint(PlSql2Parser.Out_of_line_ref_constraintContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#supplemental_logging_props}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSupplemental_logging_props(PlSql2Parser.Supplemental_logging_propsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#supplemental_log_grp_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSupplemental_log_grp_clause(PlSql2Parser.Supplemental_log_grp_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#log_grp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLog_grp(PlSql2Parser.Log_grpContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#supplemental_id_key_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSupplemental_id_key_clause(PlSql2Parser.Supplemental_id_key_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#physical_properties}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPhysical_properties(PlSql2Parser.Physical_propertiesContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#deferred_segment_creation}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDeferred_segment_creation(PlSql2Parser.Deferred_segment_creationContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#segment_attributes_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSegment_attributes_clause(PlSql2Parser.Segment_attributes_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#physical_attributes_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPhysical_attributes_clause(PlSql2Parser.Physical_attributes_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#storage_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStorage_clause(PlSql2Parser.Storage_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#size_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSize_clause(PlSql2Parser.Size_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#logging_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLogging_clause(PlSql2Parser.Logging_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#column_properties}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitColumn_properties(PlSql2Parser.Column_propertiesContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#object_type_col_properties}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitObject_type_col_properties(PlSql2Parser.Object_type_col_propertiesContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#substitutable_column_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubstitutable_column_clause(PlSql2Parser.Substitutable_column_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#nested_table_col_properties}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNested_table_col_properties(PlSql2Parser.Nested_table_col_propertiesContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#nested_item}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNested_item(PlSql2Parser.Nested_itemContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#object_properties}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitObject_properties(PlSql2Parser.Object_propertiesContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#inline_constraint}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInline_constraint(PlSql2Parser.Inline_constraintContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#references_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReferences_clause(PlSql2Parser.References_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#paren_column_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParen_column_list(PlSql2Parser.Paren_column_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#column_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitColumn_list(PlSql2Parser.Column_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#check_constraint}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCheck_constraint(PlSql2Parser.Check_constraintContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#constraint_state}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstraint_state(PlSql2Parser.Constraint_stateContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#using_index_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsing_index_clause(PlSql2Parser.Using_index_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#varray_col_properties}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVarray_col_properties(PlSql2Parser.Varray_col_propertiesContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#varray_storage_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVarray_storage_clause(PlSql2Parser.Varray_storage_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#lob_storage_parameters}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLob_storage_parameters(PlSql2Parser.Lob_storage_parametersContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#lob_parameters}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLob_parameters(PlSql2Parser.Lob_parametersContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#lob_retention_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLob_retention_clause(PlSql2Parser.Lob_retention_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#lob_deduplicate_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLob_deduplicate_clause(PlSql2Parser.Lob_deduplicate_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#lob_compression_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLob_compression_clause(PlSql2Parser.Lob_compression_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#encryption_spec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEncryption_spec(PlSql2Parser.Encryption_specContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#lob_storage_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLob_storage_clause(PlSql2Parser.Lob_storage_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#xmltype_column_properties}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitXmltype_column_properties(PlSql2Parser.Xmltype_column_propertiesContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#xmltype_storage}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitXmltype_storage(PlSql2Parser.Xmltype_storageContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#xmlschema_spec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitXmlschema_spec(PlSql2Parser.Xmlschema_specContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#allow_or_disallow}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAllow_or_disallow(PlSql2Parser.Allow_or_disallowContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#table_partitioning_clauses}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTable_partitioning_clauses(PlSql2Parser.Table_partitioning_clausesContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#range_partitions}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRange_partitions(PlSql2Parser.Range_partitionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#range_values_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRange_values_clause(PlSql2Parser.Range_values_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#table_partition_description}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTable_partition_description(PlSql2Parser.Table_partition_descriptionContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#list_partitions}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitList_partitions(PlSql2Parser.List_partitionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#list_values_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitList_values_clause(PlSql2Parser.List_values_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#hash_partitions}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHash_partitions(PlSql2Parser.Hash_partitionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#composite_range_partitions}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComposite_range_partitions(PlSql2Parser.Composite_range_partitionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#subpartition_by_range}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubpartition_by_range(PlSql2Parser.Subpartition_by_rangeContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#subpartition_by_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubpartition_by_list(PlSql2Parser.Subpartition_by_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#subpartition_template}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubpartition_template(PlSql2Parser.Subpartition_templateContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#range_subpartition_desc}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRange_subpartition_desc(PlSql2Parser.Range_subpartition_descContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#list_subpartition_desc}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitList_subpartition_desc(PlSql2Parser.List_subpartition_descContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#individual_hash_subparts}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIndividual_hash_subparts(PlSql2Parser.Individual_hash_subpartsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#hash_subpartition_quantity}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHash_subpartition_quantity(PlSql2Parser.Hash_subpartition_quantityContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#subpartition_by_hash}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubpartition_by_hash(PlSql2Parser.Subpartition_by_hashContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#range_partition_desc}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRange_partition_desc(PlSql2Parser.Range_partition_descContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#hash_subparts_by_quantity}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHash_subparts_by_quantity(PlSql2Parser.Hash_subparts_by_quantityContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#composite_list_partitions}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComposite_list_partitions(PlSql2Parser.Composite_list_partitionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#list_partition_desc}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitList_partition_desc(PlSql2Parser.List_partition_descContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#composite_hash_partitions}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComposite_hash_partitions(PlSql2Parser.Composite_hash_partitionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#reference_partitioning}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReference_partitioning(PlSql2Parser.Reference_partitioningContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#reference_partition_desc}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReference_partition_desc(PlSql2Parser.Reference_partition_descContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#system_partitioning}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSystem_partitioning(PlSql2Parser.System_partitioningContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#enable_disable_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEnable_disable_clause(PlSql2Parser.Enable_disable_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#exceptions_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExceptions_clause(PlSql2Parser.Exceptions_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#row_movement_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRow_movement_clause(PlSql2Parser.Row_movement_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#flashback_archive_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFlashback_archive_clause(PlSql2Parser.Flashback_archive_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#object_table}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitObject_table(PlSql2Parser.Object_tableContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#object_table_substitution}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitObject_table_substitution(PlSql2Parser.Object_table_substitutionContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#oid_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOid_clause(PlSql2Parser.Oid_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#oid_index_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOid_index_clause(PlSql2Parser.Oid_index_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#xmltype_table}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitXmltype_table(PlSql2Parser.Xmltype_tableContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#xmltype_virtual_columns}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitXmltype_virtual_columns(PlSql2Parser.Xmltype_virtual_columnsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#drop_table}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDrop_table(PlSql2Parser.Drop_tableContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#alter_table}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAlter_table(PlSql2Parser.Alter_tableContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#alter_table_properties}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAlter_table_properties(PlSql2Parser.Alter_table_propertiesContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#alter_table_properties_1}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAlter_table_properties_1(PlSql2Parser.Alter_table_properties_1Context ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#supplemental_table_logging}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSupplemental_table_logging(PlSql2Parser.Supplemental_table_loggingContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#allocate_extent_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAllocate_extent_clause(PlSql2Parser.Allocate_extent_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#deallocate_unused_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDeallocate_unused_clause(PlSql2Parser.Deallocate_unused_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#upgrade_table_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUpgrade_table_clause(PlSql2Parser.Upgrade_table_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#records_per_block_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRecords_per_block_clause(PlSql2Parser.Records_per_block_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#alter_iot_clauses}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAlter_iot_clauses(PlSql2Parser.Alter_iot_clausesContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#index_org_table_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIndex_org_table_clause(PlSql2Parser.Index_org_table_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#mapping_table_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMapping_table_clause(PlSql2Parser.Mapping_table_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#index_org_overflow_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIndex_org_overflow_clause(PlSql2Parser.Index_org_overflow_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#alter_overflow_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAlter_overflow_clause(PlSql2Parser.Alter_overflow_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#add_overflow_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAdd_overflow_clause(PlSql2Parser.Add_overflow_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#shrink_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitShrink_clause(PlSql2Parser.Shrink_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#alter_mapping_table_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAlter_mapping_table_clause(PlSql2Parser.Alter_mapping_table_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#constraint_clauses}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstraint_clauses(PlSql2Parser.Constraint_clausesContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#old_constraint_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOld_constraint_name(PlSql2Parser.Old_constraint_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#new_constraint_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNew_constraint_name(PlSql2Parser.New_constraint_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#drop_constraint_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDrop_constraint_clause(PlSql2Parser.Drop_constraint_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#drop_primary_key_or_unique_or_generic_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDrop_primary_key_or_unique_or_generic_clause(PlSql2Parser.Drop_primary_key_or_unique_or_generic_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#column_clauses}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitColumn_clauses(PlSql2Parser.Column_clausesContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#add_modify_drop_column_clauses}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAdd_modify_drop_column_clauses(PlSql2Parser.Add_modify_drop_column_clausesContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#add_column_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAdd_column_clause(PlSql2Parser.Add_column_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#modify_column_clauses}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModify_column_clauses(PlSql2Parser.Modify_column_clausesContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#alter_column_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAlter_column_clause(PlSql2Parser.Alter_column_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#modify_col_properties}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModify_col_properties(PlSql2Parser.Modify_col_propertiesContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#modify_col_substitutable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModify_col_substitutable(PlSql2Parser.Modify_col_substitutableContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#drop_column_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDrop_column_clause(PlSql2Parser.Drop_column_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#rename_column_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRename_column_clause(PlSql2Parser.Rename_column_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#old_column_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOld_column_name(PlSql2Parser.Old_column_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#new_column_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNew_column_name(PlSql2Parser.New_column_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#modify_collection_retrieval}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModify_collection_retrieval(PlSql2Parser.Modify_collection_retrievalContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#collection_item}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCollection_item(PlSql2Parser.Collection_itemContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#modify_lob_storage_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModify_lob_storage_clause(PlSql2Parser.Modify_lob_storage_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#modify_lob_parameters}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModify_lob_parameters(PlSql2Parser.Modify_lob_parametersContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#drop_function}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDrop_function(PlSql2Parser.Drop_functionContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#alter_function}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAlter_function(PlSql2Parser.Alter_functionContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#create_function_body}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCreate_function_body(PlSql2Parser.Create_function_bodyContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#parallel_enable_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParallel_enable_clause(PlSql2Parser.Parallel_enable_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#partition_by_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPartition_by_clause(PlSql2Parser.Partition_by_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#result_cache_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitResult_cache_clause(PlSql2Parser.Result_cache_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#relies_on_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRelies_on_part(PlSql2Parser.Relies_on_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#streaming_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStreaming_clause(PlSql2Parser.Streaming_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#drop_package}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDrop_package(PlSql2Parser.Drop_packageContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#alter_package}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAlter_package(PlSql2Parser.Alter_packageContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#create_package}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCreate_package(PlSql2Parser.Create_packageContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#package_body}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPackage_body(PlSql2Parser.Package_bodyContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#package_spec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPackage_spec(PlSql2Parser.Package_specContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#package_obj_spec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPackage_obj_spec(PlSql2Parser.Package_obj_specContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#procedure_spec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProcedure_spec(PlSql2Parser.Procedure_specContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#function_spec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_spec(PlSql2Parser.Function_specContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#package_obj_body}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPackage_obj_body(PlSql2Parser.Package_obj_bodyContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#drop_procedure}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDrop_procedure(PlSql2Parser.Drop_procedureContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#alter_procedure}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAlter_procedure(PlSql2Parser.Alter_procedureContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#create_procedure_body}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCreate_procedure_body(PlSql2Parser.Create_procedure_bodyContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#drop_trigger}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDrop_trigger(PlSql2Parser.Drop_triggerContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#alter_trigger}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAlter_trigger(PlSql2Parser.Alter_triggerContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#create_trigger}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCreate_trigger(PlSql2Parser.Create_triggerContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#trigger_follows_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTrigger_follows_clause(PlSql2Parser.Trigger_follows_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#trigger_when_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTrigger_when_clause(PlSql2Parser.Trigger_when_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#simple_dml_trigger}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSimple_dml_trigger(PlSql2Parser.Simple_dml_triggerContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#for_each_row}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFor_each_row(PlSql2Parser.For_each_rowContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#compound_dml_trigger}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCompound_dml_trigger(PlSql2Parser.Compound_dml_triggerContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#non_dml_trigger}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNon_dml_trigger(PlSql2Parser.Non_dml_triggerContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#trigger_body}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTrigger_body(PlSql2Parser.Trigger_bodyContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#routine_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRoutine_clause(PlSql2Parser.Routine_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#compound_trigger_block}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCompound_trigger_block(PlSql2Parser.Compound_trigger_blockContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#timing_point_section}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTiming_point_section(PlSql2Parser.Timing_point_sectionContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#non_dml_event}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNon_dml_event(PlSql2Parser.Non_dml_eventContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#dml_event_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDml_event_clause(PlSql2Parser.Dml_event_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#dml_event_element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDml_event_element(PlSql2Parser.Dml_event_elementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#dml_event_nested_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDml_event_nested_clause(PlSql2Parser.Dml_event_nested_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#referencing_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReferencing_clause(PlSql2Parser.Referencing_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#referencing_element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReferencing_element(PlSql2Parser.Referencing_elementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#drop_type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDrop_type(PlSql2Parser.Drop_typeContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#alter_type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAlter_type(PlSql2Parser.Alter_typeContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#compile_type_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCompile_type_clause(PlSql2Parser.Compile_type_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#replace_type_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReplace_type_clause(PlSql2Parser.Replace_type_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#alter_method_spec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAlter_method_spec(PlSql2Parser.Alter_method_specContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#alter_method_element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAlter_method_element(PlSql2Parser.Alter_method_elementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#alter_attribute_definition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAlter_attribute_definition(PlSql2Parser.Alter_attribute_definitionContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#attribute_definition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAttribute_definition(PlSql2Parser.Attribute_definitionContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#alter_collection_clauses}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAlter_collection_clauses(PlSql2Parser.Alter_collection_clausesContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#dependent_handling_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDependent_handling_clause(PlSql2Parser.Dependent_handling_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#dependent_exceptions_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDependent_exceptions_part(PlSql2Parser.Dependent_exceptions_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#create_type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCreate_type(PlSql2Parser.Create_typeContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#type_definition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitType_definition(PlSql2Parser.Type_definitionContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#object_type_def}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitObject_type_def(PlSql2Parser.Object_type_defContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#object_as_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitObject_as_part(PlSql2Parser.Object_as_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#object_under_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitObject_under_part(PlSql2Parser.Object_under_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#nested_table_type_def}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNested_table_type_def(PlSql2Parser.Nested_table_type_defContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#sqlj_object_type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSqlj_object_type(PlSql2Parser.Sqlj_object_typeContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#type_body}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitType_body(PlSql2Parser.Type_bodyContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#type_body_elements}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitType_body_elements(PlSql2Parser.Type_body_elementsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#map_order_func_declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMap_order_func_declaration(PlSql2Parser.Map_order_func_declarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#subprog_decl_in_type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubprog_decl_in_type(PlSql2Parser.Subprog_decl_in_typeContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#proc_decl_in_type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProc_decl_in_type(PlSql2Parser.Proc_decl_in_typeContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#func_decl_in_type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunc_decl_in_type(PlSql2Parser.Func_decl_in_typeContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#constructor_declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstructor_declaration(PlSql2Parser.Constructor_declarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#modifier_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModifier_clause(PlSql2Parser.Modifier_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#object_member_spec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitObject_member_spec(PlSql2Parser.Object_member_specContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#sqlj_object_type_attr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSqlj_object_type_attr(PlSql2Parser.Sqlj_object_type_attrContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#element_spec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElement_spec(PlSql2Parser.Element_specContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#element_spec_options}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElement_spec_options(PlSql2Parser.Element_spec_optionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#subprogram_spec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubprogram_spec(PlSql2Parser.Subprogram_specContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#type_procedure_spec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitType_procedure_spec(PlSql2Parser.Type_procedure_specContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#type_function_spec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitType_function_spec(PlSql2Parser.Type_function_specContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#constructor_spec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstructor_spec(PlSql2Parser.Constructor_specContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#map_order_function_spec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMap_order_function_spec(PlSql2Parser.Map_order_function_specContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#pragma_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPragma_clause(PlSql2Parser.Pragma_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#pragma_elements}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPragma_elements(PlSql2Parser.Pragma_elementsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#type_elements_parameter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitType_elements_parameter(PlSql2Parser.Type_elements_parameterContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#drop_sequence}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDrop_sequence(PlSql2Parser.Drop_sequenceContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#alter_sequence}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAlter_sequence(PlSql2Parser.Alter_sequenceContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#create_sequence}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCreate_sequence(PlSql2Parser.Create_sequenceContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#sequence_spec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSequence_spec(PlSql2Parser.Sequence_specContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#sequence_start_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSequence_start_clause(PlSql2Parser.Sequence_start_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#invoker_rights_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInvoker_rights_clause(PlSql2Parser.Invoker_rights_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#compiler_parameters_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCompiler_parameters_clause(PlSql2Parser.Compiler_parameters_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#call_spec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCall_spec(PlSql2Parser.Call_specContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#java_spec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJava_spec(PlSql2Parser.Java_specContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#c_spec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitC_spec(PlSql2Parser.C_specContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#c_agent_in_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitC_agent_in_clause(PlSql2Parser.C_agent_in_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#c_parameters_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitC_parameters_clause(PlSql2Parser.C_parameters_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#parameter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParameter(PlSql2Parser.ParameterContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#default_value_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDefault_value_part(PlSql2Parser.Default_value_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#declare_spec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDeclare_spec(PlSql2Parser.Declare_specContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#variable_declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVariable_declaration(PlSql2Parser.Variable_declarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#subtype_declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubtype_declaration(PlSql2Parser.Subtype_declarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#cursor_declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCursor_declaration(PlSql2Parser.Cursor_declarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#parameter_spec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParameter_spec(PlSql2Parser.Parameter_specContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#exception_declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitException_declaration(PlSql2Parser.Exception_declarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#pragma_declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPragma_declaration(PlSql2Parser.Pragma_declarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#record_declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRecord_declaration(PlSql2Parser.Record_declarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#record_type_dec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRecord_type_dec(PlSql2Parser.Record_type_decContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#field_spec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitField_spec(PlSql2Parser.Field_specContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#record_var_dec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRecord_var_dec(PlSql2Parser.Record_var_decContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#table_declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTable_declaration(PlSql2Parser.Table_declarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#table_type_dec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTable_type_dec(PlSql2Parser.Table_type_decContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#table_indexed_by_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTable_indexed_by_part(PlSql2Parser.Table_indexed_by_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#varray_type_def}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVarray_type_def(PlSql2Parser.Varray_type_defContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#table_var_dec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTable_var_dec(PlSql2Parser.Table_var_decContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#seq_of_statements}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSeq_of_statements(PlSql2Parser.Seq_of_statementsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#label_declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLabel_declaration(PlSql2Parser.Label_declarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStatement(PlSql2Parser.StatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#assignment_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignment_statement(PlSql2Parser.Assignment_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#continue_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitContinue_statement(PlSql2Parser.Continue_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#exit_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExit_statement(PlSql2Parser.Exit_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#goto_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGoto_statement(PlSql2Parser.Goto_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#if_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIf_statement(PlSql2Parser.If_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#elsif_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElsif_part(PlSql2Parser.Elsif_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#else_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElse_part(PlSql2Parser.Else_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#loop_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLoop_statement(PlSql2Parser.Loop_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#cursor_loop_param}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCursor_loop_param(PlSql2Parser.Cursor_loop_paramContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#forall_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitForall_statement(PlSql2Parser.Forall_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#bounds_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBounds_clause(PlSql2Parser.Bounds_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#between_bound}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBetween_bound(PlSql2Parser.Between_boundContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#lower_bound}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLower_bound(PlSql2Parser.Lower_boundContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#upper_bound}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUpper_bound(PlSql2Parser.Upper_boundContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#null_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNull_statement(PlSql2Parser.Null_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#raise_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRaise_statement(PlSql2Parser.Raise_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#return_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReturn_statement(PlSql2Parser.Return_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#function_call}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_call(PlSql2Parser.Function_callContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#body}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBody(PlSql2Parser.BodyContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#exception_handler}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitException_handler(PlSql2Parser.Exception_handlerContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#trigger_block}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTrigger_block(PlSql2Parser.Trigger_blockContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#block}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlock(PlSql2Parser.BlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#sql_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSql_statement(PlSql2Parser.Sql_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#execute_immediate}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExecute_immediate(PlSql2Parser.Execute_immediateContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#dynamic_returning_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDynamic_returning_clause(PlSql2Parser.Dynamic_returning_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#data_manipulation_language_statements}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitData_manipulation_language_statements(PlSql2Parser.Data_manipulation_language_statementsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#cursor_manipulation_statements}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCursor_manipulation_statements(PlSql2Parser.Cursor_manipulation_statementsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#close_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClose_statement(PlSql2Parser.Close_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#open_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOpen_statement(PlSql2Parser.Open_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#fetch_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFetch_statement(PlSql2Parser.Fetch_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#open_for_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOpen_for_statement(PlSql2Parser.Open_for_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#transaction_control_statements}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTransaction_control_statements(PlSql2Parser.Transaction_control_statementsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#set_transaction_command}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSet_transaction_command(PlSql2Parser.Set_transaction_commandContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#set_constraint_command}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSet_constraint_command(PlSql2Parser.Set_constraint_commandContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#commit_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCommit_statement(PlSql2Parser.Commit_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#write_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWrite_clause(PlSql2Parser.Write_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#rollback_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRollback_statement(PlSql2Parser.Rollback_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#savepoint_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSavepoint_statement(PlSql2Parser.Savepoint_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#explain_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExplain_statement(PlSql2Parser.Explain_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#select_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelect_statement(PlSql2Parser.Select_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#subquery_factoring_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubquery_factoring_clause(PlSql2Parser.Subquery_factoring_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#factoring_element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFactoring_element(PlSql2Parser.Factoring_elementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#search_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSearch_clause(PlSql2Parser.Search_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#cycle_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCycle_clause(PlSql2Parser.Cycle_clauseContext ctx);
	/**
	 * Visit a parse tree produced by the {@code SubqueryParen}
	 * labeled alternative in {@link PlSql2Parser#subquery}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubqueryParen(PlSql2Parser.SubqueryParenContext ctx);
	/**
	 * Visit a parse tree produced by the {@code IgnoreSubquery}
	 * labeled alternative in {@link PlSql2Parser#subquery}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIgnoreSubquery(PlSql2Parser.IgnoreSubqueryContext ctx);
	/**
	 * Visit a parse tree produced by the {@code SubqueryCompound}
	 * labeled alternative in {@link PlSql2Parser#subquery}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubqueryCompound(PlSql2Parser.SubqueryCompoundContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#subquery_operation_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubquery_operation_part(PlSql2Parser.Subquery_operation_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#query_block}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitQuery_block(PlSql2Parser.Query_blockContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Star1}
	 * labeled alternative in {@link PlSql2Parser#selected_element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStar1(PlSql2Parser.Star1Context ctx);
	/**
	 * Visit a parse tree produced by the {@code StarTable}
	 * labeled alternative in {@link PlSql2Parser#selected_element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStarTable(PlSql2Parser.StarTableContext ctx);
	/**
	 * Visit a parse tree produced by the {@code IgnoreTableview_name}
	 * labeled alternative in {@link PlSql2Parser#selected_element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIgnoreTableview_name(PlSql2Parser.IgnoreTableview_nameContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Alias_expr}
	 * labeled alternative in {@link PlSql2Parser#selected_element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAlias_expr(PlSql2Parser.Alias_exprContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#from_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFrom_clause(PlSql2Parser.From_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#table_ref_pivot}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTable_ref_pivot(PlSql2Parser.Table_ref_pivotContext ctx);
	/**
	 * Visit a parse tree produced by the {@code JoinExpr}
	 * labeled alternative in {@link PlSql2Parser#table_ref}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJoinExpr(PlSql2Parser.JoinExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code TableRefSimple}
	 * labeled alternative in {@link PlSql2Parser#table_ref}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTableRefSimple(PlSql2Parser.TableRefSimpleContext ctx);
	/**
	 * Visit a parse tree produced by the {@code TableRefAux}
	 * labeled alternative in {@link PlSql2Parser#table_ref}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTableRefAux(PlSql2Parser.TableRefAuxContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#table_ref_aux}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTable_ref_aux(PlSql2Parser.Table_ref_auxContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#join_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJoin_clause(PlSql2Parser.Join_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#join_on_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJoin_on_part(PlSql2Parser.Join_on_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#join_using_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJoin_using_part(PlSql2Parser.Join_using_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#join_type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJoin_type(PlSql2Parser.Join_typeContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#query_partition_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitQuery_partition_clause(PlSql2Parser.Query_partition_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#flashback_query_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFlashback_query_clause(PlSql2Parser.Flashback_query_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#pivot_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPivot_clause(PlSql2Parser.Pivot_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#pivot_element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPivot_element(PlSql2Parser.Pivot_elementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#pivot_for_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPivot_for_clause(PlSql2Parser.Pivot_for_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#pivot_in_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPivot_in_clause(PlSql2Parser.Pivot_in_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#pivot_in_clause_element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPivot_in_clause_element(PlSql2Parser.Pivot_in_clause_elementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#pivot_in_clause_elements}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPivot_in_clause_elements(PlSql2Parser.Pivot_in_clause_elementsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#unpivot_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnpivot_clause(PlSql2Parser.Unpivot_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#unpivot_in_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnpivot_in_clause(PlSql2Parser.Unpivot_in_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#unpivot_in_elements}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnpivot_in_elements(PlSql2Parser.Unpivot_in_elementsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#hierarchical_query_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHierarchical_query_clause(PlSql2Parser.Hierarchical_query_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#start_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStart_part(PlSql2Parser.Start_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#group_by_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGroup_by_clause(PlSql2Parser.Group_by_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#group_by_elements}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGroup_by_elements(PlSql2Parser.Group_by_elementsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#rollup_cube_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRollup_cube_clause(PlSql2Parser.Rollup_cube_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#grouping_sets_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGrouping_sets_clause(PlSql2Parser.Grouping_sets_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#grouping_sets_elements}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGrouping_sets_elements(PlSql2Parser.Grouping_sets_elementsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#having_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHaving_clause(PlSql2Parser.Having_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#model_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModel_clause(PlSql2Parser.Model_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#cell_reference_options}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCell_reference_options(PlSql2Parser.Cell_reference_optionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#return_rows_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReturn_rows_clause(PlSql2Parser.Return_rows_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#reference_model}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReference_model(PlSql2Parser.Reference_modelContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#main_model}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMain_model(PlSql2Parser.Main_modelContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#model_column_clauses}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModel_column_clauses(PlSql2Parser.Model_column_clausesContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#model_column_partition_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModel_column_partition_part(PlSql2Parser.Model_column_partition_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#model_column_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModel_column_list(PlSql2Parser.Model_column_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#model_column}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModel_column(PlSql2Parser.Model_columnContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#model_rules_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModel_rules_clause(PlSql2Parser.Model_rules_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#model_rules_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModel_rules_part(PlSql2Parser.Model_rules_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#model_rules_element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModel_rules_element(PlSql2Parser.Model_rules_elementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#cell_assignment}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCell_assignment(PlSql2Parser.Cell_assignmentContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#model_iterate_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModel_iterate_clause(PlSql2Parser.Model_iterate_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#until_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUntil_part(PlSql2Parser.Until_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#order_by_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOrder_by_clause(PlSql2Parser.Order_by_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#order_by_elements}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOrder_by_elements(PlSql2Parser.Order_by_elementsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#for_update_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFor_update_clause(PlSql2Parser.For_update_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#for_update_of_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFor_update_of_part(PlSql2Parser.For_update_of_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#for_update_options}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFor_update_options(PlSql2Parser.For_update_optionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#limit_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLimit_clause(PlSql2Parser.Limit_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#update_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUpdate_statement(PlSql2Parser.Update_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#update_set_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUpdate_set_clause(PlSql2Parser.Update_set_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#column_based_update_set_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitColumn_based_update_set_clause(PlSql2Parser.Column_based_update_set_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#delete_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDelete_statement(PlSql2Parser.Delete_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#insert_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInsert_statement(PlSql2Parser.Insert_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#single_table_insert}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSingle_table_insert(PlSql2Parser.Single_table_insertContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#multi_table_insert}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMulti_table_insert(PlSql2Parser.Multi_table_insertContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#multi_table_element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMulti_table_element(PlSql2Parser.Multi_table_elementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#conditional_insert_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConditional_insert_clause(PlSql2Parser.Conditional_insert_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#conditional_insert_when_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConditional_insert_when_part(PlSql2Parser.Conditional_insert_when_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#conditional_insert_else_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConditional_insert_else_part(PlSql2Parser.Conditional_insert_else_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#insert_into_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInsert_into_clause(PlSql2Parser.Insert_into_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#values_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitValues_clause(PlSql2Parser.Values_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#merge_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMerge_statement(PlSql2Parser.Merge_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#merge_update_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMerge_update_clause(PlSql2Parser.Merge_update_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#merge_element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMerge_element(PlSql2Parser.Merge_elementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#merge_update_delete_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMerge_update_delete_part(PlSql2Parser.Merge_update_delete_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#merge_insert_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMerge_insert_clause(PlSql2Parser.Merge_insert_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#selected_tableview}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelected_tableview(PlSql2Parser.Selected_tableviewContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#lock_table_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLock_table_statement(PlSql2Parser.Lock_table_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#wait_nowait_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWait_nowait_part(PlSql2Parser.Wait_nowait_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#lock_table_element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLock_table_element(PlSql2Parser.Lock_table_elementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#lock_mode}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLock_mode(PlSql2Parser.Lock_modeContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#general_table_ref}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGeneral_table_ref(PlSql2Parser.General_table_refContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#static_returning_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStatic_returning_clause(PlSql2Parser.Static_returning_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#error_logging_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitError_logging_clause(PlSql2Parser.Error_logging_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#error_logging_into_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitError_logging_into_part(PlSql2Parser.Error_logging_into_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#error_logging_reject_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitError_logging_reject_part(PlSql2Parser.Error_logging_reject_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#dml_table_expression_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDml_table_expression_clause(PlSql2Parser.Dml_table_expression_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#table_collection_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTable_collection_expression(PlSql2Parser.Table_collection_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#subquery_restriction_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubquery_restriction_clause(PlSql2Parser.Subquery_restriction_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#sample_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSample_clause(PlSql2Parser.Sample_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#seed_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSeed_part(PlSql2Parser.Seed_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#cursor_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCursor_expression(PlSql2Parser.Cursor_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#expression_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpression_list(PlSql2Parser.Expression_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#condition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCondition(PlSql2Parser.ConditionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code IgnoreExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIgnoreExpr(PlSql2Parser.IgnoreExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code AndExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAndExpr(PlSql2Parser.AndExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code LikeExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLikeExpr(PlSql2Parser.LikeExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code RelExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRelExpr(PlSql2Parser.RelExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code MemberExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMemberExpr(PlSql2Parser.MemberExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code BetweenExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBetweenExpr(PlSql2Parser.BetweenExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CursorExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCursorExpr(PlSql2Parser.CursorExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code IsExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIsExpr(PlSql2Parser.IsExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code NotExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNotExpr(PlSql2Parser.NotExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code InExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInExpr(PlSql2Parser.InExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ParenExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParenExpr(PlSql2Parser.ParenExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code OrExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOrExpr(PlSql2Parser.OrExprContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#is_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIs_part(PlSql2Parser.Is_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#cursor_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCursor_part(PlSql2Parser.Cursor_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#multiset_type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMultiset_type(PlSql2Parser.Multiset_typeContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#relational_operator}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRelational_operator(PlSql2Parser.Relational_operatorContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#like_type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLike_type(PlSql2Parser.Like_typeContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#like_escape_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLike_escape_part(PlSql2Parser.Like_escape_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#between_elements}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBetween_elements(PlSql2Parser.Between_elementsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#concatenation}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConcatenation(PlSql2Parser.ConcatenationContext ctx);
	/**
	 * Visit a parse tree produced by the {@code BinaryExpr}
	 * labeled alternative in {@link PlSql2Parser#binary_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryExpr(PlSql2Parser.BinaryExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code IgnoreBinaryExpr}
	 * labeled alternative in {@link PlSql2Parser#binary_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIgnoreBinaryExpr(PlSql2Parser.IgnoreBinaryExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ParenBinaryExpr}
	 * labeled alternative in {@link PlSql2Parser#binary_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParenBinaryExpr(PlSql2Parser.ParenBinaryExprContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#interval_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInterval_expression(PlSql2Parser.Interval_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#model_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModel_expression(PlSql2Parser.Model_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#model_expression_element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModel_expression_element(PlSql2Parser.Model_expression_elementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#single_column_for_loop}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSingle_column_for_loop(PlSql2Parser.Single_column_for_loopContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#for_like_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFor_like_part(PlSql2Parser.For_like_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#for_increment_decrement_type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFor_increment_decrement_type(PlSql2Parser.For_increment_decrement_typeContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#multi_column_for_loop}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMulti_column_for_loop(PlSql2Parser.Multi_column_for_loopContext ctx);
	/**
	 * Visit a parse tree produced by the {@code IgnoreUnaryExpr}
	 * labeled alternative in {@link PlSql2Parser#unary_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIgnoreUnaryExpr(PlSql2Parser.IgnoreUnaryExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code UnaryExpr}
	 * labeled alternative in {@link PlSql2Parser#unary_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryExpr(PlSql2Parser.UnaryExprContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#case_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCase_statement(PlSql2Parser.Case_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#simple_case_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSimple_case_statement(PlSql2Parser.Simple_case_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#simple_case_when_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSimple_case_when_part(PlSql2Parser.Simple_case_when_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#searched_case_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSearched_case_statement(PlSql2Parser.Searched_case_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#searched_case_when_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSearched_case_when_part(PlSql2Parser.Searched_case_when_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#case_else_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCase_else_part(PlSql2Parser.Case_else_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAtom(PlSql2Parser.AtomContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#expression_or_vector}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpression_or_vector(PlSql2Parser.Expression_or_vectorContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#vector_expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVector_expr(PlSql2Parser.Vector_exprContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#quantified_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitQuantified_expression(PlSql2Parser.Quantified_expressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code AggregateCall}
	 * labeled alternative in {@link PlSql2Parser#standard_function}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAggregateCall(PlSql2Parser.AggregateCallContext ctx);
	/**
	 * Visit a parse tree produced by the {@code TodoCall}
	 * labeled alternative in {@link PlSql2Parser#standard_function}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTodoCall(PlSql2Parser.TodoCallContext ctx);
	/**
	 * Visit a parse tree produced by the {@code XmlCall}
	 * labeled alternative in {@link PlSql2Parser#standard_function}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitXmlCall(PlSql2Parser.XmlCallContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CastCall}
	 * labeled alternative in {@link PlSql2Parser#standard_function}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCastCall(PlSql2Parser.CastCallContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ExtractCall}
	 * labeled alternative in {@link PlSql2Parser#standard_function}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExtractCall(PlSql2Parser.ExtractCallContext ctx);
	/**
	 * Visit a parse tree produced by the {@code WithinOrOverCall}
	 * labeled alternative in {@link PlSql2Parser#standard_function}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWithinOrOverCall(PlSql2Parser.WithinOrOverCallContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#aggregate_windowed_function}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAggregate_windowed_function(PlSql2Parser.Aggregate_windowed_functionContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#over_clause_keyword}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOver_clause_keyword(PlSql2Parser.Over_clause_keywordContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#within_or_over_clause_keyword}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWithin_or_over_clause_keyword(PlSql2Parser.Within_or_over_clause_keywordContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#standard_prediction_function_keyword}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStandard_prediction_function_keyword(PlSql2Parser.Standard_prediction_function_keywordContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#over_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOver_clause(PlSql2Parser.Over_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#windowing_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWindowing_clause(PlSql2Parser.Windowing_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#windowing_type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWindowing_type(PlSql2Parser.Windowing_typeContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#windowing_elements}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWindowing_elements(PlSql2Parser.Windowing_elementsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#using_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsing_clause(PlSql2Parser.Using_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#using_element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsing_element(PlSql2Parser.Using_elementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#collect_order_by_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCollect_order_by_part(PlSql2Parser.Collect_order_by_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#within_or_over_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWithin_or_over_part(PlSql2Parser.Within_or_over_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#cost_matrix_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCost_matrix_clause(PlSql2Parser.Cost_matrix_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#xml_passing_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitXml_passing_clause(PlSql2Parser.Xml_passing_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#xml_attributes_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitXml_attributes_clause(PlSql2Parser.Xml_attributes_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#xml_namespaces_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitXml_namespaces_clause(PlSql2Parser.Xml_namespaces_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#xml_table_column}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitXml_table_column(PlSql2Parser.Xml_table_columnContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#xml_general_default_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitXml_general_default_part(PlSql2Parser.Xml_general_default_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#xml_multiuse_expression_element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitXml_multiuse_expression_element(PlSql2Parser.Xml_multiuse_expression_elementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#xmlroot_param_version_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitXmlroot_param_version_part(PlSql2Parser.Xmlroot_param_version_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#xmlroot_param_standalone_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitXmlroot_param_standalone_part(PlSql2Parser.Xmlroot_param_standalone_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#xmlserialize_param_enconding_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitXmlserialize_param_enconding_part(PlSql2Parser.Xmlserialize_param_enconding_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#xmlserialize_param_version_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitXmlserialize_param_version_part(PlSql2Parser.Xmlserialize_param_version_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#xmlserialize_param_ident_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitXmlserialize_param_ident_part(PlSql2Parser.Xmlserialize_param_ident_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#sql_plus_command}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSql_plus_command(PlSql2Parser.Sql_plus_commandContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#whenever_command}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhenever_command(PlSql2Parser.Whenever_commandContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#set_command}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSet_command(PlSql2Parser.Set_commandContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#exit_command}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExit_command(PlSql2Parser.Exit_commandContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#prompt_command}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrompt_command(PlSql2Parser.Prompt_commandContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#show_errors_command}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitShow_errors_command(PlSql2Parser.Show_errors_commandContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#partition_extension_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPartition_extension_clause(PlSql2Parser.Partition_extension_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#column_alias}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitColumn_alias(PlSql2Parser.Column_aliasContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#table_alias}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTable_alias(PlSql2Parser.Table_aliasContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#alias_quoted_string}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAlias_quoted_string(PlSql2Parser.Alias_quoted_stringContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#where_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhere_clause(PlSql2Parser.Where_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#current_of_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCurrent_of_clause(PlSql2Parser.Current_of_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#into_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInto_clause(PlSql2Parser.Into_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#xml_column_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitXml_column_name(PlSql2Parser.Xml_column_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#cost_class_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCost_class_name(PlSql2Parser.Cost_class_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#attribute_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAttribute_name(PlSql2Parser.Attribute_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#savepoint_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSavepoint_name(PlSql2Parser.Savepoint_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#rollback_segment_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRollback_segment_name(PlSql2Parser.Rollback_segment_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#table_var_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTable_var_name(PlSql2Parser.Table_var_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#schema_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSchema_name(PlSql2Parser.Schema_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#routine_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRoutine_name(PlSql2Parser.Routine_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#package_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPackage_name(PlSql2Parser.Package_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#implementation_type_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitImplementation_type_name(PlSql2Parser.Implementation_type_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#parameter_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParameter_name(PlSql2Parser.Parameter_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#reference_model_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReference_model_name(PlSql2Parser.Reference_model_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#main_model_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMain_model_name(PlSql2Parser.Main_model_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#aggregate_function_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAggregate_function_name(PlSql2Parser.Aggregate_function_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#query_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitQuery_name(PlSql2Parser.Query_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#constraint_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstraint_name(PlSql2Parser.Constraint_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#label_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLabel_name(PlSql2Parser.Label_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#type_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitType_name(PlSql2Parser.Type_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#sequence_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSequence_name(PlSql2Parser.Sequence_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#exception_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitException_name(PlSql2Parser.Exception_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#function_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_name(PlSql2Parser.Function_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#procedure_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProcedure_name(PlSql2Parser.Procedure_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#trigger_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTrigger_name(PlSql2Parser.Trigger_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#variable_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVariable_name(PlSql2Parser.Variable_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#index_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIndex_name(PlSql2Parser.Index_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#cursor_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCursor_name(PlSql2Parser.Cursor_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#record_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRecord_name(PlSql2Parser.Record_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#collection_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCollection_name(PlSql2Parser.Collection_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#link_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLink_name(PlSql2Parser.Link_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#column_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitColumn_name(PlSql2Parser.Column_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#role_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRole_name(PlSql2Parser.Role_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#tableview_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTableview_name(PlSql2Parser.Tableview_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#dot_id}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDot_id(PlSql2Parser.Dot_idContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#star}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStar(PlSql2Parser.StarContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#keep_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitKeep_clause(PlSql2Parser.Keep_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#function_argument}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_argument(PlSql2Parser.Function_argumentContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#function_argument_analytic}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_argument_analytic(PlSql2Parser.Function_argument_analyticContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#function_argument_modeling}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_argument_modeling(PlSql2Parser.Function_argument_modelingContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#respect_or_ignore_nulls}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRespect_or_ignore_nulls(PlSql2Parser.Respect_or_ignore_nullsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#argument}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArgument(PlSql2Parser.ArgumentContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#type_spec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitType_spec(PlSql2Parser.Type_specContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#datatype}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDatatype(PlSql2Parser.DatatypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#precision_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrecision_part(PlSql2Parser.Precision_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#native_datatype_element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNative_datatype_element(PlSql2Parser.Native_datatype_elementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#bind_variable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBind_variable(PlSql2Parser.Bind_variableContext ctx);
	/**
	 * Visit a parse tree produced by the {@code FuncCall}
	 * labeled alternative in {@link PlSql2Parser#general_element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFuncCall(PlSql2Parser.FuncCallContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Identifier}
	 * labeled alternative in {@link PlSql2Parser#general_element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdentifier(PlSql2Parser.IdentifierContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#table_element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTable_element(PlSql2Parser.Table_elementContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#constant}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstant(PlSql2Parser.ConstantContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#numeric}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNumeric(PlSql2Parser.NumericContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#numeric_negative}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNumeric_negative(PlSql2Parser.Numeric_negativeContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#quoted_string}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitQuoted_string(PlSql2Parser.Quoted_stringContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#r_id}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitR_id(PlSql2Parser.R_idContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#id_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitId_expression(PlSql2Parser.Id_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#not_equal_op}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNot_equal_op(PlSql2Parser.Not_equal_opContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#greater_than_or_equals_op}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGreater_than_or_equals_op(PlSql2Parser.Greater_than_or_equals_opContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#less_than_or_equals_op}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLess_than_or_equals_op(PlSql2Parser.Less_than_or_equals_opContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#concatenation_op}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConcatenation_op(PlSql2Parser.Concatenation_opContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#outer_join_sign}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOuter_join_sign(PlSql2Parser.Outer_join_signContext ctx);
	/**
	 * Visit a parse tree produced by {@link PlSql2Parser#regular_id}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRegular_id(PlSql2Parser.Regular_idContext ctx);
}
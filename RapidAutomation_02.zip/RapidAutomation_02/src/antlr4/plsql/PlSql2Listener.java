// Generated from C:/Users/c190471/Desktop/Projects/java/RapidAutomation/src/antlr4/plsql\PlSql2.g4 by ANTLR 4.8
package antlr4.plsql;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link PlSql2Parser}.
 */
public interface PlSql2Listener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#swallow_to_semi}.
	 * @param ctx the parse tree
	 */
	void enterSwallow_to_semi(PlSql2Parser.Swallow_to_semiContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#swallow_to_semi}.
	 * @param ctx the parse tree
	 */
	void exitSwallow_to_semi(PlSql2Parser.Swallow_to_semiContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#compilation_unit}.
	 * @param ctx the parse tree
	 */
	void enterCompilation_unit(PlSql2Parser.Compilation_unitContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#compilation_unit}.
	 * @param ctx the parse tree
	 */
	void exitCompilation_unit(PlSql2Parser.Compilation_unitContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#sql_script}.
	 * @param ctx the parse tree
	 */
	void enterSql_script(PlSql2Parser.Sql_scriptContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#sql_script}.
	 * @param ctx the parse tree
	 */
	void exitSql_script(PlSql2Parser.Sql_scriptContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#sql_explain}.
	 * @param ctx the parse tree
	 */
	void enterSql_explain(PlSql2Parser.Sql_explainContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#sql_explain}.
	 * @param ctx the parse tree
	 */
	void exitSql_explain(PlSql2Parser.Sql_explainContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#unit_statement}.
	 * @param ctx the parse tree
	 */
	void enterUnit_statement(PlSql2Parser.Unit_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#unit_statement}.
	 * @param ctx the parse tree
	 */
	void exitUnit_statement(PlSql2Parser.Unit_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#unit_statement_body}.
	 * @param ctx the parse tree
	 */
	void enterUnit_statement_body(PlSql2Parser.Unit_statement_bodyContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#unit_statement_body}.
	 * @param ctx the parse tree
	 */
	void exitUnit_statement_body(PlSql2Parser.Unit_statement_bodyContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#create_role}.
	 * @param ctx the parse tree
	 */
	void enterCreate_role(PlSql2Parser.Create_roleContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#create_role}.
	 * @param ctx the parse tree
	 */
	void exitCreate_role(PlSql2Parser.Create_roleContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#role_option}.
	 * @param ctx the parse tree
	 */
	void enterRole_option(PlSql2Parser.Role_optionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#role_option}.
	 * @param ctx the parse tree
	 */
	void exitRole_option(PlSql2Parser.Role_optionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#refresh_materialized_view}.
	 * @param ctx the parse tree
	 */
	void enterRefresh_materialized_view(PlSql2Parser.Refresh_materialized_viewContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#refresh_materialized_view}.
	 * @param ctx the parse tree
	 */
	void exitRefresh_materialized_view(PlSql2Parser.Refresh_materialized_viewContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#create_materialized_view}.
	 * @param ctx the parse tree
	 */
	void enterCreate_materialized_view(PlSql2Parser.Create_materialized_viewContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#create_materialized_view}.
	 * @param ctx the parse tree
	 */
	void exitCreate_materialized_view(PlSql2Parser.Create_materialized_viewContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#create_mv_refresh}.
	 * @param ctx the parse tree
	 */
	void enterCreate_mv_refresh(PlSql2Parser.Create_mv_refreshContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#create_mv_refresh}.
	 * @param ctx the parse tree
	 */
	void exitCreate_mv_refresh(PlSql2Parser.Create_mv_refreshContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#build_clause}.
	 * @param ctx the parse tree
	 */
	void enterBuild_clause(PlSql2Parser.Build_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#build_clause}.
	 * @param ctx the parse tree
	 */
	void exitBuild_clause(PlSql2Parser.Build_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#alter_permission}.
	 * @param ctx the parse tree
	 */
	void enterAlter_permission(PlSql2Parser.Alter_permissionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#alter_permission}.
	 * @param ctx the parse tree
	 */
	void exitAlter_permission(PlSql2Parser.Alter_permissionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#permission_options}.
	 * @param ctx the parse tree
	 */
	void enterPermission_options(PlSql2Parser.Permission_optionsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#permission_options}.
	 * @param ctx the parse tree
	 */
	void exitPermission_options(PlSql2Parser.Permission_optionsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#create_view}.
	 * @param ctx the parse tree
	 */
	void enterCreate_view(PlSql2Parser.Create_viewContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#create_view}.
	 * @param ctx the parse tree
	 */
	void exitCreate_view(PlSql2Parser.Create_viewContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#view_options}.
	 * @param ctx the parse tree
	 */
	void enterView_options(PlSql2Parser.View_optionsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#view_options}.
	 * @param ctx the parse tree
	 */
	void exitView_options(PlSql2Parser.View_optionsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#view_alias_constraint}.
	 * @param ctx the parse tree
	 */
	void enterView_alias_constraint(PlSql2Parser.View_alias_constraintContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#view_alias_constraint}.
	 * @param ctx the parse tree
	 */
	void exitView_alias_constraint(PlSql2Parser.View_alias_constraintContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#create_index}.
	 * @param ctx the parse tree
	 */
	void enterCreate_index(PlSql2Parser.Create_indexContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#create_index}.
	 * @param ctx the parse tree
	 */
	void exitCreate_index(PlSql2Parser.Create_indexContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#cluster_index_clause}.
	 * @param ctx the parse tree
	 */
	void enterCluster_index_clause(PlSql2Parser.Cluster_index_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#cluster_index_clause}.
	 * @param ctx the parse tree
	 */
	void exitCluster_index_clause(PlSql2Parser.Cluster_index_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#cluster_name}.
	 * @param ctx the parse tree
	 */
	void enterCluster_name(PlSql2Parser.Cluster_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#cluster_name}.
	 * @param ctx the parse tree
	 */
	void exitCluster_name(PlSql2Parser.Cluster_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#index_attributes}.
	 * @param ctx the parse tree
	 */
	void enterIndex_attributes(PlSql2Parser.Index_attributesContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#index_attributes}.
	 * @param ctx the parse tree
	 */
	void exitIndex_attributes(PlSql2Parser.Index_attributesContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#tablespace}.
	 * @param ctx the parse tree
	 */
	void enterTablespace(PlSql2Parser.TablespaceContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#tablespace}.
	 * @param ctx the parse tree
	 */
	void exitTablespace(PlSql2Parser.TablespaceContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#key_compression}.
	 * @param ctx the parse tree
	 */
	void enterKey_compression(PlSql2Parser.Key_compressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#key_compression}.
	 * @param ctx the parse tree
	 */
	void exitKey_compression(PlSql2Parser.Key_compressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#sort_or_nosort}.
	 * @param ctx the parse tree
	 */
	void enterSort_or_nosort(PlSql2Parser.Sort_or_nosortContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#sort_or_nosort}.
	 * @param ctx the parse tree
	 */
	void exitSort_or_nosort(PlSql2Parser.Sort_or_nosortContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#visible_or_invisible}.
	 * @param ctx the parse tree
	 */
	void enterVisible_or_invisible(PlSql2Parser.Visible_or_invisibleContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#visible_or_invisible}.
	 * @param ctx the parse tree
	 */
	void exitVisible_or_invisible(PlSql2Parser.Visible_or_invisibleContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#parallel_clause}.
	 * @param ctx the parse tree
	 */
	void enterParallel_clause(PlSql2Parser.Parallel_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#parallel_clause}.
	 * @param ctx the parse tree
	 */
	void exitParallel_clause(PlSql2Parser.Parallel_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#table_index_clause}.
	 * @param ctx the parse tree
	 */
	void enterTable_index_clause(PlSql2Parser.Table_index_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#table_index_clause}.
	 * @param ctx the parse tree
	 */
	void exitTable_index_clause(PlSql2Parser.Table_index_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#index_expr}.
	 * @param ctx the parse tree
	 */
	void enterIndex_expr(PlSql2Parser.Index_exprContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#index_expr}.
	 * @param ctx the parse tree
	 */
	void exitIndex_expr(PlSql2Parser.Index_exprContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#index_properties}.
	 * @param ctx the parse tree
	 */
	void enterIndex_properties(PlSql2Parser.Index_propertiesContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#index_properties}.
	 * @param ctx the parse tree
	 */
	void exitIndex_properties(PlSql2Parser.Index_propertiesContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#global_partitioned_index}.
	 * @param ctx the parse tree
	 */
	void enterGlobal_partitioned_index(PlSql2Parser.Global_partitioned_indexContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#global_partitioned_index}.
	 * @param ctx the parse tree
	 */
	void exitGlobal_partitioned_index(PlSql2Parser.Global_partitioned_indexContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#index_partitioning_clause}.
	 * @param ctx the parse tree
	 */
	void enterIndex_partitioning_clause(PlSql2Parser.Index_partitioning_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#index_partitioning_clause}.
	 * @param ctx the parse tree
	 */
	void exitIndex_partitioning_clause(PlSql2Parser.Index_partitioning_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#partition_name}.
	 * @param ctx the parse tree
	 */
	void enterPartition_name(PlSql2Parser.Partition_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#partition_name}.
	 * @param ctx the parse tree
	 */
	void exitPartition_name(PlSql2Parser.Partition_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#literal}.
	 * @param ctx the parse tree
	 */
	void enterLiteral(PlSql2Parser.LiteralContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#literal}.
	 * @param ctx the parse tree
	 */
	void exitLiteral(PlSql2Parser.LiteralContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#string_function}.
	 * @param ctx the parse tree
	 */
	void enterString_function(PlSql2Parser.String_functionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#string_function}.
	 * @param ctx the parse tree
	 */
	void exitString_function(PlSql2Parser.String_functionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#expressions}.
	 * @param ctx the parse tree
	 */
	void enterExpressions(PlSql2Parser.ExpressionsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#expressions}.
	 * @param ctx the parse tree
	 */
	void exitExpressions(PlSql2Parser.ExpressionsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#individual_hash_partitions}.
	 * @param ctx the parse tree
	 */
	void enterIndividual_hash_partitions(PlSql2Parser.Individual_hash_partitionsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#individual_hash_partitions}.
	 * @param ctx the parse tree
	 */
	void exitIndividual_hash_partitions(PlSql2Parser.Individual_hash_partitionsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#partitioning_storage_clause}.
	 * @param ctx the parse tree
	 */
	void enterPartitioning_storage_clause(PlSql2Parser.Partitioning_storage_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#partitioning_storage_clause}.
	 * @param ctx the parse tree
	 */
	void exitPartitioning_storage_clause(PlSql2Parser.Partitioning_storage_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#table_compression}.
	 * @param ctx the parse tree
	 */
	void enterTable_compression(PlSql2Parser.Table_compressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#table_compression}.
	 * @param ctx the parse tree
	 */
	void exitTable_compression(PlSql2Parser.Table_compressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#lob_partitioning_storage}.
	 * @param ctx the parse tree
	 */
	void enterLob_partitioning_storage(PlSql2Parser.Lob_partitioning_storageContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#lob_partitioning_storage}.
	 * @param ctx the parse tree
	 */
	void exitLob_partitioning_storage(PlSql2Parser.Lob_partitioning_storageContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#lob_item}.
	 * @param ctx the parse tree
	 */
	void enterLob_item(PlSql2Parser.Lob_itemContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#lob_item}.
	 * @param ctx the parse tree
	 */
	void exitLob_item(PlSql2Parser.Lob_itemContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#lob_segname}.
	 * @param ctx the parse tree
	 */
	void enterLob_segname(PlSql2Parser.Lob_segnameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#lob_segname}.
	 * @param ctx the parse tree
	 */
	void exitLob_segname(PlSql2Parser.Lob_segnameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#varray_item}.
	 * @param ctx the parse tree
	 */
	void enterVarray_item(PlSql2Parser.Varray_itemContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#varray_item}.
	 * @param ctx the parse tree
	 */
	void exitVarray_item(PlSql2Parser.Varray_itemContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#hash_partitions_by_quantity}.
	 * @param ctx the parse tree
	 */
	void enterHash_partitions_by_quantity(PlSql2Parser.Hash_partitions_by_quantityContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#hash_partitions_by_quantity}.
	 * @param ctx the parse tree
	 */
	void exitHash_partitions_by_quantity(PlSql2Parser.Hash_partitions_by_quantityContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#hash_partition_quantity}.
	 * @param ctx the parse tree
	 */
	void enterHash_partition_quantity(PlSql2Parser.Hash_partition_quantityContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#hash_partition_quantity}.
	 * @param ctx the parse tree
	 */
	void exitHash_partition_quantity(PlSql2Parser.Hash_partition_quantityContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#local_partitioned_index}.
	 * @param ctx the parse tree
	 */
	void enterLocal_partitioned_index(PlSql2Parser.Local_partitioned_indexContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#local_partitioned_index}.
	 * @param ctx the parse tree
	 */
	void exitLocal_partitioned_index(PlSql2Parser.Local_partitioned_indexContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#on_range_partitioned_table}.
	 * @param ctx the parse tree
	 */
	void enterOn_range_partitioned_table(PlSql2Parser.On_range_partitioned_tableContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#on_range_partitioned_table}.
	 * @param ctx the parse tree
	 */
	void exitOn_range_partitioned_table(PlSql2Parser.On_range_partitioned_tableContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#on_list_partitioned_table}.
	 * @param ctx the parse tree
	 */
	void enterOn_list_partitioned_table(PlSql2Parser.On_list_partitioned_tableContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#on_list_partitioned_table}.
	 * @param ctx the parse tree
	 */
	void exitOn_list_partitioned_table(PlSql2Parser.On_list_partitioned_tableContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#on_hash_partitioned_table}.
	 * @param ctx the parse tree
	 */
	void enterOn_hash_partitioned_table(PlSql2Parser.On_hash_partitioned_tableContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#on_hash_partitioned_table}.
	 * @param ctx the parse tree
	 */
	void exitOn_hash_partitioned_table(PlSql2Parser.On_hash_partitioned_tableContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#on_comp_partitioned_table}.
	 * @param ctx the parse tree
	 */
	void enterOn_comp_partitioned_table(PlSql2Parser.On_comp_partitioned_tableContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#on_comp_partitioned_table}.
	 * @param ctx the parse tree
	 */
	void exitOn_comp_partitioned_table(PlSql2Parser.On_comp_partitioned_tableContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#index_subpartition_clause}.
	 * @param ctx the parse tree
	 */
	void enterIndex_subpartition_clause(PlSql2Parser.Index_subpartition_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#index_subpartition_clause}.
	 * @param ctx the parse tree
	 */
	void exitIndex_subpartition_clause(PlSql2Parser.Index_subpartition_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#subpartition_name}.
	 * @param ctx the parse tree
	 */
	void enterSubpartition_name(PlSql2Parser.Subpartition_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#subpartition_name}.
	 * @param ctx the parse tree
	 */
	void exitSubpartition_name(PlSql2Parser.Subpartition_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#domain_index_clause}.
	 * @param ctx the parse tree
	 */
	void enterDomain_index_clause(PlSql2Parser.Domain_index_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#domain_index_clause}.
	 * @param ctx the parse tree
	 */
	void exitDomain_index_clause(PlSql2Parser.Domain_index_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#indextype}.
	 * @param ctx the parse tree
	 */
	void enterIndextype(PlSql2Parser.IndextypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#indextype}.
	 * @param ctx the parse tree
	 */
	void exitIndextype(PlSql2Parser.IndextypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#odci_parameters}.
	 * @param ctx the parse tree
	 */
	void enterOdci_parameters(PlSql2Parser.Odci_parametersContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#odci_parameters}.
	 * @param ctx the parse tree
	 */
	void exitOdci_parameters(PlSql2Parser.Odci_parametersContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#local_domain_index_clause}.
	 * @param ctx the parse tree
	 */
	void enterLocal_domain_index_clause(PlSql2Parser.Local_domain_index_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#local_domain_index_clause}.
	 * @param ctx the parse tree
	 */
	void exitLocal_domain_index_clause(PlSql2Parser.Local_domain_index_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#xmlindex_clause}.
	 * @param ctx the parse tree
	 */
	void enterXmlindex_clause(PlSql2Parser.Xmlindex_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#xmlindex_clause}.
	 * @param ctx the parse tree
	 */
	void exitXmlindex_clause(PlSql2Parser.Xmlindex_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#local_xmlindex_clause}.
	 * @param ctx the parse tree
	 */
	void enterLocal_xmlindex_clause(PlSql2Parser.Local_xmlindex_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#local_xmlindex_clause}.
	 * @param ctx the parse tree
	 */
	void exitLocal_xmlindex_clause(PlSql2Parser.Local_xmlindex_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#bitmap_join_index_clause}.
	 * @param ctx the parse tree
	 */
	void enterBitmap_join_index_clause(PlSql2Parser.Bitmap_join_index_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#bitmap_join_index_clause}.
	 * @param ctx the parse tree
	 */
	void exitBitmap_join_index_clause(PlSql2Parser.Bitmap_join_index_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#create_table}.
	 * @param ctx the parse tree
	 */
	void enterCreate_table(PlSql2Parser.Create_tableContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#create_table}.
	 * @param ctx the parse tree
	 */
	void exitCreate_table(PlSql2Parser.Create_tableContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#relational_table}.
	 * @param ctx the parse tree
	 */
	void enterRelational_table(PlSql2Parser.Relational_tableContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#relational_table}.
	 * @param ctx the parse tree
	 */
	void exitRelational_table(PlSql2Parser.Relational_tableContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#relational_properties}.
	 * @param ctx the parse tree
	 */
	void enterRelational_properties(PlSql2Parser.Relational_propertiesContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#relational_properties}.
	 * @param ctx the parse tree
	 */
	void exitRelational_properties(PlSql2Parser.Relational_propertiesContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#column_definition}.
	 * @param ctx the parse tree
	 */
	void enterColumn_definition(PlSql2Parser.Column_definitionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#column_definition}.
	 * @param ctx the parse tree
	 */
	void exitColumn_definition(PlSql2Parser.Column_definitionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#inline_ref_constraint}.
	 * @param ctx the parse tree
	 */
	void enterInline_ref_constraint(PlSql2Parser.Inline_ref_constraintContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#inline_ref_constraint}.
	 * @param ctx the parse tree
	 */
	void exitInline_ref_constraint(PlSql2Parser.Inline_ref_constraintContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#virtual_column_definition}.
	 * @param ctx the parse tree
	 */
	void enterVirtual_column_definition(PlSql2Parser.Virtual_column_definitionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#virtual_column_definition}.
	 * @param ctx the parse tree
	 */
	void exitVirtual_column_definition(PlSql2Parser.Virtual_column_definitionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#out_of_line_constraint}.
	 * @param ctx the parse tree
	 */
	void enterOut_of_line_constraint(PlSql2Parser.Out_of_line_constraintContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#out_of_line_constraint}.
	 * @param ctx the parse tree
	 */
	void exitOut_of_line_constraint(PlSql2Parser.Out_of_line_constraintContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#foreign_key_clause}.
	 * @param ctx the parse tree
	 */
	void enterForeign_key_clause(PlSql2Parser.Foreign_key_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#foreign_key_clause}.
	 * @param ctx the parse tree
	 */
	void exitForeign_key_clause(PlSql2Parser.Foreign_key_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#on_delete_clause}.
	 * @param ctx the parse tree
	 */
	void enterOn_delete_clause(PlSql2Parser.On_delete_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#on_delete_clause}.
	 * @param ctx the parse tree
	 */
	void exitOn_delete_clause(PlSql2Parser.On_delete_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#out_of_line_ref_constraint}.
	 * @param ctx the parse tree
	 */
	void enterOut_of_line_ref_constraint(PlSql2Parser.Out_of_line_ref_constraintContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#out_of_line_ref_constraint}.
	 * @param ctx the parse tree
	 */
	void exitOut_of_line_ref_constraint(PlSql2Parser.Out_of_line_ref_constraintContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#supplemental_logging_props}.
	 * @param ctx the parse tree
	 */
	void enterSupplemental_logging_props(PlSql2Parser.Supplemental_logging_propsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#supplemental_logging_props}.
	 * @param ctx the parse tree
	 */
	void exitSupplemental_logging_props(PlSql2Parser.Supplemental_logging_propsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#supplemental_log_grp_clause}.
	 * @param ctx the parse tree
	 */
	void enterSupplemental_log_grp_clause(PlSql2Parser.Supplemental_log_grp_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#supplemental_log_grp_clause}.
	 * @param ctx the parse tree
	 */
	void exitSupplemental_log_grp_clause(PlSql2Parser.Supplemental_log_grp_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#log_grp}.
	 * @param ctx the parse tree
	 */
	void enterLog_grp(PlSql2Parser.Log_grpContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#log_grp}.
	 * @param ctx the parse tree
	 */
	void exitLog_grp(PlSql2Parser.Log_grpContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#supplemental_id_key_clause}.
	 * @param ctx the parse tree
	 */
	void enterSupplemental_id_key_clause(PlSql2Parser.Supplemental_id_key_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#supplemental_id_key_clause}.
	 * @param ctx the parse tree
	 */
	void exitSupplemental_id_key_clause(PlSql2Parser.Supplemental_id_key_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#physical_properties}.
	 * @param ctx the parse tree
	 */
	void enterPhysical_properties(PlSql2Parser.Physical_propertiesContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#physical_properties}.
	 * @param ctx the parse tree
	 */
	void exitPhysical_properties(PlSql2Parser.Physical_propertiesContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#deferred_segment_creation}.
	 * @param ctx the parse tree
	 */
	void enterDeferred_segment_creation(PlSql2Parser.Deferred_segment_creationContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#deferred_segment_creation}.
	 * @param ctx the parse tree
	 */
	void exitDeferred_segment_creation(PlSql2Parser.Deferred_segment_creationContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#segment_attributes_clause}.
	 * @param ctx the parse tree
	 */
	void enterSegment_attributes_clause(PlSql2Parser.Segment_attributes_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#segment_attributes_clause}.
	 * @param ctx the parse tree
	 */
	void exitSegment_attributes_clause(PlSql2Parser.Segment_attributes_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#physical_attributes_clause}.
	 * @param ctx the parse tree
	 */
	void enterPhysical_attributes_clause(PlSql2Parser.Physical_attributes_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#physical_attributes_clause}.
	 * @param ctx the parse tree
	 */
	void exitPhysical_attributes_clause(PlSql2Parser.Physical_attributes_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#storage_clause}.
	 * @param ctx the parse tree
	 */
	void enterStorage_clause(PlSql2Parser.Storage_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#storage_clause}.
	 * @param ctx the parse tree
	 */
	void exitStorage_clause(PlSql2Parser.Storage_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#size_clause}.
	 * @param ctx the parse tree
	 */
	void enterSize_clause(PlSql2Parser.Size_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#size_clause}.
	 * @param ctx the parse tree
	 */
	void exitSize_clause(PlSql2Parser.Size_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#logging_clause}.
	 * @param ctx the parse tree
	 */
	void enterLogging_clause(PlSql2Parser.Logging_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#logging_clause}.
	 * @param ctx the parse tree
	 */
	void exitLogging_clause(PlSql2Parser.Logging_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#column_properties}.
	 * @param ctx the parse tree
	 */
	void enterColumn_properties(PlSql2Parser.Column_propertiesContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#column_properties}.
	 * @param ctx the parse tree
	 */
	void exitColumn_properties(PlSql2Parser.Column_propertiesContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#object_type_col_properties}.
	 * @param ctx the parse tree
	 */
	void enterObject_type_col_properties(PlSql2Parser.Object_type_col_propertiesContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#object_type_col_properties}.
	 * @param ctx the parse tree
	 */
	void exitObject_type_col_properties(PlSql2Parser.Object_type_col_propertiesContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#substitutable_column_clause}.
	 * @param ctx the parse tree
	 */
	void enterSubstitutable_column_clause(PlSql2Parser.Substitutable_column_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#substitutable_column_clause}.
	 * @param ctx the parse tree
	 */
	void exitSubstitutable_column_clause(PlSql2Parser.Substitutable_column_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#nested_table_col_properties}.
	 * @param ctx the parse tree
	 */
	void enterNested_table_col_properties(PlSql2Parser.Nested_table_col_propertiesContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#nested_table_col_properties}.
	 * @param ctx the parse tree
	 */
	void exitNested_table_col_properties(PlSql2Parser.Nested_table_col_propertiesContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#nested_item}.
	 * @param ctx the parse tree
	 */
	void enterNested_item(PlSql2Parser.Nested_itemContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#nested_item}.
	 * @param ctx the parse tree
	 */
	void exitNested_item(PlSql2Parser.Nested_itemContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#object_properties}.
	 * @param ctx the parse tree
	 */
	void enterObject_properties(PlSql2Parser.Object_propertiesContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#object_properties}.
	 * @param ctx the parse tree
	 */
	void exitObject_properties(PlSql2Parser.Object_propertiesContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#inline_constraint}.
	 * @param ctx the parse tree
	 */
	void enterInline_constraint(PlSql2Parser.Inline_constraintContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#inline_constraint}.
	 * @param ctx the parse tree
	 */
	void exitInline_constraint(PlSql2Parser.Inline_constraintContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#references_clause}.
	 * @param ctx the parse tree
	 */
	void enterReferences_clause(PlSql2Parser.References_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#references_clause}.
	 * @param ctx the parse tree
	 */
	void exitReferences_clause(PlSql2Parser.References_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#paren_column_list}.
	 * @param ctx the parse tree
	 */
	void enterParen_column_list(PlSql2Parser.Paren_column_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#paren_column_list}.
	 * @param ctx the parse tree
	 */
	void exitParen_column_list(PlSql2Parser.Paren_column_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#column_list}.
	 * @param ctx the parse tree
	 */
	void enterColumn_list(PlSql2Parser.Column_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#column_list}.
	 * @param ctx the parse tree
	 */
	void exitColumn_list(PlSql2Parser.Column_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#check_constraint}.
	 * @param ctx the parse tree
	 */
	void enterCheck_constraint(PlSql2Parser.Check_constraintContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#check_constraint}.
	 * @param ctx the parse tree
	 */
	void exitCheck_constraint(PlSql2Parser.Check_constraintContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#constraint_state}.
	 * @param ctx the parse tree
	 */
	void enterConstraint_state(PlSql2Parser.Constraint_stateContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#constraint_state}.
	 * @param ctx the parse tree
	 */
	void exitConstraint_state(PlSql2Parser.Constraint_stateContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#using_index_clause}.
	 * @param ctx the parse tree
	 */
	void enterUsing_index_clause(PlSql2Parser.Using_index_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#using_index_clause}.
	 * @param ctx the parse tree
	 */
	void exitUsing_index_clause(PlSql2Parser.Using_index_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#varray_col_properties}.
	 * @param ctx the parse tree
	 */
	void enterVarray_col_properties(PlSql2Parser.Varray_col_propertiesContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#varray_col_properties}.
	 * @param ctx the parse tree
	 */
	void exitVarray_col_properties(PlSql2Parser.Varray_col_propertiesContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#varray_storage_clause}.
	 * @param ctx the parse tree
	 */
	void enterVarray_storage_clause(PlSql2Parser.Varray_storage_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#varray_storage_clause}.
	 * @param ctx the parse tree
	 */
	void exitVarray_storage_clause(PlSql2Parser.Varray_storage_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#lob_storage_parameters}.
	 * @param ctx the parse tree
	 */
	void enterLob_storage_parameters(PlSql2Parser.Lob_storage_parametersContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#lob_storage_parameters}.
	 * @param ctx the parse tree
	 */
	void exitLob_storage_parameters(PlSql2Parser.Lob_storage_parametersContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#lob_parameters}.
	 * @param ctx the parse tree
	 */
	void enterLob_parameters(PlSql2Parser.Lob_parametersContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#lob_parameters}.
	 * @param ctx the parse tree
	 */
	void exitLob_parameters(PlSql2Parser.Lob_parametersContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#lob_retention_clause}.
	 * @param ctx the parse tree
	 */
	void enterLob_retention_clause(PlSql2Parser.Lob_retention_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#lob_retention_clause}.
	 * @param ctx the parse tree
	 */
	void exitLob_retention_clause(PlSql2Parser.Lob_retention_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#lob_deduplicate_clause}.
	 * @param ctx the parse tree
	 */
	void enterLob_deduplicate_clause(PlSql2Parser.Lob_deduplicate_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#lob_deduplicate_clause}.
	 * @param ctx the parse tree
	 */
	void exitLob_deduplicate_clause(PlSql2Parser.Lob_deduplicate_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#lob_compression_clause}.
	 * @param ctx the parse tree
	 */
	void enterLob_compression_clause(PlSql2Parser.Lob_compression_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#lob_compression_clause}.
	 * @param ctx the parse tree
	 */
	void exitLob_compression_clause(PlSql2Parser.Lob_compression_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#encryption_spec}.
	 * @param ctx the parse tree
	 */
	void enterEncryption_spec(PlSql2Parser.Encryption_specContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#encryption_spec}.
	 * @param ctx the parse tree
	 */
	void exitEncryption_spec(PlSql2Parser.Encryption_specContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#lob_storage_clause}.
	 * @param ctx the parse tree
	 */
	void enterLob_storage_clause(PlSql2Parser.Lob_storage_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#lob_storage_clause}.
	 * @param ctx the parse tree
	 */
	void exitLob_storage_clause(PlSql2Parser.Lob_storage_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#xmltype_column_properties}.
	 * @param ctx the parse tree
	 */
	void enterXmltype_column_properties(PlSql2Parser.Xmltype_column_propertiesContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#xmltype_column_properties}.
	 * @param ctx the parse tree
	 */
	void exitXmltype_column_properties(PlSql2Parser.Xmltype_column_propertiesContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#xmltype_storage}.
	 * @param ctx the parse tree
	 */
	void enterXmltype_storage(PlSql2Parser.Xmltype_storageContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#xmltype_storage}.
	 * @param ctx the parse tree
	 */
	void exitXmltype_storage(PlSql2Parser.Xmltype_storageContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#xmlschema_spec}.
	 * @param ctx the parse tree
	 */
	void enterXmlschema_spec(PlSql2Parser.Xmlschema_specContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#xmlschema_spec}.
	 * @param ctx the parse tree
	 */
	void exitXmlschema_spec(PlSql2Parser.Xmlschema_specContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#allow_or_disallow}.
	 * @param ctx the parse tree
	 */
	void enterAllow_or_disallow(PlSql2Parser.Allow_or_disallowContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#allow_or_disallow}.
	 * @param ctx the parse tree
	 */
	void exitAllow_or_disallow(PlSql2Parser.Allow_or_disallowContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#table_partitioning_clauses}.
	 * @param ctx the parse tree
	 */
	void enterTable_partitioning_clauses(PlSql2Parser.Table_partitioning_clausesContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#table_partitioning_clauses}.
	 * @param ctx the parse tree
	 */
	void exitTable_partitioning_clauses(PlSql2Parser.Table_partitioning_clausesContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#range_partitions}.
	 * @param ctx the parse tree
	 */
	void enterRange_partitions(PlSql2Parser.Range_partitionsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#range_partitions}.
	 * @param ctx the parse tree
	 */
	void exitRange_partitions(PlSql2Parser.Range_partitionsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#range_values_clause}.
	 * @param ctx the parse tree
	 */
	void enterRange_values_clause(PlSql2Parser.Range_values_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#range_values_clause}.
	 * @param ctx the parse tree
	 */
	void exitRange_values_clause(PlSql2Parser.Range_values_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#table_partition_description}.
	 * @param ctx the parse tree
	 */
	void enterTable_partition_description(PlSql2Parser.Table_partition_descriptionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#table_partition_description}.
	 * @param ctx the parse tree
	 */
	void exitTable_partition_description(PlSql2Parser.Table_partition_descriptionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#list_partitions}.
	 * @param ctx the parse tree
	 */
	void enterList_partitions(PlSql2Parser.List_partitionsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#list_partitions}.
	 * @param ctx the parse tree
	 */
	void exitList_partitions(PlSql2Parser.List_partitionsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#list_values_clause}.
	 * @param ctx the parse tree
	 */
	void enterList_values_clause(PlSql2Parser.List_values_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#list_values_clause}.
	 * @param ctx the parse tree
	 */
	void exitList_values_clause(PlSql2Parser.List_values_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#hash_partitions}.
	 * @param ctx the parse tree
	 */
	void enterHash_partitions(PlSql2Parser.Hash_partitionsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#hash_partitions}.
	 * @param ctx the parse tree
	 */
	void exitHash_partitions(PlSql2Parser.Hash_partitionsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#composite_range_partitions}.
	 * @param ctx the parse tree
	 */
	void enterComposite_range_partitions(PlSql2Parser.Composite_range_partitionsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#composite_range_partitions}.
	 * @param ctx the parse tree
	 */
	void exitComposite_range_partitions(PlSql2Parser.Composite_range_partitionsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#subpartition_by_range}.
	 * @param ctx the parse tree
	 */
	void enterSubpartition_by_range(PlSql2Parser.Subpartition_by_rangeContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#subpartition_by_range}.
	 * @param ctx the parse tree
	 */
	void exitSubpartition_by_range(PlSql2Parser.Subpartition_by_rangeContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#subpartition_by_list}.
	 * @param ctx the parse tree
	 */
	void enterSubpartition_by_list(PlSql2Parser.Subpartition_by_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#subpartition_by_list}.
	 * @param ctx the parse tree
	 */
	void exitSubpartition_by_list(PlSql2Parser.Subpartition_by_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#subpartition_template}.
	 * @param ctx the parse tree
	 */
	void enterSubpartition_template(PlSql2Parser.Subpartition_templateContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#subpartition_template}.
	 * @param ctx the parse tree
	 */
	void exitSubpartition_template(PlSql2Parser.Subpartition_templateContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#range_subpartition_desc}.
	 * @param ctx the parse tree
	 */
	void enterRange_subpartition_desc(PlSql2Parser.Range_subpartition_descContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#range_subpartition_desc}.
	 * @param ctx the parse tree
	 */
	void exitRange_subpartition_desc(PlSql2Parser.Range_subpartition_descContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#list_subpartition_desc}.
	 * @param ctx the parse tree
	 */
	void enterList_subpartition_desc(PlSql2Parser.List_subpartition_descContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#list_subpartition_desc}.
	 * @param ctx the parse tree
	 */
	void exitList_subpartition_desc(PlSql2Parser.List_subpartition_descContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#individual_hash_subparts}.
	 * @param ctx the parse tree
	 */
	void enterIndividual_hash_subparts(PlSql2Parser.Individual_hash_subpartsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#individual_hash_subparts}.
	 * @param ctx the parse tree
	 */
	void exitIndividual_hash_subparts(PlSql2Parser.Individual_hash_subpartsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#hash_subpartition_quantity}.
	 * @param ctx the parse tree
	 */
	void enterHash_subpartition_quantity(PlSql2Parser.Hash_subpartition_quantityContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#hash_subpartition_quantity}.
	 * @param ctx the parse tree
	 */
	void exitHash_subpartition_quantity(PlSql2Parser.Hash_subpartition_quantityContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#subpartition_by_hash}.
	 * @param ctx the parse tree
	 */
	void enterSubpartition_by_hash(PlSql2Parser.Subpartition_by_hashContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#subpartition_by_hash}.
	 * @param ctx the parse tree
	 */
	void exitSubpartition_by_hash(PlSql2Parser.Subpartition_by_hashContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#range_partition_desc}.
	 * @param ctx the parse tree
	 */
	void enterRange_partition_desc(PlSql2Parser.Range_partition_descContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#range_partition_desc}.
	 * @param ctx the parse tree
	 */
	void exitRange_partition_desc(PlSql2Parser.Range_partition_descContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#hash_subparts_by_quantity}.
	 * @param ctx the parse tree
	 */
	void enterHash_subparts_by_quantity(PlSql2Parser.Hash_subparts_by_quantityContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#hash_subparts_by_quantity}.
	 * @param ctx the parse tree
	 */
	void exitHash_subparts_by_quantity(PlSql2Parser.Hash_subparts_by_quantityContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#composite_list_partitions}.
	 * @param ctx the parse tree
	 */
	void enterComposite_list_partitions(PlSql2Parser.Composite_list_partitionsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#composite_list_partitions}.
	 * @param ctx the parse tree
	 */
	void exitComposite_list_partitions(PlSql2Parser.Composite_list_partitionsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#list_partition_desc}.
	 * @param ctx the parse tree
	 */
	void enterList_partition_desc(PlSql2Parser.List_partition_descContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#list_partition_desc}.
	 * @param ctx the parse tree
	 */
	void exitList_partition_desc(PlSql2Parser.List_partition_descContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#composite_hash_partitions}.
	 * @param ctx the parse tree
	 */
	void enterComposite_hash_partitions(PlSql2Parser.Composite_hash_partitionsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#composite_hash_partitions}.
	 * @param ctx the parse tree
	 */
	void exitComposite_hash_partitions(PlSql2Parser.Composite_hash_partitionsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#reference_partitioning}.
	 * @param ctx the parse tree
	 */
	void enterReference_partitioning(PlSql2Parser.Reference_partitioningContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#reference_partitioning}.
	 * @param ctx the parse tree
	 */
	void exitReference_partitioning(PlSql2Parser.Reference_partitioningContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#reference_partition_desc}.
	 * @param ctx the parse tree
	 */
	void enterReference_partition_desc(PlSql2Parser.Reference_partition_descContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#reference_partition_desc}.
	 * @param ctx the parse tree
	 */
	void exitReference_partition_desc(PlSql2Parser.Reference_partition_descContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#system_partitioning}.
	 * @param ctx the parse tree
	 */
	void enterSystem_partitioning(PlSql2Parser.System_partitioningContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#system_partitioning}.
	 * @param ctx the parse tree
	 */
	void exitSystem_partitioning(PlSql2Parser.System_partitioningContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#enable_disable_clause}.
	 * @param ctx the parse tree
	 */
	void enterEnable_disable_clause(PlSql2Parser.Enable_disable_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#enable_disable_clause}.
	 * @param ctx the parse tree
	 */
	void exitEnable_disable_clause(PlSql2Parser.Enable_disable_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#exceptions_clause}.
	 * @param ctx the parse tree
	 */
	void enterExceptions_clause(PlSql2Parser.Exceptions_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#exceptions_clause}.
	 * @param ctx the parse tree
	 */
	void exitExceptions_clause(PlSql2Parser.Exceptions_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#row_movement_clause}.
	 * @param ctx the parse tree
	 */
	void enterRow_movement_clause(PlSql2Parser.Row_movement_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#row_movement_clause}.
	 * @param ctx the parse tree
	 */
	void exitRow_movement_clause(PlSql2Parser.Row_movement_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#flashback_archive_clause}.
	 * @param ctx the parse tree
	 */
	void enterFlashback_archive_clause(PlSql2Parser.Flashback_archive_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#flashback_archive_clause}.
	 * @param ctx the parse tree
	 */
	void exitFlashback_archive_clause(PlSql2Parser.Flashback_archive_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#object_table}.
	 * @param ctx the parse tree
	 */
	void enterObject_table(PlSql2Parser.Object_tableContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#object_table}.
	 * @param ctx the parse tree
	 */
	void exitObject_table(PlSql2Parser.Object_tableContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#object_table_substitution}.
	 * @param ctx the parse tree
	 */
	void enterObject_table_substitution(PlSql2Parser.Object_table_substitutionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#object_table_substitution}.
	 * @param ctx the parse tree
	 */
	void exitObject_table_substitution(PlSql2Parser.Object_table_substitutionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#oid_clause}.
	 * @param ctx the parse tree
	 */
	void enterOid_clause(PlSql2Parser.Oid_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#oid_clause}.
	 * @param ctx the parse tree
	 */
	void exitOid_clause(PlSql2Parser.Oid_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#oid_index_clause}.
	 * @param ctx the parse tree
	 */
	void enterOid_index_clause(PlSql2Parser.Oid_index_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#oid_index_clause}.
	 * @param ctx the parse tree
	 */
	void exitOid_index_clause(PlSql2Parser.Oid_index_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#xmltype_table}.
	 * @param ctx the parse tree
	 */
	void enterXmltype_table(PlSql2Parser.Xmltype_tableContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#xmltype_table}.
	 * @param ctx the parse tree
	 */
	void exitXmltype_table(PlSql2Parser.Xmltype_tableContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#xmltype_virtual_columns}.
	 * @param ctx the parse tree
	 */
	void enterXmltype_virtual_columns(PlSql2Parser.Xmltype_virtual_columnsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#xmltype_virtual_columns}.
	 * @param ctx the parse tree
	 */
	void exitXmltype_virtual_columns(PlSql2Parser.Xmltype_virtual_columnsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#drop_table}.
	 * @param ctx the parse tree
	 */
	void enterDrop_table(PlSql2Parser.Drop_tableContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#drop_table}.
	 * @param ctx the parse tree
	 */
	void exitDrop_table(PlSql2Parser.Drop_tableContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#alter_table}.
	 * @param ctx the parse tree
	 */
	void enterAlter_table(PlSql2Parser.Alter_tableContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#alter_table}.
	 * @param ctx the parse tree
	 */
	void exitAlter_table(PlSql2Parser.Alter_tableContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#alter_table_properties}.
	 * @param ctx the parse tree
	 */
	void enterAlter_table_properties(PlSql2Parser.Alter_table_propertiesContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#alter_table_properties}.
	 * @param ctx the parse tree
	 */
	void exitAlter_table_properties(PlSql2Parser.Alter_table_propertiesContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#alter_table_properties_1}.
	 * @param ctx the parse tree
	 */
	void enterAlter_table_properties_1(PlSql2Parser.Alter_table_properties_1Context ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#alter_table_properties_1}.
	 * @param ctx the parse tree
	 */
	void exitAlter_table_properties_1(PlSql2Parser.Alter_table_properties_1Context ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#supplemental_table_logging}.
	 * @param ctx the parse tree
	 */
	void enterSupplemental_table_logging(PlSql2Parser.Supplemental_table_loggingContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#supplemental_table_logging}.
	 * @param ctx the parse tree
	 */
	void exitSupplemental_table_logging(PlSql2Parser.Supplemental_table_loggingContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#allocate_extent_clause}.
	 * @param ctx the parse tree
	 */
	void enterAllocate_extent_clause(PlSql2Parser.Allocate_extent_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#allocate_extent_clause}.
	 * @param ctx the parse tree
	 */
	void exitAllocate_extent_clause(PlSql2Parser.Allocate_extent_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#deallocate_unused_clause}.
	 * @param ctx the parse tree
	 */
	void enterDeallocate_unused_clause(PlSql2Parser.Deallocate_unused_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#deallocate_unused_clause}.
	 * @param ctx the parse tree
	 */
	void exitDeallocate_unused_clause(PlSql2Parser.Deallocate_unused_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#upgrade_table_clause}.
	 * @param ctx the parse tree
	 */
	void enterUpgrade_table_clause(PlSql2Parser.Upgrade_table_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#upgrade_table_clause}.
	 * @param ctx the parse tree
	 */
	void exitUpgrade_table_clause(PlSql2Parser.Upgrade_table_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#records_per_block_clause}.
	 * @param ctx the parse tree
	 */
	void enterRecords_per_block_clause(PlSql2Parser.Records_per_block_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#records_per_block_clause}.
	 * @param ctx the parse tree
	 */
	void exitRecords_per_block_clause(PlSql2Parser.Records_per_block_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#alter_iot_clauses}.
	 * @param ctx the parse tree
	 */
	void enterAlter_iot_clauses(PlSql2Parser.Alter_iot_clausesContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#alter_iot_clauses}.
	 * @param ctx the parse tree
	 */
	void exitAlter_iot_clauses(PlSql2Parser.Alter_iot_clausesContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#index_org_table_clause}.
	 * @param ctx the parse tree
	 */
	void enterIndex_org_table_clause(PlSql2Parser.Index_org_table_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#index_org_table_clause}.
	 * @param ctx the parse tree
	 */
	void exitIndex_org_table_clause(PlSql2Parser.Index_org_table_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#mapping_table_clause}.
	 * @param ctx the parse tree
	 */
	void enterMapping_table_clause(PlSql2Parser.Mapping_table_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#mapping_table_clause}.
	 * @param ctx the parse tree
	 */
	void exitMapping_table_clause(PlSql2Parser.Mapping_table_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#index_org_overflow_clause}.
	 * @param ctx the parse tree
	 */
	void enterIndex_org_overflow_clause(PlSql2Parser.Index_org_overflow_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#index_org_overflow_clause}.
	 * @param ctx the parse tree
	 */
	void exitIndex_org_overflow_clause(PlSql2Parser.Index_org_overflow_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#alter_overflow_clause}.
	 * @param ctx the parse tree
	 */
	void enterAlter_overflow_clause(PlSql2Parser.Alter_overflow_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#alter_overflow_clause}.
	 * @param ctx the parse tree
	 */
	void exitAlter_overflow_clause(PlSql2Parser.Alter_overflow_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#add_overflow_clause}.
	 * @param ctx the parse tree
	 */
	void enterAdd_overflow_clause(PlSql2Parser.Add_overflow_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#add_overflow_clause}.
	 * @param ctx the parse tree
	 */
	void exitAdd_overflow_clause(PlSql2Parser.Add_overflow_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#shrink_clause}.
	 * @param ctx the parse tree
	 */
	void enterShrink_clause(PlSql2Parser.Shrink_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#shrink_clause}.
	 * @param ctx the parse tree
	 */
	void exitShrink_clause(PlSql2Parser.Shrink_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#alter_mapping_table_clause}.
	 * @param ctx the parse tree
	 */
	void enterAlter_mapping_table_clause(PlSql2Parser.Alter_mapping_table_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#alter_mapping_table_clause}.
	 * @param ctx the parse tree
	 */
	void exitAlter_mapping_table_clause(PlSql2Parser.Alter_mapping_table_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#constraint_clauses}.
	 * @param ctx the parse tree
	 */
	void enterConstraint_clauses(PlSql2Parser.Constraint_clausesContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#constraint_clauses}.
	 * @param ctx the parse tree
	 */
	void exitConstraint_clauses(PlSql2Parser.Constraint_clausesContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#old_constraint_name}.
	 * @param ctx the parse tree
	 */
	void enterOld_constraint_name(PlSql2Parser.Old_constraint_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#old_constraint_name}.
	 * @param ctx the parse tree
	 */
	void exitOld_constraint_name(PlSql2Parser.Old_constraint_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#new_constraint_name}.
	 * @param ctx the parse tree
	 */
	void enterNew_constraint_name(PlSql2Parser.New_constraint_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#new_constraint_name}.
	 * @param ctx the parse tree
	 */
	void exitNew_constraint_name(PlSql2Parser.New_constraint_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#drop_constraint_clause}.
	 * @param ctx the parse tree
	 */
	void enterDrop_constraint_clause(PlSql2Parser.Drop_constraint_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#drop_constraint_clause}.
	 * @param ctx the parse tree
	 */
	void exitDrop_constraint_clause(PlSql2Parser.Drop_constraint_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#drop_primary_key_or_unique_or_generic_clause}.
	 * @param ctx the parse tree
	 */
	void enterDrop_primary_key_or_unique_or_generic_clause(PlSql2Parser.Drop_primary_key_or_unique_or_generic_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#drop_primary_key_or_unique_or_generic_clause}.
	 * @param ctx the parse tree
	 */
	void exitDrop_primary_key_or_unique_or_generic_clause(PlSql2Parser.Drop_primary_key_or_unique_or_generic_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#column_clauses}.
	 * @param ctx the parse tree
	 */
	void enterColumn_clauses(PlSql2Parser.Column_clausesContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#column_clauses}.
	 * @param ctx the parse tree
	 */
	void exitColumn_clauses(PlSql2Parser.Column_clausesContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#add_modify_drop_column_clauses}.
	 * @param ctx the parse tree
	 */
	void enterAdd_modify_drop_column_clauses(PlSql2Parser.Add_modify_drop_column_clausesContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#add_modify_drop_column_clauses}.
	 * @param ctx the parse tree
	 */
	void exitAdd_modify_drop_column_clauses(PlSql2Parser.Add_modify_drop_column_clausesContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#add_column_clause}.
	 * @param ctx the parse tree
	 */
	void enterAdd_column_clause(PlSql2Parser.Add_column_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#add_column_clause}.
	 * @param ctx the parse tree
	 */
	void exitAdd_column_clause(PlSql2Parser.Add_column_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#modify_column_clauses}.
	 * @param ctx the parse tree
	 */
	void enterModify_column_clauses(PlSql2Parser.Modify_column_clausesContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#modify_column_clauses}.
	 * @param ctx the parse tree
	 */
	void exitModify_column_clauses(PlSql2Parser.Modify_column_clausesContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#alter_column_clause}.
	 * @param ctx the parse tree
	 */
	void enterAlter_column_clause(PlSql2Parser.Alter_column_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#alter_column_clause}.
	 * @param ctx the parse tree
	 */
	void exitAlter_column_clause(PlSql2Parser.Alter_column_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#modify_col_properties}.
	 * @param ctx the parse tree
	 */
	void enterModify_col_properties(PlSql2Parser.Modify_col_propertiesContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#modify_col_properties}.
	 * @param ctx the parse tree
	 */
	void exitModify_col_properties(PlSql2Parser.Modify_col_propertiesContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#modify_col_substitutable}.
	 * @param ctx the parse tree
	 */
	void enterModify_col_substitutable(PlSql2Parser.Modify_col_substitutableContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#modify_col_substitutable}.
	 * @param ctx the parse tree
	 */
	void exitModify_col_substitutable(PlSql2Parser.Modify_col_substitutableContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#drop_column_clause}.
	 * @param ctx the parse tree
	 */
	void enterDrop_column_clause(PlSql2Parser.Drop_column_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#drop_column_clause}.
	 * @param ctx the parse tree
	 */
	void exitDrop_column_clause(PlSql2Parser.Drop_column_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#rename_column_clause}.
	 * @param ctx the parse tree
	 */
	void enterRename_column_clause(PlSql2Parser.Rename_column_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#rename_column_clause}.
	 * @param ctx the parse tree
	 */
	void exitRename_column_clause(PlSql2Parser.Rename_column_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#old_column_name}.
	 * @param ctx the parse tree
	 */
	void enterOld_column_name(PlSql2Parser.Old_column_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#old_column_name}.
	 * @param ctx the parse tree
	 */
	void exitOld_column_name(PlSql2Parser.Old_column_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#new_column_name}.
	 * @param ctx the parse tree
	 */
	void enterNew_column_name(PlSql2Parser.New_column_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#new_column_name}.
	 * @param ctx the parse tree
	 */
	void exitNew_column_name(PlSql2Parser.New_column_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#modify_collection_retrieval}.
	 * @param ctx the parse tree
	 */
	void enterModify_collection_retrieval(PlSql2Parser.Modify_collection_retrievalContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#modify_collection_retrieval}.
	 * @param ctx the parse tree
	 */
	void exitModify_collection_retrieval(PlSql2Parser.Modify_collection_retrievalContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#collection_item}.
	 * @param ctx the parse tree
	 */
	void enterCollection_item(PlSql2Parser.Collection_itemContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#collection_item}.
	 * @param ctx the parse tree
	 */
	void exitCollection_item(PlSql2Parser.Collection_itemContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#modify_lob_storage_clause}.
	 * @param ctx the parse tree
	 */
	void enterModify_lob_storage_clause(PlSql2Parser.Modify_lob_storage_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#modify_lob_storage_clause}.
	 * @param ctx the parse tree
	 */
	void exitModify_lob_storage_clause(PlSql2Parser.Modify_lob_storage_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#modify_lob_parameters}.
	 * @param ctx the parse tree
	 */
	void enterModify_lob_parameters(PlSql2Parser.Modify_lob_parametersContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#modify_lob_parameters}.
	 * @param ctx the parse tree
	 */
	void exitModify_lob_parameters(PlSql2Parser.Modify_lob_parametersContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#drop_function}.
	 * @param ctx the parse tree
	 */
	void enterDrop_function(PlSql2Parser.Drop_functionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#drop_function}.
	 * @param ctx the parse tree
	 */
	void exitDrop_function(PlSql2Parser.Drop_functionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#alter_function}.
	 * @param ctx the parse tree
	 */
	void enterAlter_function(PlSql2Parser.Alter_functionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#alter_function}.
	 * @param ctx the parse tree
	 */
	void exitAlter_function(PlSql2Parser.Alter_functionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#create_function_body}.
	 * @param ctx the parse tree
	 */
	void enterCreate_function_body(PlSql2Parser.Create_function_bodyContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#create_function_body}.
	 * @param ctx the parse tree
	 */
	void exitCreate_function_body(PlSql2Parser.Create_function_bodyContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#parallel_enable_clause}.
	 * @param ctx the parse tree
	 */
	void enterParallel_enable_clause(PlSql2Parser.Parallel_enable_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#parallel_enable_clause}.
	 * @param ctx the parse tree
	 */
	void exitParallel_enable_clause(PlSql2Parser.Parallel_enable_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#partition_by_clause}.
	 * @param ctx the parse tree
	 */
	void enterPartition_by_clause(PlSql2Parser.Partition_by_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#partition_by_clause}.
	 * @param ctx the parse tree
	 */
	void exitPartition_by_clause(PlSql2Parser.Partition_by_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#result_cache_clause}.
	 * @param ctx the parse tree
	 */
	void enterResult_cache_clause(PlSql2Parser.Result_cache_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#result_cache_clause}.
	 * @param ctx the parse tree
	 */
	void exitResult_cache_clause(PlSql2Parser.Result_cache_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#relies_on_part}.
	 * @param ctx the parse tree
	 */
	void enterRelies_on_part(PlSql2Parser.Relies_on_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#relies_on_part}.
	 * @param ctx the parse tree
	 */
	void exitRelies_on_part(PlSql2Parser.Relies_on_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#streaming_clause}.
	 * @param ctx the parse tree
	 */
	void enterStreaming_clause(PlSql2Parser.Streaming_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#streaming_clause}.
	 * @param ctx the parse tree
	 */
	void exitStreaming_clause(PlSql2Parser.Streaming_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#drop_package}.
	 * @param ctx the parse tree
	 */
	void enterDrop_package(PlSql2Parser.Drop_packageContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#drop_package}.
	 * @param ctx the parse tree
	 */
	void exitDrop_package(PlSql2Parser.Drop_packageContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#alter_package}.
	 * @param ctx the parse tree
	 */
	void enterAlter_package(PlSql2Parser.Alter_packageContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#alter_package}.
	 * @param ctx the parse tree
	 */
	void exitAlter_package(PlSql2Parser.Alter_packageContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#create_package}.
	 * @param ctx the parse tree
	 */
	void enterCreate_package(PlSql2Parser.Create_packageContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#create_package}.
	 * @param ctx the parse tree
	 */
	void exitCreate_package(PlSql2Parser.Create_packageContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#package_body}.
	 * @param ctx the parse tree
	 */
	void enterPackage_body(PlSql2Parser.Package_bodyContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#package_body}.
	 * @param ctx the parse tree
	 */
	void exitPackage_body(PlSql2Parser.Package_bodyContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#package_spec}.
	 * @param ctx the parse tree
	 */
	void enterPackage_spec(PlSql2Parser.Package_specContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#package_spec}.
	 * @param ctx the parse tree
	 */
	void exitPackage_spec(PlSql2Parser.Package_specContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#package_obj_spec}.
	 * @param ctx the parse tree
	 */
	void enterPackage_obj_spec(PlSql2Parser.Package_obj_specContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#package_obj_spec}.
	 * @param ctx the parse tree
	 */
	void exitPackage_obj_spec(PlSql2Parser.Package_obj_specContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#procedure_spec}.
	 * @param ctx the parse tree
	 */
	void enterProcedure_spec(PlSql2Parser.Procedure_specContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#procedure_spec}.
	 * @param ctx the parse tree
	 */
	void exitProcedure_spec(PlSql2Parser.Procedure_specContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#function_spec}.
	 * @param ctx the parse tree
	 */
	void enterFunction_spec(PlSql2Parser.Function_specContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#function_spec}.
	 * @param ctx the parse tree
	 */
	void exitFunction_spec(PlSql2Parser.Function_specContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#package_obj_body}.
	 * @param ctx the parse tree
	 */
	void enterPackage_obj_body(PlSql2Parser.Package_obj_bodyContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#package_obj_body}.
	 * @param ctx the parse tree
	 */
	void exitPackage_obj_body(PlSql2Parser.Package_obj_bodyContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#drop_procedure}.
	 * @param ctx the parse tree
	 */
	void enterDrop_procedure(PlSql2Parser.Drop_procedureContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#drop_procedure}.
	 * @param ctx the parse tree
	 */
	void exitDrop_procedure(PlSql2Parser.Drop_procedureContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#alter_procedure}.
	 * @param ctx the parse tree
	 */
	void enterAlter_procedure(PlSql2Parser.Alter_procedureContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#alter_procedure}.
	 * @param ctx the parse tree
	 */
	void exitAlter_procedure(PlSql2Parser.Alter_procedureContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#create_procedure_body}.
	 * @param ctx the parse tree
	 */
	void enterCreate_procedure_body(PlSql2Parser.Create_procedure_bodyContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#create_procedure_body}.
	 * @param ctx the parse tree
	 */
	void exitCreate_procedure_body(PlSql2Parser.Create_procedure_bodyContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#drop_trigger}.
	 * @param ctx the parse tree
	 */
	void enterDrop_trigger(PlSql2Parser.Drop_triggerContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#drop_trigger}.
	 * @param ctx the parse tree
	 */
	void exitDrop_trigger(PlSql2Parser.Drop_triggerContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#alter_trigger}.
	 * @param ctx the parse tree
	 */
	void enterAlter_trigger(PlSql2Parser.Alter_triggerContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#alter_trigger}.
	 * @param ctx the parse tree
	 */
	void exitAlter_trigger(PlSql2Parser.Alter_triggerContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#create_trigger}.
	 * @param ctx the parse tree
	 */
	void enterCreate_trigger(PlSql2Parser.Create_triggerContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#create_trigger}.
	 * @param ctx the parse tree
	 */
	void exitCreate_trigger(PlSql2Parser.Create_triggerContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#trigger_follows_clause}.
	 * @param ctx the parse tree
	 */
	void enterTrigger_follows_clause(PlSql2Parser.Trigger_follows_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#trigger_follows_clause}.
	 * @param ctx the parse tree
	 */
	void exitTrigger_follows_clause(PlSql2Parser.Trigger_follows_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#trigger_when_clause}.
	 * @param ctx the parse tree
	 */
	void enterTrigger_when_clause(PlSql2Parser.Trigger_when_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#trigger_when_clause}.
	 * @param ctx the parse tree
	 */
	void exitTrigger_when_clause(PlSql2Parser.Trigger_when_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#simple_dml_trigger}.
	 * @param ctx the parse tree
	 */
	void enterSimple_dml_trigger(PlSql2Parser.Simple_dml_triggerContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#simple_dml_trigger}.
	 * @param ctx the parse tree
	 */
	void exitSimple_dml_trigger(PlSql2Parser.Simple_dml_triggerContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#for_each_row}.
	 * @param ctx the parse tree
	 */
	void enterFor_each_row(PlSql2Parser.For_each_rowContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#for_each_row}.
	 * @param ctx the parse tree
	 */
	void exitFor_each_row(PlSql2Parser.For_each_rowContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#compound_dml_trigger}.
	 * @param ctx the parse tree
	 */
	void enterCompound_dml_trigger(PlSql2Parser.Compound_dml_triggerContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#compound_dml_trigger}.
	 * @param ctx the parse tree
	 */
	void exitCompound_dml_trigger(PlSql2Parser.Compound_dml_triggerContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#non_dml_trigger}.
	 * @param ctx the parse tree
	 */
	void enterNon_dml_trigger(PlSql2Parser.Non_dml_triggerContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#non_dml_trigger}.
	 * @param ctx the parse tree
	 */
	void exitNon_dml_trigger(PlSql2Parser.Non_dml_triggerContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#trigger_body}.
	 * @param ctx the parse tree
	 */
	void enterTrigger_body(PlSql2Parser.Trigger_bodyContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#trigger_body}.
	 * @param ctx the parse tree
	 */
	void exitTrigger_body(PlSql2Parser.Trigger_bodyContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#routine_clause}.
	 * @param ctx the parse tree
	 */
	void enterRoutine_clause(PlSql2Parser.Routine_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#routine_clause}.
	 * @param ctx the parse tree
	 */
	void exitRoutine_clause(PlSql2Parser.Routine_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#compound_trigger_block}.
	 * @param ctx the parse tree
	 */
	void enterCompound_trigger_block(PlSql2Parser.Compound_trigger_blockContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#compound_trigger_block}.
	 * @param ctx the parse tree
	 */
	void exitCompound_trigger_block(PlSql2Parser.Compound_trigger_blockContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#timing_point_section}.
	 * @param ctx the parse tree
	 */
	void enterTiming_point_section(PlSql2Parser.Timing_point_sectionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#timing_point_section}.
	 * @param ctx the parse tree
	 */
	void exitTiming_point_section(PlSql2Parser.Timing_point_sectionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#non_dml_event}.
	 * @param ctx the parse tree
	 */
	void enterNon_dml_event(PlSql2Parser.Non_dml_eventContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#non_dml_event}.
	 * @param ctx the parse tree
	 */
	void exitNon_dml_event(PlSql2Parser.Non_dml_eventContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#dml_event_clause}.
	 * @param ctx the parse tree
	 */
	void enterDml_event_clause(PlSql2Parser.Dml_event_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#dml_event_clause}.
	 * @param ctx the parse tree
	 */
	void exitDml_event_clause(PlSql2Parser.Dml_event_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#dml_event_element}.
	 * @param ctx the parse tree
	 */
	void enterDml_event_element(PlSql2Parser.Dml_event_elementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#dml_event_element}.
	 * @param ctx the parse tree
	 */
	void exitDml_event_element(PlSql2Parser.Dml_event_elementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#dml_event_nested_clause}.
	 * @param ctx the parse tree
	 */
	void enterDml_event_nested_clause(PlSql2Parser.Dml_event_nested_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#dml_event_nested_clause}.
	 * @param ctx the parse tree
	 */
	void exitDml_event_nested_clause(PlSql2Parser.Dml_event_nested_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#referencing_clause}.
	 * @param ctx the parse tree
	 */
	void enterReferencing_clause(PlSql2Parser.Referencing_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#referencing_clause}.
	 * @param ctx the parse tree
	 */
	void exitReferencing_clause(PlSql2Parser.Referencing_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#referencing_element}.
	 * @param ctx the parse tree
	 */
	void enterReferencing_element(PlSql2Parser.Referencing_elementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#referencing_element}.
	 * @param ctx the parse tree
	 */
	void exitReferencing_element(PlSql2Parser.Referencing_elementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#drop_type}.
	 * @param ctx the parse tree
	 */
	void enterDrop_type(PlSql2Parser.Drop_typeContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#drop_type}.
	 * @param ctx the parse tree
	 */
	void exitDrop_type(PlSql2Parser.Drop_typeContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#alter_type}.
	 * @param ctx the parse tree
	 */
	void enterAlter_type(PlSql2Parser.Alter_typeContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#alter_type}.
	 * @param ctx the parse tree
	 */
	void exitAlter_type(PlSql2Parser.Alter_typeContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#compile_type_clause}.
	 * @param ctx the parse tree
	 */
	void enterCompile_type_clause(PlSql2Parser.Compile_type_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#compile_type_clause}.
	 * @param ctx the parse tree
	 */
	void exitCompile_type_clause(PlSql2Parser.Compile_type_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#replace_type_clause}.
	 * @param ctx the parse tree
	 */
	void enterReplace_type_clause(PlSql2Parser.Replace_type_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#replace_type_clause}.
	 * @param ctx the parse tree
	 */
	void exitReplace_type_clause(PlSql2Parser.Replace_type_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#alter_method_spec}.
	 * @param ctx the parse tree
	 */
	void enterAlter_method_spec(PlSql2Parser.Alter_method_specContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#alter_method_spec}.
	 * @param ctx the parse tree
	 */
	void exitAlter_method_spec(PlSql2Parser.Alter_method_specContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#alter_method_element}.
	 * @param ctx the parse tree
	 */
	void enterAlter_method_element(PlSql2Parser.Alter_method_elementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#alter_method_element}.
	 * @param ctx the parse tree
	 */
	void exitAlter_method_element(PlSql2Parser.Alter_method_elementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#alter_attribute_definition}.
	 * @param ctx the parse tree
	 */
	void enterAlter_attribute_definition(PlSql2Parser.Alter_attribute_definitionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#alter_attribute_definition}.
	 * @param ctx the parse tree
	 */
	void exitAlter_attribute_definition(PlSql2Parser.Alter_attribute_definitionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#attribute_definition}.
	 * @param ctx the parse tree
	 */
	void enterAttribute_definition(PlSql2Parser.Attribute_definitionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#attribute_definition}.
	 * @param ctx the parse tree
	 */
	void exitAttribute_definition(PlSql2Parser.Attribute_definitionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#alter_collection_clauses}.
	 * @param ctx the parse tree
	 */
	void enterAlter_collection_clauses(PlSql2Parser.Alter_collection_clausesContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#alter_collection_clauses}.
	 * @param ctx the parse tree
	 */
	void exitAlter_collection_clauses(PlSql2Parser.Alter_collection_clausesContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#dependent_handling_clause}.
	 * @param ctx the parse tree
	 */
	void enterDependent_handling_clause(PlSql2Parser.Dependent_handling_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#dependent_handling_clause}.
	 * @param ctx the parse tree
	 */
	void exitDependent_handling_clause(PlSql2Parser.Dependent_handling_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#dependent_exceptions_part}.
	 * @param ctx the parse tree
	 */
	void enterDependent_exceptions_part(PlSql2Parser.Dependent_exceptions_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#dependent_exceptions_part}.
	 * @param ctx the parse tree
	 */
	void exitDependent_exceptions_part(PlSql2Parser.Dependent_exceptions_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#create_type}.
	 * @param ctx the parse tree
	 */
	void enterCreate_type(PlSql2Parser.Create_typeContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#create_type}.
	 * @param ctx the parse tree
	 */
	void exitCreate_type(PlSql2Parser.Create_typeContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#type_definition}.
	 * @param ctx the parse tree
	 */
	void enterType_definition(PlSql2Parser.Type_definitionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#type_definition}.
	 * @param ctx the parse tree
	 */
	void exitType_definition(PlSql2Parser.Type_definitionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#object_type_def}.
	 * @param ctx the parse tree
	 */
	void enterObject_type_def(PlSql2Parser.Object_type_defContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#object_type_def}.
	 * @param ctx the parse tree
	 */
	void exitObject_type_def(PlSql2Parser.Object_type_defContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#object_as_part}.
	 * @param ctx the parse tree
	 */
	void enterObject_as_part(PlSql2Parser.Object_as_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#object_as_part}.
	 * @param ctx the parse tree
	 */
	void exitObject_as_part(PlSql2Parser.Object_as_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#object_under_part}.
	 * @param ctx the parse tree
	 */
	void enterObject_under_part(PlSql2Parser.Object_under_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#object_under_part}.
	 * @param ctx the parse tree
	 */
	void exitObject_under_part(PlSql2Parser.Object_under_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#nested_table_type_def}.
	 * @param ctx the parse tree
	 */
	void enterNested_table_type_def(PlSql2Parser.Nested_table_type_defContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#nested_table_type_def}.
	 * @param ctx the parse tree
	 */
	void exitNested_table_type_def(PlSql2Parser.Nested_table_type_defContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#sqlj_object_type}.
	 * @param ctx the parse tree
	 */
	void enterSqlj_object_type(PlSql2Parser.Sqlj_object_typeContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#sqlj_object_type}.
	 * @param ctx the parse tree
	 */
	void exitSqlj_object_type(PlSql2Parser.Sqlj_object_typeContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#type_body}.
	 * @param ctx the parse tree
	 */
	void enterType_body(PlSql2Parser.Type_bodyContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#type_body}.
	 * @param ctx the parse tree
	 */
	void exitType_body(PlSql2Parser.Type_bodyContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#type_body_elements}.
	 * @param ctx the parse tree
	 */
	void enterType_body_elements(PlSql2Parser.Type_body_elementsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#type_body_elements}.
	 * @param ctx the parse tree
	 */
	void exitType_body_elements(PlSql2Parser.Type_body_elementsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#map_order_func_declaration}.
	 * @param ctx the parse tree
	 */
	void enterMap_order_func_declaration(PlSql2Parser.Map_order_func_declarationContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#map_order_func_declaration}.
	 * @param ctx the parse tree
	 */
	void exitMap_order_func_declaration(PlSql2Parser.Map_order_func_declarationContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#subprog_decl_in_type}.
	 * @param ctx the parse tree
	 */
	void enterSubprog_decl_in_type(PlSql2Parser.Subprog_decl_in_typeContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#subprog_decl_in_type}.
	 * @param ctx the parse tree
	 */
	void exitSubprog_decl_in_type(PlSql2Parser.Subprog_decl_in_typeContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#proc_decl_in_type}.
	 * @param ctx the parse tree
	 */
	void enterProc_decl_in_type(PlSql2Parser.Proc_decl_in_typeContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#proc_decl_in_type}.
	 * @param ctx the parse tree
	 */
	void exitProc_decl_in_type(PlSql2Parser.Proc_decl_in_typeContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#func_decl_in_type}.
	 * @param ctx the parse tree
	 */
	void enterFunc_decl_in_type(PlSql2Parser.Func_decl_in_typeContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#func_decl_in_type}.
	 * @param ctx the parse tree
	 */
	void exitFunc_decl_in_type(PlSql2Parser.Func_decl_in_typeContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#constructor_declaration}.
	 * @param ctx the parse tree
	 */
	void enterConstructor_declaration(PlSql2Parser.Constructor_declarationContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#constructor_declaration}.
	 * @param ctx the parse tree
	 */
	void exitConstructor_declaration(PlSql2Parser.Constructor_declarationContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#modifier_clause}.
	 * @param ctx the parse tree
	 */
	void enterModifier_clause(PlSql2Parser.Modifier_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#modifier_clause}.
	 * @param ctx the parse tree
	 */
	void exitModifier_clause(PlSql2Parser.Modifier_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#object_member_spec}.
	 * @param ctx the parse tree
	 */
	void enterObject_member_spec(PlSql2Parser.Object_member_specContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#object_member_spec}.
	 * @param ctx the parse tree
	 */
	void exitObject_member_spec(PlSql2Parser.Object_member_specContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#sqlj_object_type_attr}.
	 * @param ctx the parse tree
	 */
	void enterSqlj_object_type_attr(PlSql2Parser.Sqlj_object_type_attrContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#sqlj_object_type_attr}.
	 * @param ctx the parse tree
	 */
	void exitSqlj_object_type_attr(PlSql2Parser.Sqlj_object_type_attrContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#element_spec}.
	 * @param ctx the parse tree
	 */
	void enterElement_spec(PlSql2Parser.Element_specContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#element_spec}.
	 * @param ctx the parse tree
	 */
	void exitElement_spec(PlSql2Parser.Element_specContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#element_spec_options}.
	 * @param ctx the parse tree
	 */
	void enterElement_spec_options(PlSql2Parser.Element_spec_optionsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#element_spec_options}.
	 * @param ctx the parse tree
	 */
	void exitElement_spec_options(PlSql2Parser.Element_spec_optionsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#subprogram_spec}.
	 * @param ctx the parse tree
	 */
	void enterSubprogram_spec(PlSql2Parser.Subprogram_specContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#subprogram_spec}.
	 * @param ctx the parse tree
	 */
	void exitSubprogram_spec(PlSql2Parser.Subprogram_specContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#type_procedure_spec}.
	 * @param ctx the parse tree
	 */
	void enterType_procedure_spec(PlSql2Parser.Type_procedure_specContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#type_procedure_spec}.
	 * @param ctx the parse tree
	 */
	void exitType_procedure_spec(PlSql2Parser.Type_procedure_specContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#type_function_spec}.
	 * @param ctx the parse tree
	 */
	void enterType_function_spec(PlSql2Parser.Type_function_specContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#type_function_spec}.
	 * @param ctx the parse tree
	 */
	void exitType_function_spec(PlSql2Parser.Type_function_specContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#constructor_spec}.
	 * @param ctx the parse tree
	 */
	void enterConstructor_spec(PlSql2Parser.Constructor_specContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#constructor_spec}.
	 * @param ctx the parse tree
	 */
	void exitConstructor_spec(PlSql2Parser.Constructor_specContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#map_order_function_spec}.
	 * @param ctx the parse tree
	 */
	void enterMap_order_function_spec(PlSql2Parser.Map_order_function_specContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#map_order_function_spec}.
	 * @param ctx the parse tree
	 */
	void exitMap_order_function_spec(PlSql2Parser.Map_order_function_specContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#pragma_clause}.
	 * @param ctx the parse tree
	 */
	void enterPragma_clause(PlSql2Parser.Pragma_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#pragma_clause}.
	 * @param ctx the parse tree
	 */
	void exitPragma_clause(PlSql2Parser.Pragma_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#pragma_elements}.
	 * @param ctx the parse tree
	 */
	void enterPragma_elements(PlSql2Parser.Pragma_elementsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#pragma_elements}.
	 * @param ctx the parse tree
	 */
	void exitPragma_elements(PlSql2Parser.Pragma_elementsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#type_elements_parameter}.
	 * @param ctx the parse tree
	 */
	void enterType_elements_parameter(PlSql2Parser.Type_elements_parameterContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#type_elements_parameter}.
	 * @param ctx the parse tree
	 */
	void exitType_elements_parameter(PlSql2Parser.Type_elements_parameterContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#drop_sequence}.
	 * @param ctx the parse tree
	 */
	void enterDrop_sequence(PlSql2Parser.Drop_sequenceContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#drop_sequence}.
	 * @param ctx the parse tree
	 */
	void exitDrop_sequence(PlSql2Parser.Drop_sequenceContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#alter_sequence}.
	 * @param ctx the parse tree
	 */
	void enterAlter_sequence(PlSql2Parser.Alter_sequenceContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#alter_sequence}.
	 * @param ctx the parse tree
	 */
	void exitAlter_sequence(PlSql2Parser.Alter_sequenceContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#create_sequence}.
	 * @param ctx the parse tree
	 */
	void enterCreate_sequence(PlSql2Parser.Create_sequenceContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#create_sequence}.
	 * @param ctx the parse tree
	 */
	void exitCreate_sequence(PlSql2Parser.Create_sequenceContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#sequence_spec}.
	 * @param ctx the parse tree
	 */
	void enterSequence_spec(PlSql2Parser.Sequence_specContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#sequence_spec}.
	 * @param ctx the parse tree
	 */
	void exitSequence_spec(PlSql2Parser.Sequence_specContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#sequence_start_clause}.
	 * @param ctx the parse tree
	 */
	void enterSequence_start_clause(PlSql2Parser.Sequence_start_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#sequence_start_clause}.
	 * @param ctx the parse tree
	 */
	void exitSequence_start_clause(PlSql2Parser.Sequence_start_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#invoker_rights_clause}.
	 * @param ctx the parse tree
	 */
	void enterInvoker_rights_clause(PlSql2Parser.Invoker_rights_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#invoker_rights_clause}.
	 * @param ctx the parse tree
	 */
	void exitInvoker_rights_clause(PlSql2Parser.Invoker_rights_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#compiler_parameters_clause}.
	 * @param ctx the parse tree
	 */
	void enterCompiler_parameters_clause(PlSql2Parser.Compiler_parameters_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#compiler_parameters_clause}.
	 * @param ctx the parse tree
	 */
	void exitCompiler_parameters_clause(PlSql2Parser.Compiler_parameters_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#call_spec}.
	 * @param ctx the parse tree
	 */
	void enterCall_spec(PlSql2Parser.Call_specContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#call_spec}.
	 * @param ctx the parse tree
	 */
	void exitCall_spec(PlSql2Parser.Call_specContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#java_spec}.
	 * @param ctx the parse tree
	 */
	void enterJava_spec(PlSql2Parser.Java_specContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#java_spec}.
	 * @param ctx the parse tree
	 */
	void exitJava_spec(PlSql2Parser.Java_specContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#c_spec}.
	 * @param ctx the parse tree
	 */
	void enterC_spec(PlSql2Parser.C_specContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#c_spec}.
	 * @param ctx the parse tree
	 */
	void exitC_spec(PlSql2Parser.C_specContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#c_agent_in_clause}.
	 * @param ctx the parse tree
	 */
	void enterC_agent_in_clause(PlSql2Parser.C_agent_in_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#c_agent_in_clause}.
	 * @param ctx the parse tree
	 */
	void exitC_agent_in_clause(PlSql2Parser.C_agent_in_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#c_parameters_clause}.
	 * @param ctx the parse tree
	 */
	void enterC_parameters_clause(PlSql2Parser.C_parameters_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#c_parameters_clause}.
	 * @param ctx the parse tree
	 */
	void exitC_parameters_clause(PlSql2Parser.C_parameters_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#parameter}.
	 * @param ctx the parse tree
	 */
	void enterParameter(PlSql2Parser.ParameterContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#parameter}.
	 * @param ctx the parse tree
	 */
	void exitParameter(PlSql2Parser.ParameterContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#default_value_part}.
	 * @param ctx the parse tree
	 */
	void enterDefault_value_part(PlSql2Parser.Default_value_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#default_value_part}.
	 * @param ctx the parse tree
	 */
	void exitDefault_value_part(PlSql2Parser.Default_value_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#declare_spec}.
	 * @param ctx the parse tree
	 */
	void enterDeclare_spec(PlSql2Parser.Declare_specContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#declare_spec}.
	 * @param ctx the parse tree
	 */
	void exitDeclare_spec(PlSql2Parser.Declare_specContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#variable_declaration}.
	 * @param ctx the parse tree
	 */
	void enterVariable_declaration(PlSql2Parser.Variable_declarationContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#variable_declaration}.
	 * @param ctx the parse tree
	 */
	void exitVariable_declaration(PlSql2Parser.Variable_declarationContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#subtype_declaration}.
	 * @param ctx the parse tree
	 */
	void enterSubtype_declaration(PlSql2Parser.Subtype_declarationContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#subtype_declaration}.
	 * @param ctx the parse tree
	 */
	void exitSubtype_declaration(PlSql2Parser.Subtype_declarationContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#cursor_declaration}.
	 * @param ctx the parse tree
	 */
	void enterCursor_declaration(PlSql2Parser.Cursor_declarationContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#cursor_declaration}.
	 * @param ctx the parse tree
	 */
	void exitCursor_declaration(PlSql2Parser.Cursor_declarationContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#parameter_spec}.
	 * @param ctx the parse tree
	 */
	void enterParameter_spec(PlSql2Parser.Parameter_specContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#parameter_spec}.
	 * @param ctx the parse tree
	 */
	void exitParameter_spec(PlSql2Parser.Parameter_specContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#exception_declaration}.
	 * @param ctx the parse tree
	 */
	void enterException_declaration(PlSql2Parser.Exception_declarationContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#exception_declaration}.
	 * @param ctx the parse tree
	 */
	void exitException_declaration(PlSql2Parser.Exception_declarationContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#pragma_declaration}.
	 * @param ctx the parse tree
	 */
	void enterPragma_declaration(PlSql2Parser.Pragma_declarationContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#pragma_declaration}.
	 * @param ctx the parse tree
	 */
	void exitPragma_declaration(PlSql2Parser.Pragma_declarationContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#record_declaration}.
	 * @param ctx the parse tree
	 */
	void enterRecord_declaration(PlSql2Parser.Record_declarationContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#record_declaration}.
	 * @param ctx the parse tree
	 */
	void exitRecord_declaration(PlSql2Parser.Record_declarationContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#record_type_dec}.
	 * @param ctx the parse tree
	 */
	void enterRecord_type_dec(PlSql2Parser.Record_type_decContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#record_type_dec}.
	 * @param ctx the parse tree
	 */
	void exitRecord_type_dec(PlSql2Parser.Record_type_decContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#field_spec}.
	 * @param ctx the parse tree
	 */
	void enterField_spec(PlSql2Parser.Field_specContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#field_spec}.
	 * @param ctx the parse tree
	 */
	void exitField_spec(PlSql2Parser.Field_specContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#record_var_dec}.
	 * @param ctx the parse tree
	 */
	void enterRecord_var_dec(PlSql2Parser.Record_var_decContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#record_var_dec}.
	 * @param ctx the parse tree
	 */
	void exitRecord_var_dec(PlSql2Parser.Record_var_decContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#table_declaration}.
	 * @param ctx the parse tree
	 */
	void enterTable_declaration(PlSql2Parser.Table_declarationContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#table_declaration}.
	 * @param ctx the parse tree
	 */
	void exitTable_declaration(PlSql2Parser.Table_declarationContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#table_type_dec}.
	 * @param ctx the parse tree
	 */
	void enterTable_type_dec(PlSql2Parser.Table_type_decContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#table_type_dec}.
	 * @param ctx the parse tree
	 */
	void exitTable_type_dec(PlSql2Parser.Table_type_decContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#table_indexed_by_part}.
	 * @param ctx the parse tree
	 */
	void enterTable_indexed_by_part(PlSql2Parser.Table_indexed_by_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#table_indexed_by_part}.
	 * @param ctx the parse tree
	 */
	void exitTable_indexed_by_part(PlSql2Parser.Table_indexed_by_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#varray_type_def}.
	 * @param ctx the parse tree
	 */
	void enterVarray_type_def(PlSql2Parser.Varray_type_defContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#varray_type_def}.
	 * @param ctx the parse tree
	 */
	void exitVarray_type_def(PlSql2Parser.Varray_type_defContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#table_var_dec}.
	 * @param ctx the parse tree
	 */
	void enterTable_var_dec(PlSql2Parser.Table_var_decContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#table_var_dec}.
	 * @param ctx the parse tree
	 */
	void exitTable_var_dec(PlSql2Parser.Table_var_decContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#seq_of_statements}.
	 * @param ctx the parse tree
	 */
	void enterSeq_of_statements(PlSql2Parser.Seq_of_statementsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#seq_of_statements}.
	 * @param ctx the parse tree
	 */
	void exitSeq_of_statements(PlSql2Parser.Seq_of_statementsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#label_declaration}.
	 * @param ctx the parse tree
	 */
	void enterLabel_declaration(PlSql2Parser.Label_declarationContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#label_declaration}.
	 * @param ctx the parse tree
	 */
	void exitLabel_declaration(PlSql2Parser.Label_declarationContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#statement}.
	 * @param ctx the parse tree
	 */
	void enterStatement(PlSql2Parser.StatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#statement}.
	 * @param ctx the parse tree
	 */
	void exitStatement(PlSql2Parser.StatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#assignment_statement}.
	 * @param ctx the parse tree
	 */
	void enterAssignment_statement(PlSql2Parser.Assignment_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#assignment_statement}.
	 * @param ctx the parse tree
	 */
	void exitAssignment_statement(PlSql2Parser.Assignment_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#continue_statement}.
	 * @param ctx the parse tree
	 */
	void enterContinue_statement(PlSql2Parser.Continue_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#continue_statement}.
	 * @param ctx the parse tree
	 */
	void exitContinue_statement(PlSql2Parser.Continue_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#exit_statement}.
	 * @param ctx the parse tree
	 */
	void enterExit_statement(PlSql2Parser.Exit_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#exit_statement}.
	 * @param ctx the parse tree
	 */
	void exitExit_statement(PlSql2Parser.Exit_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#goto_statement}.
	 * @param ctx the parse tree
	 */
	void enterGoto_statement(PlSql2Parser.Goto_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#goto_statement}.
	 * @param ctx the parse tree
	 */
	void exitGoto_statement(PlSql2Parser.Goto_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#if_statement}.
	 * @param ctx the parse tree
	 */
	void enterIf_statement(PlSql2Parser.If_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#if_statement}.
	 * @param ctx the parse tree
	 */
	void exitIf_statement(PlSql2Parser.If_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#elsif_part}.
	 * @param ctx the parse tree
	 */
	void enterElsif_part(PlSql2Parser.Elsif_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#elsif_part}.
	 * @param ctx the parse tree
	 */
	void exitElsif_part(PlSql2Parser.Elsif_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#else_part}.
	 * @param ctx the parse tree
	 */
	void enterElse_part(PlSql2Parser.Else_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#else_part}.
	 * @param ctx the parse tree
	 */
	void exitElse_part(PlSql2Parser.Else_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#loop_statement}.
	 * @param ctx the parse tree
	 */
	void enterLoop_statement(PlSql2Parser.Loop_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#loop_statement}.
	 * @param ctx the parse tree
	 */
	void exitLoop_statement(PlSql2Parser.Loop_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#cursor_loop_param}.
	 * @param ctx the parse tree
	 */
	void enterCursor_loop_param(PlSql2Parser.Cursor_loop_paramContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#cursor_loop_param}.
	 * @param ctx the parse tree
	 */
	void exitCursor_loop_param(PlSql2Parser.Cursor_loop_paramContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#forall_statement}.
	 * @param ctx the parse tree
	 */
	void enterForall_statement(PlSql2Parser.Forall_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#forall_statement}.
	 * @param ctx the parse tree
	 */
	void exitForall_statement(PlSql2Parser.Forall_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#bounds_clause}.
	 * @param ctx the parse tree
	 */
	void enterBounds_clause(PlSql2Parser.Bounds_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#bounds_clause}.
	 * @param ctx the parse tree
	 */
	void exitBounds_clause(PlSql2Parser.Bounds_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#between_bound}.
	 * @param ctx the parse tree
	 */
	void enterBetween_bound(PlSql2Parser.Between_boundContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#between_bound}.
	 * @param ctx the parse tree
	 */
	void exitBetween_bound(PlSql2Parser.Between_boundContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#lower_bound}.
	 * @param ctx the parse tree
	 */
	void enterLower_bound(PlSql2Parser.Lower_boundContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#lower_bound}.
	 * @param ctx the parse tree
	 */
	void exitLower_bound(PlSql2Parser.Lower_boundContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#upper_bound}.
	 * @param ctx the parse tree
	 */
	void enterUpper_bound(PlSql2Parser.Upper_boundContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#upper_bound}.
	 * @param ctx the parse tree
	 */
	void exitUpper_bound(PlSql2Parser.Upper_boundContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#null_statement}.
	 * @param ctx the parse tree
	 */
	void enterNull_statement(PlSql2Parser.Null_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#null_statement}.
	 * @param ctx the parse tree
	 */
	void exitNull_statement(PlSql2Parser.Null_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#raise_statement}.
	 * @param ctx the parse tree
	 */
	void enterRaise_statement(PlSql2Parser.Raise_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#raise_statement}.
	 * @param ctx the parse tree
	 */
	void exitRaise_statement(PlSql2Parser.Raise_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#return_statement}.
	 * @param ctx the parse tree
	 */
	void enterReturn_statement(PlSql2Parser.Return_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#return_statement}.
	 * @param ctx the parse tree
	 */
	void exitReturn_statement(PlSql2Parser.Return_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#function_call}.
	 * @param ctx the parse tree
	 */
	void enterFunction_call(PlSql2Parser.Function_callContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#function_call}.
	 * @param ctx the parse tree
	 */
	void exitFunction_call(PlSql2Parser.Function_callContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#body}.
	 * @param ctx the parse tree
	 */
	void enterBody(PlSql2Parser.BodyContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#body}.
	 * @param ctx the parse tree
	 */
	void exitBody(PlSql2Parser.BodyContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#exception_handler}.
	 * @param ctx the parse tree
	 */
	void enterException_handler(PlSql2Parser.Exception_handlerContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#exception_handler}.
	 * @param ctx the parse tree
	 */
	void exitException_handler(PlSql2Parser.Exception_handlerContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#trigger_block}.
	 * @param ctx the parse tree
	 */
	void enterTrigger_block(PlSql2Parser.Trigger_blockContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#trigger_block}.
	 * @param ctx the parse tree
	 */
	void exitTrigger_block(PlSql2Parser.Trigger_blockContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#block}.
	 * @param ctx the parse tree
	 */
	void enterBlock(PlSql2Parser.BlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#block}.
	 * @param ctx the parse tree
	 */
	void exitBlock(PlSql2Parser.BlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#sql_statement}.
	 * @param ctx the parse tree
	 */
	void enterSql_statement(PlSql2Parser.Sql_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#sql_statement}.
	 * @param ctx the parse tree
	 */
	void exitSql_statement(PlSql2Parser.Sql_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#execute_immediate}.
	 * @param ctx the parse tree
	 */
	void enterExecute_immediate(PlSql2Parser.Execute_immediateContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#execute_immediate}.
	 * @param ctx the parse tree
	 */
	void exitExecute_immediate(PlSql2Parser.Execute_immediateContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#dynamic_returning_clause}.
	 * @param ctx the parse tree
	 */
	void enterDynamic_returning_clause(PlSql2Parser.Dynamic_returning_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#dynamic_returning_clause}.
	 * @param ctx the parse tree
	 */
	void exitDynamic_returning_clause(PlSql2Parser.Dynamic_returning_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#data_manipulation_language_statements}.
	 * @param ctx the parse tree
	 */
	void enterData_manipulation_language_statements(PlSql2Parser.Data_manipulation_language_statementsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#data_manipulation_language_statements}.
	 * @param ctx the parse tree
	 */
	void exitData_manipulation_language_statements(PlSql2Parser.Data_manipulation_language_statementsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#cursor_manipulation_statements}.
	 * @param ctx the parse tree
	 */
	void enterCursor_manipulation_statements(PlSql2Parser.Cursor_manipulation_statementsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#cursor_manipulation_statements}.
	 * @param ctx the parse tree
	 */
	void exitCursor_manipulation_statements(PlSql2Parser.Cursor_manipulation_statementsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#close_statement}.
	 * @param ctx the parse tree
	 */
	void enterClose_statement(PlSql2Parser.Close_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#close_statement}.
	 * @param ctx the parse tree
	 */
	void exitClose_statement(PlSql2Parser.Close_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#open_statement}.
	 * @param ctx the parse tree
	 */
	void enterOpen_statement(PlSql2Parser.Open_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#open_statement}.
	 * @param ctx the parse tree
	 */
	void exitOpen_statement(PlSql2Parser.Open_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#fetch_statement}.
	 * @param ctx the parse tree
	 */
	void enterFetch_statement(PlSql2Parser.Fetch_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#fetch_statement}.
	 * @param ctx the parse tree
	 */
	void exitFetch_statement(PlSql2Parser.Fetch_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#open_for_statement}.
	 * @param ctx the parse tree
	 */
	void enterOpen_for_statement(PlSql2Parser.Open_for_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#open_for_statement}.
	 * @param ctx the parse tree
	 */
	void exitOpen_for_statement(PlSql2Parser.Open_for_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#transaction_control_statements}.
	 * @param ctx the parse tree
	 */
	void enterTransaction_control_statements(PlSql2Parser.Transaction_control_statementsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#transaction_control_statements}.
	 * @param ctx the parse tree
	 */
	void exitTransaction_control_statements(PlSql2Parser.Transaction_control_statementsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#set_transaction_command}.
	 * @param ctx the parse tree
	 */
	void enterSet_transaction_command(PlSql2Parser.Set_transaction_commandContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#set_transaction_command}.
	 * @param ctx the parse tree
	 */
	void exitSet_transaction_command(PlSql2Parser.Set_transaction_commandContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#set_constraint_command}.
	 * @param ctx the parse tree
	 */
	void enterSet_constraint_command(PlSql2Parser.Set_constraint_commandContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#set_constraint_command}.
	 * @param ctx the parse tree
	 */
	void exitSet_constraint_command(PlSql2Parser.Set_constraint_commandContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#commit_statement}.
	 * @param ctx the parse tree
	 */
	void enterCommit_statement(PlSql2Parser.Commit_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#commit_statement}.
	 * @param ctx the parse tree
	 */
	void exitCommit_statement(PlSql2Parser.Commit_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#write_clause}.
	 * @param ctx the parse tree
	 */
	void enterWrite_clause(PlSql2Parser.Write_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#write_clause}.
	 * @param ctx the parse tree
	 */
	void exitWrite_clause(PlSql2Parser.Write_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#rollback_statement}.
	 * @param ctx the parse tree
	 */
	void enterRollback_statement(PlSql2Parser.Rollback_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#rollback_statement}.
	 * @param ctx the parse tree
	 */
	void exitRollback_statement(PlSql2Parser.Rollback_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#savepoint_statement}.
	 * @param ctx the parse tree
	 */
	void enterSavepoint_statement(PlSql2Parser.Savepoint_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#savepoint_statement}.
	 * @param ctx the parse tree
	 */
	void exitSavepoint_statement(PlSql2Parser.Savepoint_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#explain_statement}.
	 * @param ctx the parse tree
	 */
	void enterExplain_statement(PlSql2Parser.Explain_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#explain_statement}.
	 * @param ctx the parse tree
	 */
	void exitExplain_statement(PlSql2Parser.Explain_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#select_statement}.
	 * @param ctx the parse tree
	 */
	void enterSelect_statement(PlSql2Parser.Select_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#select_statement}.
	 * @param ctx the parse tree
	 */
	void exitSelect_statement(PlSql2Parser.Select_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#subquery_factoring_clause}.
	 * @param ctx the parse tree
	 */
	void enterSubquery_factoring_clause(PlSql2Parser.Subquery_factoring_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#subquery_factoring_clause}.
	 * @param ctx the parse tree
	 */
	void exitSubquery_factoring_clause(PlSql2Parser.Subquery_factoring_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#factoring_element}.
	 * @param ctx the parse tree
	 */
	void enterFactoring_element(PlSql2Parser.Factoring_elementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#factoring_element}.
	 * @param ctx the parse tree
	 */
	void exitFactoring_element(PlSql2Parser.Factoring_elementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#search_clause}.
	 * @param ctx the parse tree
	 */
	void enterSearch_clause(PlSql2Parser.Search_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#search_clause}.
	 * @param ctx the parse tree
	 */
	void exitSearch_clause(PlSql2Parser.Search_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#cycle_clause}.
	 * @param ctx the parse tree
	 */
	void enterCycle_clause(PlSql2Parser.Cycle_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#cycle_clause}.
	 * @param ctx the parse tree
	 */
	void exitCycle_clause(PlSql2Parser.Cycle_clauseContext ctx);
	/**
	 * Enter a parse tree produced by the {@code SubqueryParen}
	 * labeled alternative in {@link PlSql2Parser#subquery}.
	 * @param ctx the parse tree
	 */
	void enterSubqueryParen(PlSql2Parser.SubqueryParenContext ctx);
	/**
	 * Exit a parse tree produced by the {@code SubqueryParen}
	 * labeled alternative in {@link PlSql2Parser#subquery}.
	 * @param ctx the parse tree
	 */
	void exitSubqueryParen(PlSql2Parser.SubqueryParenContext ctx);
	/**
	 * Enter a parse tree produced by the {@code IgnoreSubquery}
	 * labeled alternative in {@link PlSql2Parser#subquery}.
	 * @param ctx the parse tree
	 */
	void enterIgnoreSubquery(PlSql2Parser.IgnoreSubqueryContext ctx);
	/**
	 * Exit a parse tree produced by the {@code IgnoreSubquery}
	 * labeled alternative in {@link PlSql2Parser#subquery}.
	 * @param ctx the parse tree
	 */
	void exitIgnoreSubquery(PlSql2Parser.IgnoreSubqueryContext ctx);
	/**
	 * Enter a parse tree produced by the {@code SubqueryCompound}
	 * labeled alternative in {@link PlSql2Parser#subquery}.
	 * @param ctx the parse tree
	 */
	void enterSubqueryCompound(PlSql2Parser.SubqueryCompoundContext ctx);
	/**
	 * Exit a parse tree produced by the {@code SubqueryCompound}
	 * labeled alternative in {@link PlSql2Parser#subquery}.
	 * @param ctx the parse tree
	 */
	void exitSubqueryCompound(PlSql2Parser.SubqueryCompoundContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#subquery_operation_part}.
	 * @param ctx the parse tree
	 */
	void enterSubquery_operation_part(PlSql2Parser.Subquery_operation_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#subquery_operation_part}.
	 * @param ctx the parse tree
	 */
	void exitSubquery_operation_part(PlSql2Parser.Subquery_operation_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#query_block}.
	 * @param ctx the parse tree
	 */
	void enterQuery_block(PlSql2Parser.Query_blockContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#query_block}.
	 * @param ctx the parse tree
	 */
	void exitQuery_block(PlSql2Parser.Query_blockContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Star1}
	 * labeled alternative in {@link PlSql2Parser#selected_element}.
	 * @param ctx the parse tree
	 */
	void enterStar1(PlSql2Parser.Star1Context ctx);
	/**
	 * Exit a parse tree produced by the {@code Star1}
	 * labeled alternative in {@link PlSql2Parser#selected_element}.
	 * @param ctx the parse tree
	 */
	void exitStar1(PlSql2Parser.Star1Context ctx);
	/**
	 * Enter a parse tree produced by the {@code StarTable}
	 * labeled alternative in {@link PlSql2Parser#selected_element}.
	 * @param ctx the parse tree
	 */
	void enterStarTable(PlSql2Parser.StarTableContext ctx);
	/**
	 * Exit a parse tree produced by the {@code StarTable}
	 * labeled alternative in {@link PlSql2Parser#selected_element}.
	 * @param ctx the parse tree
	 */
	void exitStarTable(PlSql2Parser.StarTableContext ctx);
	/**
	 * Enter a parse tree produced by the {@code IgnoreTableview_name}
	 * labeled alternative in {@link PlSql2Parser#selected_element}.
	 * @param ctx the parse tree
	 */
	void enterIgnoreTableview_name(PlSql2Parser.IgnoreTableview_nameContext ctx);
	/**
	 * Exit a parse tree produced by the {@code IgnoreTableview_name}
	 * labeled alternative in {@link PlSql2Parser#selected_element}.
	 * @param ctx the parse tree
	 */
	void exitIgnoreTableview_name(PlSql2Parser.IgnoreTableview_nameContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Alias_expr}
	 * labeled alternative in {@link PlSql2Parser#selected_element}.
	 * @param ctx the parse tree
	 */
	void enterAlias_expr(PlSql2Parser.Alias_exprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Alias_expr}
	 * labeled alternative in {@link PlSql2Parser#selected_element}.
	 * @param ctx the parse tree
	 */
	void exitAlias_expr(PlSql2Parser.Alias_exprContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#from_clause}.
	 * @param ctx the parse tree
	 */
	void enterFrom_clause(PlSql2Parser.From_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#from_clause}.
	 * @param ctx the parse tree
	 */
	void exitFrom_clause(PlSql2Parser.From_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#table_ref_pivot}.
	 * @param ctx the parse tree
	 */
	void enterTable_ref_pivot(PlSql2Parser.Table_ref_pivotContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#table_ref_pivot}.
	 * @param ctx the parse tree
	 */
	void exitTable_ref_pivot(PlSql2Parser.Table_ref_pivotContext ctx);
	/**
	 * Enter a parse tree produced by the {@code JoinExpr}
	 * labeled alternative in {@link PlSql2Parser#table_ref}.
	 * @param ctx the parse tree
	 */
	void enterJoinExpr(PlSql2Parser.JoinExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code JoinExpr}
	 * labeled alternative in {@link PlSql2Parser#table_ref}.
	 * @param ctx the parse tree
	 */
	void exitJoinExpr(PlSql2Parser.JoinExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code TableRefSimple}
	 * labeled alternative in {@link PlSql2Parser#table_ref}.
	 * @param ctx the parse tree
	 */
	void enterTableRefSimple(PlSql2Parser.TableRefSimpleContext ctx);
	/**
	 * Exit a parse tree produced by the {@code TableRefSimple}
	 * labeled alternative in {@link PlSql2Parser#table_ref}.
	 * @param ctx the parse tree
	 */
	void exitTableRefSimple(PlSql2Parser.TableRefSimpleContext ctx);
	/**
	 * Enter a parse tree produced by the {@code TableRefAux}
	 * labeled alternative in {@link PlSql2Parser#table_ref}.
	 * @param ctx the parse tree
	 */
	void enterTableRefAux(PlSql2Parser.TableRefAuxContext ctx);
	/**
	 * Exit a parse tree produced by the {@code TableRefAux}
	 * labeled alternative in {@link PlSql2Parser#table_ref}.
	 * @param ctx the parse tree
	 */
	void exitTableRefAux(PlSql2Parser.TableRefAuxContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#table_ref_aux}.
	 * @param ctx the parse tree
	 */
	void enterTable_ref_aux(PlSql2Parser.Table_ref_auxContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#table_ref_aux}.
	 * @param ctx the parse tree
	 */
	void exitTable_ref_aux(PlSql2Parser.Table_ref_auxContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#join_clause}.
	 * @param ctx the parse tree
	 */
	void enterJoin_clause(PlSql2Parser.Join_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#join_clause}.
	 * @param ctx the parse tree
	 */
	void exitJoin_clause(PlSql2Parser.Join_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#join_on_part}.
	 * @param ctx the parse tree
	 */
	void enterJoin_on_part(PlSql2Parser.Join_on_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#join_on_part}.
	 * @param ctx the parse tree
	 */
	void exitJoin_on_part(PlSql2Parser.Join_on_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#join_using_part}.
	 * @param ctx the parse tree
	 */
	void enterJoin_using_part(PlSql2Parser.Join_using_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#join_using_part}.
	 * @param ctx the parse tree
	 */
	void exitJoin_using_part(PlSql2Parser.Join_using_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#join_type}.
	 * @param ctx the parse tree
	 */
	void enterJoin_type(PlSql2Parser.Join_typeContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#join_type}.
	 * @param ctx the parse tree
	 */
	void exitJoin_type(PlSql2Parser.Join_typeContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#query_partition_clause}.
	 * @param ctx the parse tree
	 */
	void enterQuery_partition_clause(PlSql2Parser.Query_partition_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#query_partition_clause}.
	 * @param ctx the parse tree
	 */
	void exitQuery_partition_clause(PlSql2Parser.Query_partition_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#flashback_query_clause}.
	 * @param ctx the parse tree
	 */
	void enterFlashback_query_clause(PlSql2Parser.Flashback_query_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#flashback_query_clause}.
	 * @param ctx the parse tree
	 */
	void exitFlashback_query_clause(PlSql2Parser.Flashback_query_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#pivot_clause}.
	 * @param ctx the parse tree
	 */
	void enterPivot_clause(PlSql2Parser.Pivot_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#pivot_clause}.
	 * @param ctx the parse tree
	 */
	void exitPivot_clause(PlSql2Parser.Pivot_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#pivot_element}.
	 * @param ctx the parse tree
	 */
	void enterPivot_element(PlSql2Parser.Pivot_elementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#pivot_element}.
	 * @param ctx the parse tree
	 */
	void exitPivot_element(PlSql2Parser.Pivot_elementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#pivot_for_clause}.
	 * @param ctx the parse tree
	 */
	void enterPivot_for_clause(PlSql2Parser.Pivot_for_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#pivot_for_clause}.
	 * @param ctx the parse tree
	 */
	void exitPivot_for_clause(PlSql2Parser.Pivot_for_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#pivot_in_clause}.
	 * @param ctx the parse tree
	 */
	void enterPivot_in_clause(PlSql2Parser.Pivot_in_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#pivot_in_clause}.
	 * @param ctx the parse tree
	 */
	void exitPivot_in_clause(PlSql2Parser.Pivot_in_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#pivot_in_clause_element}.
	 * @param ctx the parse tree
	 */
	void enterPivot_in_clause_element(PlSql2Parser.Pivot_in_clause_elementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#pivot_in_clause_element}.
	 * @param ctx the parse tree
	 */
	void exitPivot_in_clause_element(PlSql2Parser.Pivot_in_clause_elementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#pivot_in_clause_elements}.
	 * @param ctx the parse tree
	 */
	void enterPivot_in_clause_elements(PlSql2Parser.Pivot_in_clause_elementsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#pivot_in_clause_elements}.
	 * @param ctx the parse tree
	 */
	void exitPivot_in_clause_elements(PlSql2Parser.Pivot_in_clause_elementsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#unpivot_clause}.
	 * @param ctx the parse tree
	 */
	void enterUnpivot_clause(PlSql2Parser.Unpivot_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#unpivot_clause}.
	 * @param ctx the parse tree
	 */
	void exitUnpivot_clause(PlSql2Parser.Unpivot_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#unpivot_in_clause}.
	 * @param ctx the parse tree
	 */
	void enterUnpivot_in_clause(PlSql2Parser.Unpivot_in_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#unpivot_in_clause}.
	 * @param ctx the parse tree
	 */
	void exitUnpivot_in_clause(PlSql2Parser.Unpivot_in_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#unpivot_in_elements}.
	 * @param ctx the parse tree
	 */
	void enterUnpivot_in_elements(PlSql2Parser.Unpivot_in_elementsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#unpivot_in_elements}.
	 * @param ctx the parse tree
	 */
	void exitUnpivot_in_elements(PlSql2Parser.Unpivot_in_elementsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#hierarchical_query_clause}.
	 * @param ctx the parse tree
	 */
	void enterHierarchical_query_clause(PlSql2Parser.Hierarchical_query_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#hierarchical_query_clause}.
	 * @param ctx the parse tree
	 */
	void exitHierarchical_query_clause(PlSql2Parser.Hierarchical_query_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#start_part}.
	 * @param ctx the parse tree
	 */
	void enterStart_part(PlSql2Parser.Start_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#start_part}.
	 * @param ctx the parse tree
	 */
	void exitStart_part(PlSql2Parser.Start_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#group_by_clause}.
	 * @param ctx the parse tree
	 */
	void enterGroup_by_clause(PlSql2Parser.Group_by_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#group_by_clause}.
	 * @param ctx the parse tree
	 */
	void exitGroup_by_clause(PlSql2Parser.Group_by_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#group_by_elements}.
	 * @param ctx the parse tree
	 */
	void enterGroup_by_elements(PlSql2Parser.Group_by_elementsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#group_by_elements}.
	 * @param ctx the parse tree
	 */
	void exitGroup_by_elements(PlSql2Parser.Group_by_elementsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#rollup_cube_clause}.
	 * @param ctx the parse tree
	 */
	void enterRollup_cube_clause(PlSql2Parser.Rollup_cube_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#rollup_cube_clause}.
	 * @param ctx the parse tree
	 */
	void exitRollup_cube_clause(PlSql2Parser.Rollup_cube_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#grouping_sets_clause}.
	 * @param ctx the parse tree
	 */
	void enterGrouping_sets_clause(PlSql2Parser.Grouping_sets_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#grouping_sets_clause}.
	 * @param ctx the parse tree
	 */
	void exitGrouping_sets_clause(PlSql2Parser.Grouping_sets_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#grouping_sets_elements}.
	 * @param ctx the parse tree
	 */
	void enterGrouping_sets_elements(PlSql2Parser.Grouping_sets_elementsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#grouping_sets_elements}.
	 * @param ctx the parse tree
	 */
	void exitGrouping_sets_elements(PlSql2Parser.Grouping_sets_elementsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#having_clause}.
	 * @param ctx the parse tree
	 */
	void enterHaving_clause(PlSql2Parser.Having_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#having_clause}.
	 * @param ctx the parse tree
	 */
	void exitHaving_clause(PlSql2Parser.Having_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#model_clause}.
	 * @param ctx the parse tree
	 */
	void enterModel_clause(PlSql2Parser.Model_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#model_clause}.
	 * @param ctx the parse tree
	 */
	void exitModel_clause(PlSql2Parser.Model_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#cell_reference_options}.
	 * @param ctx the parse tree
	 */
	void enterCell_reference_options(PlSql2Parser.Cell_reference_optionsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#cell_reference_options}.
	 * @param ctx the parse tree
	 */
	void exitCell_reference_options(PlSql2Parser.Cell_reference_optionsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#return_rows_clause}.
	 * @param ctx the parse tree
	 */
	void enterReturn_rows_clause(PlSql2Parser.Return_rows_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#return_rows_clause}.
	 * @param ctx the parse tree
	 */
	void exitReturn_rows_clause(PlSql2Parser.Return_rows_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#reference_model}.
	 * @param ctx the parse tree
	 */
	void enterReference_model(PlSql2Parser.Reference_modelContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#reference_model}.
	 * @param ctx the parse tree
	 */
	void exitReference_model(PlSql2Parser.Reference_modelContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#main_model}.
	 * @param ctx the parse tree
	 */
	void enterMain_model(PlSql2Parser.Main_modelContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#main_model}.
	 * @param ctx the parse tree
	 */
	void exitMain_model(PlSql2Parser.Main_modelContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#model_column_clauses}.
	 * @param ctx the parse tree
	 */
	void enterModel_column_clauses(PlSql2Parser.Model_column_clausesContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#model_column_clauses}.
	 * @param ctx the parse tree
	 */
	void exitModel_column_clauses(PlSql2Parser.Model_column_clausesContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#model_column_partition_part}.
	 * @param ctx the parse tree
	 */
	void enterModel_column_partition_part(PlSql2Parser.Model_column_partition_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#model_column_partition_part}.
	 * @param ctx the parse tree
	 */
	void exitModel_column_partition_part(PlSql2Parser.Model_column_partition_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#model_column_list}.
	 * @param ctx the parse tree
	 */
	void enterModel_column_list(PlSql2Parser.Model_column_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#model_column_list}.
	 * @param ctx the parse tree
	 */
	void exitModel_column_list(PlSql2Parser.Model_column_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#model_column}.
	 * @param ctx the parse tree
	 */
	void enterModel_column(PlSql2Parser.Model_columnContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#model_column}.
	 * @param ctx the parse tree
	 */
	void exitModel_column(PlSql2Parser.Model_columnContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#model_rules_clause}.
	 * @param ctx the parse tree
	 */
	void enterModel_rules_clause(PlSql2Parser.Model_rules_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#model_rules_clause}.
	 * @param ctx the parse tree
	 */
	void exitModel_rules_clause(PlSql2Parser.Model_rules_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#model_rules_part}.
	 * @param ctx the parse tree
	 */
	void enterModel_rules_part(PlSql2Parser.Model_rules_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#model_rules_part}.
	 * @param ctx the parse tree
	 */
	void exitModel_rules_part(PlSql2Parser.Model_rules_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#model_rules_element}.
	 * @param ctx the parse tree
	 */
	void enterModel_rules_element(PlSql2Parser.Model_rules_elementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#model_rules_element}.
	 * @param ctx the parse tree
	 */
	void exitModel_rules_element(PlSql2Parser.Model_rules_elementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#cell_assignment}.
	 * @param ctx the parse tree
	 */
	void enterCell_assignment(PlSql2Parser.Cell_assignmentContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#cell_assignment}.
	 * @param ctx the parse tree
	 */
	void exitCell_assignment(PlSql2Parser.Cell_assignmentContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#model_iterate_clause}.
	 * @param ctx the parse tree
	 */
	void enterModel_iterate_clause(PlSql2Parser.Model_iterate_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#model_iterate_clause}.
	 * @param ctx the parse tree
	 */
	void exitModel_iterate_clause(PlSql2Parser.Model_iterate_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#until_part}.
	 * @param ctx the parse tree
	 */
	void enterUntil_part(PlSql2Parser.Until_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#until_part}.
	 * @param ctx the parse tree
	 */
	void exitUntil_part(PlSql2Parser.Until_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#order_by_clause}.
	 * @param ctx the parse tree
	 */
	void enterOrder_by_clause(PlSql2Parser.Order_by_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#order_by_clause}.
	 * @param ctx the parse tree
	 */
	void exitOrder_by_clause(PlSql2Parser.Order_by_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#order_by_elements}.
	 * @param ctx the parse tree
	 */
	void enterOrder_by_elements(PlSql2Parser.Order_by_elementsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#order_by_elements}.
	 * @param ctx the parse tree
	 */
	void exitOrder_by_elements(PlSql2Parser.Order_by_elementsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#for_update_clause}.
	 * @param ctx the parse tree
	 */
	void enterFor_update_clause(PlSql2Parser.For_update_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#for_update_clause}.
	 * @param ctx the parse tree
	 */
	void exitFor_update_clause(PlSql2Parser.For_update_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#for_update_of_part}.
	 * @param ctx the parse tree
	 */
	void enterFor_update_of_part(PlSql2Parser.For_update_of_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#for_update_of_part}.
	 * @param ctx the parse tree
	 */
	void exitFor_update_of_part(PlSql2Parser.For_update_of_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#for_update_options}.
	 * @param ctx the parse tree
	 */
	void enterFor_update_options(PlSql2Parser.For_update_optionsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#for_update_options}.
	 * @param ctx the parse tree
	 */
	void exitFor_update_options(PlSql2Parser.For_update_optionsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#limit_clause}.
	 * @param ctx the parse tree
	 */
	void enterLimit_clause(PlSql2Parser.Limit_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#limit_clause}.
	 * @param ctx the parse tree
	 */
	void exitLimit_clause(PlSql2Parser.Limit_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#update_statement}.
	 * @param ctx the parse tree
	 */
	void enterUpdate_statement(PlSql2Parser.Update_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#update_statement}.
	 * @param ctx the parse tree
	 */
	void exitUpdate_statement(PlSql2Parser.Update_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#update_set_clause}.
	 * @param ctx the parse tree
	 */
	void enterUpdate_set_clause(PlSql2Parser.Update_set_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#update_set_clause}.
	 * @param ctx the parse tree
	 */
	void exitUpdate_set_clause(PlSql2Parser.Update_set_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#column_based_update_set_clause}.
	 * @param ctx the parse tree
	 */
	void enterColumn_based_update_set_clause(PlSql2Parser.Column_based_update_set_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#column_based_update_set_clause}.
	 * @param ctx the parse tree
	 */
	void exitColumn_based_update_set_clause(PlSql2Parser.Column_based_update_set_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#delete_statement}.
	 * @param ctx the parse tree
	 */
	void enterDelete_statement(PlSql2Parser.Delete_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#delete_statement}.
	 * @param ctx the parse tree
	 */
	void exitDelete_statement(PlSql2Parser.Delete_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#insert_statement}.
	 * @param ctx the parse tree
	 */
	void enterInsert_statement(PlSql2Parser.Insert_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#insert_statement}.
	 * @param ctx the parse tree
	 */
	void exitInsert_statement(PlSql2Parser.Insert_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#single_table_insert}.
	 * @param ctx the parse tree
	 */
	void enterSingle_table_insert(PlSql2Parser.Single_table_insertContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#single_table_insert}.
	 * @param ctx the parse tree
	 */
	void exitSingle_table_insert(PlSql2Parser.Single_table_insertContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#multi_table_insert}.
	 * @param ctx the parse tree
	 */
	void enterMulti_table_insert(PlSql2Parser.Multi_table_insertContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#multi_table_insert}.
	 * @param ctx the parse tree
	 */
	void exitMulti_table_insert(PlSql2Parser.Multi_table_insertContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#multi_table_element}.
	 * @param ctx the parse tree
	 */
	void enterMulti_table_element(PlSql2Parser.Multi_table_elementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#multi_table_element}.
	 * @param ctx the parse tree
	 */
	void exitMulti_table_element(PlSql2Parser.Multi_table_elementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#conditional_insert_clause}.
	 * @param ctx the parse tree
	 */
	void enterConditional_insert_clause(PlSql2Parser.Conditional_insert_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#conditional_insert_clause}.
	 * @param ctx the parse tree
	 */
	void exitConditional_insert_clause(PlSql2Parser.Conditional_insert_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#conditional_insert_when_part}.
	 * @param ctx the parse tree
	 */
	void enterConditional_insert_when_part(PlSql2Parser.Conditional_insert_when_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#conditional_insert_when_part}.
	 * @param ctx the parse tree
	 */
	void exitConditional_insert_when_part(PlSql2Parser.Conditional_insert_when_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#conditional_insert_else_part}.
	 * @param ctx the parse tree
	 */
	void enterConditional_insert_else_part(PlSql2Parser.Conditional_insert_else_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#conditional_insert_else_part}.
	 * @param ctx the parse tree
	 */
	void exitConditional_insert_else_part(PlSql2Parser.Conditional_insert_else_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#insert_into_clause}.
	 * @param ctx the parse tree
	 */
	void enterInsert_into_clause(PlSql2Parser.Insert_into_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#insert_into_clause}.
	 * @param ctx the parse tree
	 */
	void exitInsert_into_clause(PlSql2Parser.Insert_into_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#values_clause}.
	 * @param ctx the parse tree
	 */
	void enterValues_clause(PlSql2Parser.Values_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#values_clause}.
	 * @param ctx the parse tree
	 */
	void exitValues_clause(PlSql2Parser.Values_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#merge_statement}.
	 * @param ctx the parse tree
	 */
	void enterMerge_statement(PlSql2Parser.Merge_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#merge_statement}.
	 * @param ctx the parse tree
	 */
	void exitMerge_statement(PlSql2Parser.Merge_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#merge_update_clause}.
	 * @param ctx the parse tree
	 */
	void enterMerge_update_clause(PlSql2Parser.Merge_update_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#merge_update_clause}.
	 * @param ctx the parse tree
	 */
	void exitMerge_update_clause(PlSql2Parser.Merge_update_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#merge_element}.
	 * @param ctx the parse tree
	 */
	void enterMerge_element(PlSql2Parser.Merge_elementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#merge_element}.
	 * @param ctx the parse tree
	 */
	void exitMerge_element(PlSql2Parser.Merge_elementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#merge_update_delete_part}.
	 * @param ctx the parse tree
	 */
	void enterMerge_update_delete_part(PlSql2Parser.Merge_update_delete_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#merge_update_delete_part}.
	 * @param ctx the parse tree
	 */
	void exitMerge_update_delete_part(PlSql2Parser.Merge_update_delete_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#merge_insert_clause}.
	 * @param ctx the parse tree
	 */
	void enterMerge_insert_clause(PlSql2Parser.Merge_insert_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#merge_insert_clause}.
	 * @param ctx the parse tree
	 */
	void exitMerge_insert_clause(PlSql2Parser.Merge_insert_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#selected_tableview}.
	 * @param ctx the parse tree
	 */
	void enterSelected_tableview(PlSql2Parser.Selected_tableviewContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#selected_tableview}.
	 * @param ctx the parse tree
	 */
	void exitSelected_tableview(PlSql2Parser.Selected_tableviewContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#lock_table_statement}.
	 * @param ctx the parse tree
	 */
	void enterLock_table_statement(PlSql2Parser.Lock_table_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#lock_table_statement}.
	 * @param ctx the parse tree
	 */
	void exitLock_table_statement(PlSql2Parser.Lock_table_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#wait_nowait_part}.
	 * @param ctx the parse tree
	 */
	void enterWait_nowait_part(PlSql2Parser.Wait_nowait_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#wait_nowait_part}.
	 * @param ctx the parse tree
	 */
	void exitWait_nowait_part(PlSql2Parser.Wait_nowait_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#lock_table_element}.
	 * @param ctx the parse tree
	 */
	void enterLock_table_element(PlSql2Parser.Lock_table_elementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#lock_table_element}.
	 * @param ctx the parse tree
	 */
	void exitLock_table_element(PlSql2Parser.Lock_table_elementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#lock_mode}.
	 * @param ctx the parse tree
	 */
	void enterLock_mode(PlSql2Parser.Lock_modeContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#lock_mode}.
	 * @param ctx the parse tree
	 */
	void exitLock_mode(PlSql2Parser.Lock_modeContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#general_table_ref}.
	 * @param ctx the parse tree
	 */
	void enterGeneral_table_ref(PlSql2Parser.General_table_refContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#general_table_ref}.
	 * @param ctx the parse tree
	 */
	void exitGeneral_table_ref(PlSql2Parser.General_table_refContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#static_returning_clause}.
	 * @param ctx the parse tree
	 */
	void enterStatic_returning_clause(PlSql2Parser.Static_returning_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#static_returning_clause}.
	 * @param ctx the parse tree
	 */
	void exitStatic_returning_clause(PlSql2Parser.Static_returning_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#error_logging_clause}.
	 * @param ctx the parse tree
	 */
	void enterError_logging_clause(PlSql2Parser.Error_logging_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#error_logging_clause}.
	 * @param ctx the parse tree
	 */
	void exitError_logging_clause(PlSql2Parser.Error_logging_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#error_logging_into_part}.
	 * @param ctx the parse tree
	 */
	void enterError_logging_into_part(PlSql2Parser.Error_logging_into_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#error_logging_into_part}.
	 * @param ctx the parse tree
	 */
	void exitError_logging_into_part(PlSql2Parser.Error_logging_into_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#error_logging_reject_part}.
	 * @param ctx the parse tree
	 */
	void enterError_logging_reject_part(PlSql2Parser.Error_logging_reject_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#error_logging_reject_part}.
	 * @param ctx the parse tree
	 */
	void exitError_logging_reject_part(PlSql2Parser.Error_logging_reject_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#dml_table_expression_clause}.
	 * @param ctx the parse tree
	 */
	void enterDml_table_expression_clause(PlSql2Parser.Dml_table_expression_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#dml_table_expression_clause}.
	 * @param ctx the parse tree
	 */
	void exitDml_table_expression_clause(PlSql2Parser.Dml_table_expression_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#table_collection_expression}.
	 * @param ctx the parse tree
	 */
	void enterTable_collection_expression(PlSql2Parser.Table_collection_expressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#table_collection_expression}.
	 * @param ctx the parse tree
	 */
	void exitTable_collection_expression(PlSql2Parser.Table_collection_expressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#subquery_restriction_clause}.
	 * @param ctx the parse tree
	 */
	void enterSubquery_restriction_clause(PlSql2Parser.Subquery_restriction_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#subquery_restriction_clause}.
	 * @param ctx the parse tree
	 */
	void exitSubquery_restriction_clause(PlSql2Parser.Subquery_restriction_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#sample_clause}.
	 * @param ctx the parse tree
	 */
	void enterSample_clause(PlSql2Parser.Sample_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#sample_clause}.
	 * @param ctx the parse tree
	 */
	void exitSample_clause(PlSql2Parser.Sample_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#seed_part}.
	 * @param ctx the parse tree
	 */
	void enterSeed_part(PlSql2Parser.Seed_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#seed_part}.
	 * @param ctx the parse tree
	 */
	void exitSeed_part(PlSql2Parser.Seed_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#cursor_expression}.
	 * @param ctx the parse tree
	 */
	void enterCursor_expression(PlSql2Parser.Cursor_expressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#cursor_expression}.
	 * @param ctx the parse tree
	 */
	void exitCursor_expression(PlSql2Parser.Cursor_expressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#expression_list}.
	 * @param ctx the parse tree
	 */
	void enterExpression_list(PlSql2Parser.Expression_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#expression_list}.
	 * @param ctx the parse tree
	 */
	void exitExpression_list(PlSql2Parser.Expression_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#condition}.
	 * @param ctx the parse tree
	 */
	void enterCondition(PlSql2Parser.ConditionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#condition}.
	 * @param ctx the parse tree
	 */
	void exitCondition(PlSql2Parser.ConditionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code IgnoreExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 */
	void enterIgnoreExpr(PlSql2Parser.IgnoreExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code IgnoreExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 */
	void exitIgnoreExpr(PlSql2Parser.IgnoreExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code AndExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 */
	void enterAndExpr(PlSql2Parser.AndExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code AndExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 */
	void exitAndExpr(PlSql2Parser.AndExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code LikeExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 */
	void enterLikeExpr(PlSql2Parser.LikeExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code LikeExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 */
	void exitLikeExpr(PlSql2Parser.LikeExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code RelExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 */
	void enterRelExpr(PlSql2Parser.RelExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code RelExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 */
	void exitRelExpr(PlSql2Parser.RelExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code MemberExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 */
	void enterMemberExpr(PlSql2Parser.MemberExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code MemberExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 */
	void exitMemberExpr(PlSql2Parser.MemberExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code BetweenExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 */
	void enterBetweenExpr(PlSql2Parser.BetweenExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code BetweenExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 */
	void exitBetweenExpr(PlSql2Parser.BetweenExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code CursorExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 */
	void enterCursorExpr(PlSql2Parser.CursorExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code CursorExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 */
	void exitCursorExpr(PlSql2Parser.CursorExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code IsExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 */
	void enterIsExpr(PlSql2Parser.IsExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code IsExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 */
	void exitIsExpr(PlSql2Parser.IsExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code NotExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 */
	void enterNotExpr(PlSql2Parser.NotExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code NotExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 */
	void exitNotExpr(PlSql2Parser.NotExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code InExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 */
	void enterInExpr(PlSql2Parser.InExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code InExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 */
	void exitInExpr(PlSql2Parser.InExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ParenExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 */
	void enterParenExpr(PlSql2Parser.ParenExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ParenExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 */
	void exitParenExpr(PlSql2Parser.ParenExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code OrExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 */
	void enterOrExpr(PlSql2Parser.OrExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code OrExpr}
	 * labeled alternative in {@link PlSql2Parser#expression}.
	 * @param ctx the parse tree
	 */
	void exitOrExpr(PlSql2Parser.OrExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#is_part}.
	 * @param ctx the parse tree
	 */
	void enterIs_part(PlSql2Parser.Is_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#is_part}.
	 * @param ctx the parse tree
	 */
	void exitIs_part(PlSql2Parser.Is_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#cursor_part}.
	 * @param ctx the parse tree
	 */
	void enterCursor_part(PlSql2Parser.Cursor_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#cursor_part}.
	 * @param ctx the parse tree
	 */
	void exitCursor_part(PlSql2Parser.Cursor_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#multiset_type}.
	 * @param ctx the parse tree
	 */
	void enterMultiset_type(PlSql2Parser.Multiset_typeContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#multiset_type}.
	 * @param ctx the parse tree
	 */
	void exitMultiset_type(PlSql2Parser.Multiset_typeContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#relational_operator}.
	 * @param ctx the parse tree
	 */
	void enterRelational_operator(PlSql2Parser.Relational_operatorContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#relational_operator}.
	 * @param ctx the parse tree
	 */
	void exitRelational_operator(PlSql2Parser.Relational_operatorContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#like_type}.
	 * @param ctx the parse tree
	 */
	void enterLike_type(PlSql2Parser.Like_typeContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#like_type}.
	 * @param ctx the parse tree
	 */
	void exitLike_type(PlSql2Parser.Like_typeContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#like_escape_part}.
	 * @param ctx the parse tree
	 */
	void enterLike_escape_part(PlSql2Parser.Like_escape_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#like_escape_part}.
	 * @param ctx the parse tree
	 */
	void exitLike_escape_part(PlSql2Parser.Like_escape_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#between_elements}.
	 * @param ctx the parse tree
	 */
	void enterBetween_elements(PlSql2Parser.Between_elementsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#between_elements}.
	 * @param ctx the parse tree
	 */
	void exitBetween_elements(PlSql2Parser.Between_elementsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#concatenation}.
	 * @param ctx the parse tree
	 */
	void enterConcatenation(PlSql2Parser.ConcatenationContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#concatenation}.
	 * @param ctx the parse tree
	 */
	void exitConcatenation(PlSql2Parser.ConcatenationContext ctx);
	/**
	 * Enter a parse tree produced by the {@code BinaryExpr}
	 * labeled alternative in {@link PlSql2Parser#binary_expression}.
	 * @param ctx the parse tree
	 */
	void enterBinaryExpr(PlSql2Parser.BinaryExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code BinaryExpr}
	 * labeled alternative in {@link PlSql2Parser#binary_expression}.
	 * @param ctx the parse tree
	 */
	void exitBinaryExpr(PlSql2Parser.BinaryExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code IgnoreBinaryExpr}
	 * labeled alternative in {@link PlSql2Parser#binary_expression}.
	 * @param ctx the parse tree
	 */
	void enterIgnoreBinaryExpr(PlSql2Parser.IgnoreBinaryExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code IgnoreBinaryExpr}
	 * labeled alternative in {@link PlSql2Parser#binary_expression}.
	 * @param ctx the parse tree
	 */
	void exitIgnoreBinaryExpr(PlSql2Parser.IgnoreBinaryExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ParenBinaryExpr}
	 * labeled alternative in {@link PlSql2Parser#binary_expression}.
	 * @param ctx the parse tree
	 */
	void enterParenBinaryExpr(PlSql2Parser.ParenBinaryExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ParenBinaryExpr}
	 * labeled alternative in {@link PlSql2Parser#binary_expression}.
	 * @param ctx the parse tree
	 */
	void exitParenBinaryExpr(PlSql2Parser.ParenBinaryExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#interval_expression}.
	 * @param ctx the parse tree
	 */
	void enterInterval_expression(PlSql2Parser.Interval_expressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#interval_expression}.
	 * @param ctx the parse tree
	 */
	void exitInterval_expression(PlSql2Parser.Interval_expressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#model_expression}.
	 * @param ctx the parse tree
	 */
	void enterModel_expression(PlSql2Parser.Model_expressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#model_expression}.
	 * @param ctx the parse tree
	 */
	void exitModel_expression(PlSql2Parser.Model_expressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#model_expression_element}.
	 * @param ctx the parse tree
	 */
	void enterModel_expression_element(PlSql2Parser.Model_expression_elementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#model_expression_element}.
	 * @param ctx the parse tree
	 */
	void exitModel_expression_element(PlSql2Parser.Model_expression_elementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#single_column_for_loop}.
	 * @param ctx the parse tree
	 */
	void enterSingle_column_for_loop(PlSql2Parser.Single_column_for_loopContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#single_column_for_loop}.
	 * @param ctx the parse tree
	 */
	void exitSingle_column_for_loop(PlSql2Parser.Single_column_for_loopContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#for_like_part}.
	 * @param ctx the parse tree
	 */
	void enterFor_like_part(PlSql2Parser.For_like_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#for_like_part}.
	 * @param ctx the parse tree
	 */
	void exitFor_like_part(PlSql2Parser.For_like_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#for_increment_decrement_type}.
	 * @param ctx the parse tree
	 */
	void enterFor_increment_decrement_type(PlSql2Parser.For_increment_decrement_typeContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#for_increment_decrement_type}.
	 * @param ctx the parse tree
	 */
	void exitFor_increment_decrement_type(PlSql2Parser.For_increment_decrement_typeContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#multi_column_for_loop}.
	 * @param ctx the parse tree
	 */
	void enterMulti_column_for_loop(PlSql2Parser.Multi_column_for_loopContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#multi_column_for_loop}.
	 * @param ctx the parse tree
	 */
	void exitMulti_column_for_loop(PlSql2Parser.Multi_column_for_loopContext ctx);
	/**
	 * Enter a parse tree produced by the {@code IgnoreUnaryExpr}
	 * labeled alternative in {@link PlSql2Parser#unary_expression}.
	 * @param ctx the parse tree
	 */
	void enterIgnoreUnaryExpr(PlSql2Parser.IgnoreUnaryExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code IgnoreUnaryExpr}
	 * labeled alternative in {@link PlSql2Parser#unary_expression}.
	 * @param ctx the parse tree
	 */
	void exitIgnoreUnaryExpr(PlSql2Parser.IgnoreUnaryExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code UnaryExpr}
	 * labeled alternative in {@link PlSql2Parser#unary_expression}.
	 * @param ctx the parse tree
	 */
	void enterUnaryExpr(PlSql2Parser.UnaryExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code UnaryExpr}
	 * labeled alternative in {@link PlSql2Parser#unary_expression}.
	 * @param ctx the parse tree
	 */
	void exitUnaryExpr(PlSql2Parser.UnaryExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#case_statement}.
	 * @param ctx the parse tree
	 */
	void enterCase_statement(PlSql2Parser.Case_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#case_statement}.
	 * @param ctx the parse tree
	 */
	void exitCase_statement(PlSql2Parser.Case_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#simple_case_statement}.
	 * @param ctx the parse tree
	 */
	void enterSimple_case_statement(PlSql2Parser.Simple_case_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#simple_case_statement}.
	 * @param ctx the parse tree
	 */
	void exitSimple_case_statement(PlSql2Parser.Simple_case_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#simple_case_when_part}.
	 * @param ctx the parse tree
	 */
	void enterSimple_case_when_part(PlSql2Parser.Simple_case_when_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#simple_case_when_part}.
	 * @param ctx the parse tree
	 */
	void exitSimple_case_when_part(PlSql2Parser.Simple_case_when_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#searched_case_statement}.
	 * @param ctx the parse tree
	 */
	void enterSearched_case_statement(PlSql2Parser.Searched_case_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#searched_case_statement}.
	 * @param ctx the parse tree
	 */
	void exitSearched_case_statement(PlSql2Parser.Searched_case_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#searched_case_when_part}.
	 * @param ctx the parse tree
	 */
	void enterSearched_case_when_part(PlSql2Parser.Searched_case_when_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#searched_case_when_part}.
	 * @param ctx the parse tree
	 */
	void exitSearched_case_when_part(PlSql2Parser.Searched_case_when_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#case_else_part}.
	 * @param ctx the parse tree
	 */
	void enterCase_else_part(PlSql2Parser.Case_else_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#case_else_part}.
	 * @param ctx the parse tree
	 */
	void exitCase_else_part(PlSql2Parser.Case_else_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#atom}.
	 * @param ctx the parse tree
	 */
	void enterAtom(PlSql2Parser.AtomContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#atom}.
	 * @param ctx the parse tree
	 */
	void exitAtom(PlSql2Parser.AtomContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#expression_or_vector}.
	 * @param ctx the parse tree
	 */
	void enterExpression_or_vector(PlSql2Parser.Expression_or_vectorContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#expression_or_vector}.
	 * @param ctx the parse tree
	 */
	void exitExpression_or_vector(PlSql2Parser.Expression_or_vectorContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#vector_expr}.
	 * @param ctx the parse tree
	 */
	void enterVector_expr(PlSql2Parser.Vector_exprContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#vector_expr}.
	 * @param ctx the parse tree
	 */
	void exitVector_expr(PlSql2Parser.Vector_exprContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#quantified_expression}.
	 * @param ctx the parse tree
	 */
	void enterQuantified_expression(PlSql2Parser.Quantified_expressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#quantified_expression}.
	 * @param ctx the parse tree
	 */
	void exitQuantified_expression(PlSql2Parser.Quantified_expressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code AggregateCall}
	 * labeled alternative in {@link PlSql2Parser#standard_function}.
	 * @param ctx the parse tree
	 */
	void enterAggregateCall(PlSql2Parser.AggregateCallContext ctx);
	/**
	 * Exit a parse tree produced by the {@code AggregateCall}
	 * labeled alternative in {@link PlSql2Parser#standard_function}.
	 * @param ctx the parse tree
	 */
	void exitAggregateCall(PlSql2Parser.AggregateCallContext ctx);
	/**
	 * Enter a parse tree produced by the {@code TodoCall}
	 * labeled alternative in {@link PlSql2Parser#standard_function}.
	 * @param ctx the parse tree
	 */
	void enterTodoCall(PlSql2Parser.TodoCallContext ctx);
	/**
	 * Exit a parse tree produced by the {@code TodoCall}
	 * labeled alternative in {@link PlSql2Parser#standard_function}.
	 * @param ctx the parse tree
	 */
	void exitTodoCall(PlSql2Parser.TodoCallContext ctx);
	/**
	 * Enter a parse tree produced by the {@code XmlCall}
	 * labeled alternative in {@link PlSql2Parser#standard_function}.
	 * @param ctx the parse tree
	 */
	void enterXmlCall(PlSql2Parser.XmlCallContext ctx);
	/**
	 * Exit a parse tree produced by the {@code XmlCall}
	 * labeled alternative in {@link PlSql2Parser#standard_function}.
	 * @param ctx the parse tree
	 */
	void exitXmlCall(PlSql2Parser.XmlCallContext ctx);
	/**
	 * Enter a parse tree produced by the {@code CastCall}
	 * labeled alternative in {@link PlSql2Parser#standard_function}.
	 * @param ctx the parse tree
	 */
	void enterCastCall(PlSql2Parser.CastCallContext ctx);
	/**
	 * Exit a parse tree produced by the {@code CastCall}
	 * labeled alternative in {@link PlSql2Parser#standard_function}.
	 * @param ctx the parse tree
	 */
	void exitCastCall(PlSql2Parser.CastCallContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ExtractCall}
	 * labeled alternative in {@link PlSql2Parser#standard_function}.
	 * @param ctx the parse tree
	 */
	void enterExtractCall(PlSql2Parser.ExtractCallContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ExtractCall}
	 * labeled alternative in {@link PlSql2Parser#standard_function}.
	 * @param ctx the parse tree
	 */
	void exitExtractCall(PlSql2Parser.ExtractCallContext ctx);
	/**
	 * Enter a parse tree produced by the {@code WithinOrOverCall}
	 * labeled alternative in {@link PlSql2Parser#standard_function}.
	 * @param ctx the parse tree
	 */
	void enterWithinOrOverCall(PlSql2Parser.WithinOrOverCallContext ctx);
	/**
	 * Exit a parse tree produced by the {@code WithinOrOverCall}
	 * labeled alternative in {@link PlSql2Parser#standard_function}.
	 * @param ctx the parse tree
	 */
	void exitWithinOrOverCall(PlSql2Parser.WithinOrOverCallContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#aggregate_windowed_function}.
	 * @param ctx the parse tree
	 */
	void enterAggregate_windowed_function(PlSql2Parser.Aggregate_windowed_functionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#aggregate_windowed_function}.
	 * @param ctx the parse tree
	 */
	void exitAggregate_windowed_function(PlSql2Parser.Aggregate_windowed_functionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#over_clause_keyword}.
	 * @param ctx the parse tree
	 */
	void enterOver_clause_keyword(PlSql2Parser.Over_clause_keywordContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#over_clause_keyword}.
	 * @param ctx the parse tree
	 */
	void exitOver_clause_keyword(PlSql2Parser.Over_clause_keywordContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#within_or_over_clause_keyword}.
	 * @param ctx the parse tree
	 */
	void enterWithin_or_over_clause_keyword(PlSql2Parser.Within_or_over_clause_keywordContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#within_or_over_clause_keyword}.
	 * @param ctx the parse tree
	 */
	void exitWithin_or_over_clause_keyword(PlSql2Parser.Within_or_over_clause_keywordContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#standard_prediction_function_keyword}.
	 * @param ctx the parse tree
	 */
	void enterStandard_prediction_function_keyword(PlSql2Parser.Standard_prediction_function_keywordContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#standard_prediction_function_keyword}.
	 * @param ctx the parse tree
	 */
	void exitStandard_prediction_function_keyword(PlSql2Parser.Standard_prediction_function_keywordContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#over_clause}.
	 * @param ctx the parse tree
	 */
	void enterOver_clause(PlSql2Parser.Over_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#over_clause}.
	 * @param ctx the parse tree
	 */
	void exitOver_clause(PlSql2Parser.Over_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#windowing_clause}.
	 * @param ctx the parse tree
	 */
	void enterWindowing_clause(PlSql2Parser.Windowing_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#windowing_clause}.
	 * @param ctx the parse tree
	 */
	void exitWindowing_clause(PlSql2Parser.Windowing_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#windowing_type}.
	 * @param ctx the parse tree
	 */
	void enterWindowing_type(PlSql2Parser.Windowing_typeContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#windowing_type}.
	 * @param ctx the parse tree
	 */
	void exitWindowing_type(PlSql2Parser.Windowing_typeContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#windowing_elements}.
	 * @param ctx the parse tree
	 */
	void enterWindowing_elements(PlSql2Parser.Windowing_elementsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#windowing_elements}.
	 * @param ctx the parse tree
	 */
	void exitWindowing_elements(PlSql2Parser.Windowing_elementsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#using_clause}.
	 * @param ctx the parse tree
	 */
	void enterUsing_clause(PlSql2Parser.Using_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#using_clause}.
	 * @param ctx the parse tree
	 */
	void exitUsing_clause(PlSql2Parser.Using_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#using_element}.
	 * @param ctx the parse tree
	 */
	void enterUsing_element(PlSql2Parser.Using_elementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#using_element}.
	 * @param ctx the parse tree
	 */
	void exitUsing_element(PlSql2Parser.Using_elementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#collect_order_by_part}.
	 * @param ctx the parse tree
	 */
	void enterCollect_order_by_part(PlSql2Parser.Collect_order_by_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#collect_order_by_part}.
	 * @param ctx the parse tree
	 */
	void exitCollect_order_by_part(PlSql2Parser.Collect_order_by_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#within_or_over_part}.
	 * @param ctx the parse tree
	 */
	void enterWithin_or_over_part(PlSql2Parser.Within_or_over_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#within_or_over_part}.
	 * @param ctx the parse tree
	 */
	void exitWithin_or_over_part(PlSql2Parser.Within_or_over_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#cost_matrix_clause}.
	 * @param ctx the parse tree
	 */
	void enterCost_matrix_clause(PlSql2Parser.Cost_matrix_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#cost_matrix_clause}.
	 * @param ctx the parse tree
	 */
	void exitCost_matrix_clause(PlSql2Parser.Cost_matrix_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#xml_passing_clause}.
	 * @param ctx the parse tree
	 */
	void enterXml_passing_clause(PlSql2Parser.Xml_passing_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#xml_passing_clause}.
	 * @param ctx the parse tree
	 */
	void exitXml_passing_clause(PlSql2Parser.Xml_passing_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#xml_attributes_clause}.
	 * @param ctx the parse tree
	 */
	void enterXml_attributes_clause(PlSql2Parser.Xml_attributes_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#xml_attributes_clause}.
	 * @param ctx the parse tree
	 */
	void exitXml_attributes_clause(PlSql2Parser.Xml_attributes_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#xml_namespaces_clause}.
	 * @param ctx the parse tree
	 */
	void enterXml_namespaces_clause(PlSql2Parser.Xml_namespaces_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#xml_namespaces_clause}.
	 * @param ctx the parse tree
	 */
	void exitXml_namespaces_clause(PlSql2Parser.Xml_namespaces_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#xml_table_column}.
	 * @param ctx the parse tree
	 */
	void enterXml_table_column(PlSql2Parser.Xml_table_columnContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#xml_table_column}.
	 * @param ctx the parse tree
	 */
	void exitXml_table_column(PlSql2Parser.Xml_table_columnContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#xml_general_default_part}.
	 * @param ctx the parse tree
	 */
	void enterXml_general_default_part(PlSql2Parser.Xml_general_default_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#xml_general_default_part}.
	 * @param ctx the parse tree
	 */
	void exitXml_general_default_part(PlSql2Parser.Xml_general_default_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#xml_multiuse_expression_element}.
	 * @param ctx the parse tree
	 */
	void enterXml_multiuse_expression_element(PlSql2Parser.Xml_multiuse_expression_elementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#xml_multiuse_expression_element}.
	 * @param ctx the parse tree
	 */
	void exitXml_multiuse_expression_element(PlSql2Parser.Xml_multiuse_expression_elementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#xmlroot_param_version_part}.
	 * @param ctx the parse tree
	 */
	void enterXmlroot_param_version_part(PlSql2Parser.Xmlroot_param_version_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#xmlroot_param_version_part}.
	 * @param ctx the parse tree
	 */
	void exitXmlroot_param_version_part(PlSql2Parser.Xmlroot_param_version_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#xmlroot_param_standalone_part}.
	 * @param ctx the parse tree
	 */
	void enterXmlroot_param_standalone_part(PlSql2Parser.Xmlroot_param_standalone_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#xmlroot_param_standalone_part}.
	 * @param ctx the parse tree
	 */
	void exitXmlroot_param_standalone_part(PlSql2Parser.Xmlroot_param_standalone_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#xmlserialize_param_enconding_part}.
	 * @param ctx the parse tree
	 */
	void enterXmlserialize_param_enconding_part(PlSql2Parser.Xmlserialize_param_enconding_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#xmlserialize_param_enconding_part}.
	 * @param ctx the parse tree
	 */
	void exitXmlserialize_param_enconding_part(PlSql2Parser.Xmlserialize_param_enconding_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#xmlserialize_param_version_part}.
	 * @param ctx the parse tree
	 */
	void enterXmlserialize_param_version_part(PlSql2Parser.Xmlserialize_param_version_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#xmlserialize_param_version_part}.
	 * @param ctx the parse tree
	 */
	void exitXmlserialize_param_version_part(PlSql2Parser.Xmlserialize_param_version_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#xmlserialize_param_ident_part}.
	 * @param ctx the parse tree
	 */
	void enterXmlserialize_param_ident_part(PlSql2Parser.Xmlserialize_param_ident_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#xmlserialize_param_ident_part}.
	 * @param ctx the parse tree
	 */
	void exitXmlserialize_param_ident_part(PlSql2Parser.Xmlserialize_param_ident_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#sql_plus_command}.
	 * @param ctx the parse tree
	 */
	void enterSql_plus_command(PlSql2Parser.Sql_plus_commandContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#sql_plus_command}.
	 * @param ctx the parse tree
	 */
	void exitSql_plus_command(PlSql2Parser.Sql_plus_commandContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#whenever_command}.
	 * @param ctx the parse tree
	 */
	void enterWhenever_command(PlSql2Parser.Whenever_commandContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#whenever_command}.
	 * @param ctx the parse tree
	 */
	void exitWhenever_command(PlSql2Parser.Whenever_commandContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#set_command}.
	 * @param ctx the parse tree
	 */
	void enterSet_command(PlSql2Parser.Set_commandContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#set_command}.
	 * @param ctx the parse tree
	 */
	void exitSet_command(PlSql2Parser.Set_commandContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#exit_command}.
	 * @param ctx the parse tree
	 */
	void enterExit_command(PlSql2Parser.Exit_commandContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#exit_command}.
	 * @param ctx the parse tree
	 */
	void exitExit_command(PlSql2Parser.Exit_commandContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#prompt_command}.
	 * @param ctx the parse tree
	 */
	void enterPrompt_command(PlSql2Parser.Prompt_commandContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#prompt_command}.
	 * @param ctx the parse tree
	 */
	void exitPrompt_command(PlSql2Parser.Prompt_commandContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#show_errors_command}.
	 * @param ctx the parse tree
	 */
	void enterShow_errors_command(PlSql2Parser.Show_errors_commandContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#show_errors_command}.
	 * @param ctx the parse tree
	 */
	void exitShow_errors_command(PlSql2Parser.Show_errors_commandContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#partition_extension_clause}.
	 * @param ctx the parse tree
	 */
	void enterPartition_extension_clause(PlSql2Parser.Partition_extension_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#partition_extension_clause}.
	 * @param ctx the parse tree
	 */
	void exitPartition_extension_clause(PlSql2Parser.Partition_extension_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#column_alias}.
	 * @param ctx the parse tree
	 */
	void enterColumn_alias(PlSql2Parser.Column_aliasContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#column_alias}.
	 * @param ctx the parse tree
	 */
	void exitColumn_alias(PlSql2Parser.Column_aliasContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#table_alias}.
	 * @param ctx the parse tree
	 */
	void enterTable_alias(PlSql2Parser.Table_aliasContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#table_alias}.
	 * @param ctx the parse tree
	 */
	void exitTable_alias(PlSql2Parser.Table_aliasContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#alias_quoted_string}.
	 * @param ctx the parse tree
	 */
	void enterAlias_quoted_string(PlSql2Parser.Alias_quoted_stringContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#alias_quoted_string}.
	 * @param ctx the parse tree
	 */
	void exitAlias_quoted_string(PlSql2Parser.Alias_quoted_stringContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#where_clause}.
	 * @param ctx the parse tree
	 */
	void enterWhere_clause(PlSql2Parser.Where_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#where_clause}.
	 * @param ctx the parse tree
	 */
	void exitWhere_clause(PlSql2Parser.Where_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#current_of_clause}.
	 * @param ctx the parse tree
	 */
	void enterCurrent_of_clause(PlSql2Parser.Current_of_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#current_of_clause}.
	 * @param ctx the parse tree
	 */
	void exitCurrent_of_clause(PlSql2Parser.Current_of_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#into_clause}.
	 * @param ctx the parse tree
	 */
	void enterInto_clause(PlSql2Parser.Into_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#into_clause}.
	 * @param ctx the parse tree
	 */
	void exitInto_clause(PlSql2Parser.Into_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#xml_column_name}.
	 * @param ctx the parse tree
	 */
	void enterXml_column_name(PlSql2Parser.Xml_column_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#xml_column_name}.
	 * @param ctx the parse tree
	 */
	void exitXml_column_name(PlSql2Parser.Xml_column_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#cost_class_name}.
	 * @param ctx the parse tree
	 */
	void enterCost_class_name(PlSql2Parser.Cost_class_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#cost_class_name}.
	 * @param ctx the parse tree
	 */
	void exitCost_class_name(PlSql2Parser.Cost_class_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#attribute_name}.
	 * @param ctx the parse tree
	 */
	void enterAttribute_name(PlSql2Parser.Attribute_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#attribute_name}.
	 * @param ctx the parse tree
	 */
	void exitAttribute_name(PlSql2Parser.Attribute_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#savepoint_name}.
	 * @param ctx the parse tree
	 */
	void enterSavepoint_name(PlSql2Parser.Savepoint_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#savepoint_name}.
	 * @param ctx the parse tree
	 */
	void exitSavepoint_name(PlSql2Parser.Savepoint_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#rollback_segment_name}.
	 * @param ctx the parse tree
	 */
	void enterRollback_segment_name(PlSql2Parser.Rollback_segment_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#rollback_segment_name}.
	 * @param ctx the parse tree
	 */
	void exitRollback_segment_name(PlSql2Parser.Rollback_segment_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#table_var_name}.
	 * @param ctx the parse tree
	 */
	void enterTable_var_name(PlSql2Parser.Table_var_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#table_var_name}.
	 * @param ctx the parse tree
	 */
	void exitTable_var_name(PlSql2Parser.Table_var_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#schema_name}.
	 * @param ctx the parse tree
	 */
	void enterSchema_name(PlSql2Parser.Schema_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#schema_name}.
	 * @param ctx the parse tree
	 */
	void exitSchema_name(PlSql2Parser.Schema_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#routine_name}.
	 * @param ctx the parse tree
	 */
	void enterRoutine_name(PlSql2Parser.Routine_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#routine_name}.
	 * @param ctx the parse tree
	 */
	void exitRoutine_name(PlSql2Parser.Routine_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#package_name}.
	 * @param ctx the parse tree
	 */
	void enterPackage_name(PlSql2Parser.Package_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#package_name}.
	 * @param ctx the parse tree
	 */
	void exitPackage_name(PlSql2Parser.Package_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#implementation_type_name}.
	 * @param ctx the parse tree
	 */
	void enterImplementation_type_name(PlSql2Parser.Implementation_type_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#implementation_type_name}.
	 * @param ctx the parse tree
	 */
	void exitImplementation_type_name(PlSql2Parser.Implementation_type_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#parameter_name}.
	 * @param ctx the parse tree
	 */
	void enterParameter_name(PlSql2Parser.Parameter_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#parameter_name}.
	 * @param ctx the parse tree
	 */
	void exitParameter_name(PlSql2Parser.Parameter_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#reference_model_name}.
	 * @param ctx the parse tree
	 */
	void enterReference_model_name(PlSql2Parser.Reference_model_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#reference_model_name}.
	 * @param ctx the parse tree
	 */
	void exitReference_model_name(PlSql2Parser.Reference_model_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#main_model_name}.
	 * @param ctx the parse tree
	 */
	void enterMain_model_name(PlSql2Parser.Main_model_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#main_model_name}.
	 * @param ctx the parse tree
	 */
	void exitMain_model_name(PlSql2Parser.Main_model_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#aggregate_function_name}.
	 * @param ctx the parse tree
	 */
	void enterAggregate_function_name(PlSql2Parser.Aggregate_function_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#aggregate_function_name}.
	 * @param ctx the parse tree
	 */
	void exitAggregate_function_name(PlSql2Parser.Aggregate_function_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#query_name}.
	 * @param ctx the parse tree
	 */
	void enterQuery_name(PlSql2Parser.Query_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#query_name}.
	 * @param ctx the parse tree
	 */
	void exitQuery_name(PlSql2Parser.Query_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#constraint_name}.
	 * @param ctx the parse tree
	 */
	void enterConstraint_name(PlSql2Parser.Constraint_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#constraint_name}.
	 * @param ctx the parse tree
	 */
	void exitConstraint_name(PlSql2Parser.Constraint_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#label_name}.
	 * @param ctx the parse tree
	 */
	void enterLabel_name(PlSql2Parser.Label_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#label_name}.
	 * @param ctx the parse tree
	 */
	void exitLabel_name(PlSql2Parser.Label_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#type_name}.
	 * @param ctx the parse tree
	 */
	void enterType_name(PlSql2Parser.Type_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#type_name}.
	 * @param ctx the parse tree
	 */
	void exitType_name(PlSql2Parser.Type_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#sequence_name}.
	 * @param ctx the parse tree
	 */
	void enterSequence_name(PlSql2Parser.Sequence_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#sequence_name}.
	 * @param ctx the parse tree
	 */
	void exitSequence_name(PlSql2Parser.Sequence_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#exception_name}.
	 * @param ctx the parse tree
	 */
	void enterException_name(PlSql2Parser.Exception_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#exception_name}.
	 * @param ctx the parse tree
	 */
	void exitException_name(PlSql2Parser.Exception_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#function_name}.
	 * @param ctx the parse tree
	 */
	void enterFunction_name(PlSql2Parser.Function_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#function_name}.
	 * @param ctx the parse tree
	 */
	void exitFunction_name(PlSql2Parser.Function_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#procedure_name}.
	 * @param ctx the parse tree
	 */
	void enterProcedure_name(PlSql2Parser.Procedure_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#procedure_name}.
	 * @param ctx the parse tree
	 */
	void exitProcedure_name(PlSql2Parser.Procedure_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#trigger_name}.
	 * @param ctx the parse tree
	 */
	void enterTrigger_name(PlSql2Parser.Trigger_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#trigger_name}.
	 * @param ctx the parse tree
	 */
	void exitTrigger_name(PlSql2Parser.Trigger_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#variable_name}.
	 * @param ctx the parse tree
	 */
	void enterVariable_name(PlSql2Parser.Variable_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#variable_name}.
	 * @param ctx the parse tree
	 */
	void exitVariable_name(PlSql2Parser.Variable_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#index_name}.
	 * @param ctx the parse tree
	 */
	void enterIndex_name(PlSql2Parser.Index_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#index_name}.
	 * @param ctx the parse tree
	 */
	void exitIndex_name(PlSql2Parser.Index_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#cursor_name}.
	 * @param ctx the parse tree
	 */
	void enterCursor_name(PlSql2Parser.Cursor_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#cursor_name}.
	 * @param ctx the parse tree
	 */
	void exitCursor_name(PlSql2Parser.Cursor_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#record_name}.
	 * @param ctx the parse tree
	 */
	void enterRecord_name(PlSql2Parser.Record_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#record_name}.
	 * @param ctx the parse tree
	 */
	void exitRecord_name(PlSql2Parser.Record_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#collection_name}.
	 * @param ctx the parse tree
	 */
	void enterCollection_name(PlSql2Parser.Collection_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#collection_name}.
	 * @param ctx the parse tree
	 */
	void exitCollection_name(PlSql2Parser.Collection_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#link_name}.
	 * @param ctx the parse tree
	 */
	void enterLink_name(PlSql2Parser.Link_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#link_name}.
	 * @param ctx the parse tree
	 */
	void exitLink_name(PlSql2Parser.Link_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#column_name}.
	 * @param ctx the parse tree
	 */
	void enterColumn_name(PlSql2Parser.Column_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#column_name}.
	 * @param ctx the parse tree
	 */
	void exitColumn_name(PlSql2Parser.Column_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#role_name}.
	 * @param ctx the parse tree
	 */
	void enterRole_name(PlSql2Parser.Role_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#role_name}.
	 * @param ctx the parse tree
	 */
	void exitRole_name(PlSql2Parser.Role_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#tableview_name}.
	 * @param ctx the parse tree
	 */
	void enterTableview_name(PlSql2Parser.Tableview_nameContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#tableview_name}.
	 * @param ctx the parse tree
	 */
	void exitTableview_name(PlSql2Parser.Tableview_nameContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#dot_id}.
	 * @param ctx the parse tree
	 */
	void enterDot_id(PlSql2Parser.Dot_idContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#dot_id}.
	 * @param ctx the parse tree
	 */
	void exitDot_id(PlSql2Parser.Dot_idContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#star}.
	 * @param ctx the parse tree
	 */
	void enterStar(PlSql2Parser.StarContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#star}.
	 * @param ctx the parse tree
	 */
	void exitStar(PlSql2Parser.StarContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#keep_clause}.
	 * @param ctx the parse tree
	 */
	void enterKeep_clause(PlSql2Parser.Keep_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#keep_clause}.
	 * @param ctx the parse tree
	 */
	void exitKeep_clause(PlSql2Parser.Keep_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#function_argument}.
	 * @param ctx the parse tree
	 */
	void enterFunction_argument(PlSql2Parser.Function_argumentContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#function_argument}.
	 * @param ctx the parse tree
	 */
	void exitFunction_argument(PlSql2Parser.Function_argumentContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#function_argument_analytic}.
	 * @param ctx the parse tree
	 */
	void enterFunction_argument_analytic(PlSql2Parser.Function_argument_analyticContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#function_argument_analytic}.
	 * @param ctx the parse tree
	 */
	void exitFunction_argument_analytic(PlSql2Parser.Function_argument_analyticContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#function_argument_modeling}.
	 * @param ctx the parse tree
	 */
	void enterFunction_argument_modeling(PlSql2Parser.Function_argument_modelingContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#function_argument_modeling}.
	 * @param ctx the parse tree
	 */
	void exitFunction_argument_modeling(PlSql2Parser.Function_argument_modelingContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#respect_or_ignore_nulls}.
	 * @param ctx the parse tree
	 */
	void enterRespect_or_ignore_nulls(PlSql2Parser.Respect_or_ignore_nullsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#respect_or_ignore_nulls}.
	 * @param ctx the parse tree
	 */
	void exitRespect_or_ignore_nulls(PlSql2Parser.Respect_or_ignore_nullsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#argument}.
	 * @param ctx the parse tree
	 */
	void enterArgument(PlSql2Parser.ArgumentContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#argument}.
	 * @param ctx the parse tree
	 */
	void exitArgument(PlSql2Parser.ArgumentContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#type_spec}.
	 * @param ctx the parse tree
	 */
	void enterType_spec(PlSql2Parser.Type_specContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#type_spec}.
	 * @param ctx the parse tree
	 */
	void exitType_spec(PlSql2Parser.Type_specContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#datatype}.
	 * @param ctx the parse tree
	 */
	void enterDatatype(PlSql2Parser.DatatypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#datatype}.
	 * @param ctx the parse tree
	 */
	void exitDatatype(PlSql2Parser.DatatypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#precision_part}.
	 * @param ctx the parse tree
	 */
	void enterPrecision_part(PlSql2Parser.Precision_partContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#precision_part}.
	 * @param ctx the parse tree
	 */
	void exitPrecision_part(PlSql2Parser.Precision_partContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#native_datatype_element}.
	 * @param ctx the parse tree
	 */
	void enterNative_datatype_element(PlSql2Parser.Native_datatype_elementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#native_datatype_element}.
	 * @param ctx the parse tree
	 */
	void exitNative_datatype_element(PlSql2Parser.Native_datatype_elementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#bind_variable}.
	 * @param ctx the parse tree
	 */
	void enterBind_variable(PlSql2Parser.Bind_variableContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#bind_variable}.
	 * @param ctx the parse tree
	 */
	void exitBind_variable(PlSql2Parser.Bind_variableContext ctx);
	/**
	 * Enter a parse tree produced by the {@code FuncCall}
	 * labeled alternative in {@link PlSql2Parser#general_element}.
	 * @param ctx the parse tree
	 */
	void enterFuncCall(PlSql2Parser.FuncCallContext ctx);
	/**
	 * Exit a parse tree produced by the {@code FuncCall}
	 * labeled alternative in {@link PlSql2Parser#general_element}.
	 * @param ctx the parse tree
	 */
	void exitFuncCall(PlSql2Parser.FuncCallContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Identifier}
	 * labeled alternative in {@link PlSql2Parser#general_element}.
	 * @param ctx the parse tree
	 */
	void enterIdentifier(PlSql2Parser.IdentifierContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Identifier}
	 * labeled alternative in {@link PlSql2Parser#general_element}.
	 * @param ctx the parse tree
	 */
	void exitIdentifier(PlSql2Parser.IdentifierContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#table_element}.
	 * @param ctx the parse tree
	 */
	void enterTable_element(PlSql2Parser.Table_elementContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#table_element}.
	 * @param ctx the parse tree
	 */
	void exitTable_element(PlSql2Parser.Table_elementContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#constant}.
	 * @param ctx the parse tree
	 */
	void enterConstant(PlSql2Parser.ConstantContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#constant}.
	 * @param ctx the parse tree
	 */
	void exitConstant(PlSql2Parser.ConstantContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#numeric}.
	 * @param ctx the parse tree
	 */
	void enterNumeric(PlSql2Parser.NumericContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#numeric}.
	 * @param ctx the parse tree
	 */
	void exitNumeric(PlSql2Parser.NumericContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#numeric_negative}.
	 * @param ctx the parse tree
	 */
	void enterNumeric_negative(PlSql2Parser.Numeric_negativeContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#numeric_negative}.
	 * @param ctx the parse tree
	 */
	void exitNumeric_negative(PlSql2Parser.Numeric_negativeContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#quoted_string}.
	 * @param ctx the parse tree
	 */
	void enterQuoted_string(PlSql2Parser.Quoted_stringContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#quoted_string}.
	 * @param ctx the parse tree
	 */
	void exitQuoted_string(PlSql2Parser.Quoted_stringContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#r_id}.
	 * @param ctx the parse tree
	 */
	void enterR_id(PlSql2Parser.R_idContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#r_id}.
	 * @param ctx the parse tree
	 */
	void exitR_id(PlSql2Parser.R_idContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#id_expression}.
	 * @param ctx the parse tree
	 */
	void enterId_expression(PlSql2Parser.Id_expressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#id_expression}.
	 * @param ctx the parse tree
	 */
	void exitId_expression(PlSql2Parser.Id_expressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#not_equal_op}.
	 * @param ctx the parse tree
	 */
	void enterNot_equal_op(PlSql2Parser.Not_equal_opContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#not_equal_op}.
	 * @param ctx the parse tree
	 */
	void exitNot_equal_op(PlSql2Parser.Not_equal_opContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#greater_than_or_equals_op}.
	 * @param ctx the parse tree
	 */
	void enterGreater_than_or_equals_op(PlSql2Parser.Greater_than_or_equals_opContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#greater_than_or_equals_op}.
	 * @param ctx the parse tree
	 */
	void exitGreater_than_or_equals_op(PlSql2Parser.Greater_than_or_equals_opContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#less_than_or_equals_op}.
	 * @param ctx the parse tree
	 */
	void enterLess_than_or_equals_op(PlSql2Parser.Less_than_or_equals_opContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#less_than_or_equals_op}.
	 * @param ctx the parse tree
	 */
	void exitLess_than_or_equals_op(PlSql2Parser.Less_than_or_equals_opContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#concatenation_op}.
	 * @param ctx the parse tree
	 */
	void enterConcatenation_op(PlSql2Parser.Concatenation_opContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#concatenation_op}.
	 * @param ctx the parse tree
	 */
	void exitConcatenation_op(PlSql2Parser.Concatenation_opContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#outer_join_sign}.
	 * @param ctx the parse tree
	 */
	void enterOuter_join_sign(PlSql2Parser.Outer_join_signContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#outer_join_sign}.
	 * @param ctx the parse tree
	 */
	void exitOuter_join_sign(PlSql2Parser.Outer_join_signContext ctx);
	/**
	 * Enter a parse tree produced by {@link PlSql2Parser#regular_id}.
	 * @param ctx the parse tree
	 */
	void enterRegular_id(PlSql2Parser.Regular_idContext ctx);
	/**
	 * Exit a parse tree produced by {@link PlSql2Parser#regular_id}.
	 * @param ctx the parse tree
	 */
	void exitRegular_id(PlSql2Parser.Regular_idContext ctx);
}
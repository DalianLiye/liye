// Generated from C:/Users/c190471/Desktop/RapidAutomation/src/antlr4/dtd\DTDParser.g4 by ANTLR 4.8
package antlr4.dtd;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link DTDParserParser}.
 */
public interface DTDParserListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link DTDParserParser#dtd_document}.
	 * @param ctx the parse tree
	 */
	void enterDtd_document(DTDParserParser.Dtd_documentContext ctx);
	/**
	 * Exit a parse tree produced by {@link DTDParserParser#dtd_document}.
	 * @param ctx the parse tree
	 */
	void exitDtd_document(DTDParserParser.Dtd_documentContext ctx);
	/**
	 * Enter a parse tree produced by {@link DTDParserParser#dtd_element}.
	 * @param ctx the parse tree
	 */
	void enterDtd_element(DTDParserParser.Dtd_elementContext ctx);
	/**
	 * Exit a parse tree produced by {@link DTDParserParser#dtd_element}.
	 * @param ctx the parse tree
	 */
	void exitDtd_element(DTDParserParser.Dtd_elementContext ctx);
	/**
	 * Enter a parse tree produced by {@link DTDParserParser#children_elements}.
	 * @param ctx the parse tree
	 */
	void enterChildren_elements(DTDParserParser.Children_elementsContext ctx);
	/**
	 * Exit a parse tree produced by {@link DTDParserParser#children_elements}.
	 * @param ctx the parse tree
	 */
	void exitChildren_elements(DTDParserParser.Children_elementsContext ctx);
	/**
	 * Enter a parse tree produced by {@link DTDParserParser#children}.
	 * @param ctx the parse tree
	 */
	void enterChildren(DTDParserParser.ChildrenContext ctx);
	/**
	 * Exit a parse tree produced by {@link DTDParserParser#children}.
	 * @param ctx the parse tree
	 */
	void exitChildren(DTDParserParser.ChildrenContext ctx);
	/**
	 * Enter a parse tree produced by {@link DTDParserParser#child}.
	 * @param ctx the parse tree
	 */
	void enterChild(DTDParserParser.ChildContext ctx);
	/**
	 * Exit a parse tree produced by {@link DTDParserParser#child}.
	 * @param ctx the parse tree
	 */
	void exitChild(DTDParserParser.ChildContext ctx);
	/**
	 * Enter a parse tree produced by {@link DTDParserParser#child01}.
	 * @param ctx the parse tree
	 */
	void enterChild01(DTDParserParser.Child01Context ctx);
	/**
	 * Exit a parse tree produced by {@link DTDParserParser#child01}.
	 * @param ctx the parse tree
	 */
	void exitChild01(DTDParserParser.Child01Context ctx);
	/**
	 * Enter a parse tree produced by {@link DTDParserParser#dtd_attlist}.
	 * @param ctx the parse tree
	 */
	void enterDtd_attlist(DTDParserParser.Dtd_attlistContext ctx);
	/**
	 * Exit a parse tree produced by {@link DTDParserParser#dtd_attlist}.
	 * @param ctx the parse tree
	 */
	void exitDtd_attlist(DTDParserParser.Dtd_attlistContext ctx);
	/**
	 * Enter a parse tree produced by {@link DTDParserParser#parent_element}.
	 * @param ctx the parse tree
	 */
	void enterParent_element(DTDParserParser.Parent_elementContext ctx);
	/**
	 * Exit a parse tree produced by {@link DTDParserParser#parent_element}.
	 * @param ctx the parse tree
	 */
	void exitParent_element(DTDParserParser.Parent_elementContext ctx);
	/**
	 * Enter a parse tree produced by {@link DTDParserParser#element}.
	 * @param ctx the parse tree
	 */
	void enterElement(DTDParserParser.ElementContext ctx);
	/**
	 * Exit a parse tree produced by {@link DTDParserParser#element}.
	 * @param ctx the parse tree
	 */
	void exitElement(DTDParserParser.ElementContext ctx);
	/**
	 * Enter a parse tree produced by {@link DTDParserParser#attribute}.
	 * @param ctx the parse tree
	 */
	void enterAttribute(DTDParserParser.AttributeContext ctx);
	/**
	 * Exit a parse tree produced by {@link DTDParserParser#attribute}.
	 * @param ctx the parse tree
	 */
	void exitAttribute(DTDParserParser.AttributeContext ctx);
	/**
	 * Enter a parse tree produced by {@link DTDParserParser#value}.
	 * @param ctx the parse tree
	 */
	void enterValue(DTDParserParser.ValueContext ctx);
	/**
	 * Exit a parse tree produced by {@link DTDParserParser#value}.
	 * @param ctx the parse tree
	 */
	void exitValue(DTDParserParser.ValueContext ctx);
}
// Generated from C:/Users/c190471/Desktop/RapidAutomation/src/antlr4/dtd\DTDParser.g4 by ANTLR 4.8
package antlr4.dtd;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link DTDParserParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface DTDParserVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link DTDParserParser#dtd_document}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDtd_document(DTDParserParser.Dtd_documentContext ctx);
	/**
	 * Visit a parse tree produced by {@link DTDParserParser#dtd_element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDtd_element(DTDParserParser.Dtd_elementContext ctx);
	/**
	 * Visit a parse tree produced by {@link DTDParserParser#children_elements}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitChildren_elements(DTDParserParser.Children_elementsContext ctx);
	/**
	 * Visit a parse tree produced by {@link DTDParserParser#children}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitChildren(DTDParserParser.ChildrenContext ctx);
	/**
	 * Visit a parse tree produced by {@link DTDParserParser#child}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitChild(DTDParserParser.ChildContext ctx);
	/**
	 * Visit a parse tree produced by {@link DTDParserParser#child01}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitChild01(DTDParserParser.Child01Context ctx);
	/**
	 * Visit a parse tree produced by {@link DTDParserParser#dtd_attlist}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDtd_attlist(DTDParserParser.Dtd_attlistContext ctx);
	/**
	 * Visit a parse tree produced by {@link DTDParserParser#parent_element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParent_element(DTDParserParser.Parent_elementContext ctx);
	/**
	 * Visit a parse tree produced by {@link DTDParserParser#element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElement(DTDParserParser.ElementContext ctx);
	/**
	 * Visit a parse tree produced by {@link DTDParserParser#attribute}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAttribute(DTDParserParser.AttributeContext ctx);
	/**
	 * Visit a parse tree produced by {@link DTDParserParser#value}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitValue(DTDParserParser.ValueContext ctx);
}
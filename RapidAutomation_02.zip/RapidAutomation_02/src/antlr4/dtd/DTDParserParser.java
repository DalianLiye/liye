// Generated from C:/Users/c190471/Desktop/RapidAutomation/src/antlr4/dtd\DTDParser.g4 by ANTLR 4.8
package antlr4.dtd;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class DTDParserParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.8", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, T__4=5, T__5=6, T__6=7, T__7=8, T__8=9, 
		T__9=10, T__10=11, T__11=12, T__12=13, T__13=14, T__14=15, T__15=16, T__16=17, 
		Name=18, COMMENT=19;
	public static final int
		RULE_dtd_document = 0, RULE_dtd_element = 1, RULE_children_elements = 2, 
		RULE_children = 3, RULE_child = 4, RULE_child01 = 5, RULE_dtd_attlist = 6, 
		RULE_parent_element = 7, RULE_element = 8, RULE_attribute = 9, RULE_value = 10;
	private static String[] makeRuleNames() {
		return new String[] {
			"dtd_document", "dtd_element", "children_elements", "children", "child", 
			"child01", "dtd_attlist", "parent_element", "element", "attribute", "value"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'<!ELEMENT'", "'>'", "'('", "')'", "')*'", "')?'", "')+'", "'EMPTY'", 
			"','", "'|'", "'*'", "'+'", "'?'", "'<!ATTLIST'", "'CDATA'", "'#REQUIRED'", 
			"'#IMPLIED'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, "Name", "COMMENT"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "DTDParser.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public DTDParserParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	public static class Dtd_documentContext extends ParserRuleContext {
		public List<Dtd_elementContext> dtd_element() {
			return getRuleContexts(Dtd_elementContext.class);
		}
		public Dtd_elementContext dtd_element(int i) {
			return getRuleContext(Dtd_elementContext.class,i);
		}
		public List<Dtd_attlistContext> dtd_attlist() {
			return getRuleContexts(Dtd_attlistContext.class);
		}
		public Dtd_attlistContext dtd_attlist(int i) {
			return getRuleContext(Dtd_attlistContext.class,i);
		}
		public Dtd_documentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dtd_document; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DTDParserListener ) ((DTDParserListener)listener).enterDtd_document(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DTDParserListener ) ((DTDParserListener)listener).exitDtd_document(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DTDParserVisitor ) return ((DTDParserVisitor<? extends T>)visitor).visitDtd_document(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Dtd_documentContext dtd_document() throws RecognitionException {
		Dtd_documentContext _localctx = new Dtd_documentContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_dtd_document);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(31);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(22);
				dtd_element();
				setState(26);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__13) {
					{
					{
					setState(23);
					dtd_attlist();
					}
					}
					setState(28);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				}
				setState(33);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Dtd_elementContext extends ParserRuleContext {
		public Parent_elementContext parent_element() {
			return getRuleContext(Parent_elementContext.class,0);
		}
		public Children_elementsContext children_elements() {
			return getRuleContext(Children_elementsContext.class,0);
		}
		public Dtd_elementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dtd_element; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DTDParserListener ) ((DTDParserListener)listener).enterDtd_element(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DTDParserListener ) ((DTDParserListener)listener).exitDtd_element(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DTDParserVisitor ) return ((DTDParserVisitor<? extends T>)visitor).visitDtd_element(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Dtd_elementContext dtd_element() throws RecognitionException {
		Dtd_elementContext _localctx = new Dtd_elementContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_dtd_element);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(34);
			match(T__0);
			setState(35);
			parent_element();
			setState(36);
			children_elements();
			setState(37);
			match(T__1);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Children_elementsContext extends ParserRuleContext {
		public ChildrenContext children() {
			return getRuleContext(ChildrenContext.class,0);
		}
		public Children_elementsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_children_elements; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DTDParserListener ) ((DTDParserListener)listener).enterChildren_elements(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DTDParserListener ) ((DTDParserListener)listener).exitChildren_elements(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DTDParserVisitor ) return ((DTDParserVisitor<? extends T>)visitor).visitChildren_elements(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Children_elementsContext children_elements() throws RecognitionException {
		Children_elementsContext _localctx = new Children_elementsContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_children_elements);
		int _la;
		try {
			setState(44);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__2:
				enterOuterAlt(_localctx, 1);
				{
				setState(39);
				match(T__2);
				setState(40);
				children();
				setState(41);
				_la = _input.LA(1);
				if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__3) | (1L << T__4) | (1L << T__5) | (1L << T__6))) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case T__7:
				enterOuterAlt(_localctx, 2);
				{
				setState(43);
				match(T__7);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ChildrenContext extends ParserRuleContext {
		public List<ChildContext> child() {
			return getRuleContexts(ChildContext.class);
		}
		public ChildContext child(int i) {
			return getRuleContext(ChildContext.class,i);
		}
		public ChildrenContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_children; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DTDParserListener ) ((DTDParserListener)listener).enterChildren(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DTDParserListener ) ((DTDParserListener)listener).exitChildren(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DTDParserVisitor ) return ((DTDParserVisitor<? extends T>)visitor).visitChildren(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ChildrenContext children() throws RecognitionException {
		ChildrenContext _localctx = new ChildrenContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_children);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(57);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__8) | (1L << T__9) | (1L << T__10) | (1L << T__11) | (1L << T__12) | (1L << Name))) != 0)) {
				{
				{
				setState(49);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,3,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(46);
						_la = _input.LA(1);
						if ( !(_la==T__8 || _la==T__9) ) {
						_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						}
						} 
					}
					setState(51);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,3,_ctx);
				}
				setState(52);
				child();
				setState(53);
				_la = _input.LA(1);
				if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__10) | (1L << T__11) | (1L << T__12))) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				}
				setState(59);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ChildContext extends ParserRuleContext {
		public List<Child01Context> child01() {
			return getRuleContexts(Child01Context.class);
		}
		public Child01Context child01(int i) {
			return getRuleContext(Child01Context.class,i);
		}
		public ChildContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_child; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DTDParserListener ) ((DTDParserListener)listener).enterChild(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DTDParserListener ) ((DTDParserListener)listener).exitChild(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DTDParserVisitor ) return ((DTDParserVisitor<? extends T>)visitor).visitChild(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ChildContext child() throws RecognitionException {
		ChildContext _localctx = new ChildContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_child);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(71);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__8) | (1L << T__9) | (1L << Name))) != 0)) {
				{
				{
				setState(63);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__8 || _la==T__9) {
					{
					{
					setState(60);
					_la = _input.LA(1);
					if ( !(_la==T__8 || _la==T__9) ) {
					_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					}
					}
					setState(65);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(66);
				child01();
				setState(67);
				_la = _input.LA(1);
				if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__10) | (1L << T__11) | (1L << T__12))) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				}
				setState(73);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Child01Context extends ParserRuleContext {
		public TerminalNode Name() { return getToken(DTDParserParser.Name, 0); }
		public Child01Context(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_child01; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DTDParserListener ) ((DTDParserListener)listener).enterChild01(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DTDParserListener ) ((DTDParserListener)listener).exitChild01(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DTDParserVisitor ) return ((DTDParserVisitor<? extends T>)visitor).visitChild01(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Child01Context child01() throws RecognitionException {
		Child01Context _localctx = new Child01Context(_ctx, getState());
		enterRule(_localctx, 10, RULE_child01);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(74);
			match(Name);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Dtd_attlistContext extends ParserRuleContext {
		public ElementContext element() {
			return getRuleContext(ElementContext.class,0);
		}
		public List<AttributeContext> attribute() {
			return getRuleContexts(AttributeContext.class);
		}
		public AttributeContext attribute(int i) {
			return getRuleContext(AttributeContext.class,i);
		}
		public Dtd_attlistContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dtd_attlist; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DTDParserListener ) ((DTDParserListener)listener).enterDtd_attlist(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DTDParserListener ) ((DTDParserListener)listener).exitDtd_attlist(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DTDParserVisitor ) return ((DTDParserVisitor<? extends T>)visitor).visitDtd_attlist(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Dtd_attlistContext dtd_attlist() throws RecognitionException {
		Dtd_attlistContext _localctx = new Dtd_attlistContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_dtd_attlist);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(76);
			match(T__13);
			setState(77);
			element();
			setState(81);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==Name) {
				{
				{
				setState(78);
				attribute();
				}
				}
				setState(83);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(84);
			match(T__1);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Parent_elementContext extends ParserRuleContext {
		public TerminalNode Name() { return getToken(DTDParserParser.Name, 0); }
		public Parent_elementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parent_element; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DTDParserListener ) ((DTDParserListener)listener).enterParent_element(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DTDParserListener ) ((DTDParserListener)listener).exitParent_element(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DTDParserVisitor ) return ((DTDParserVisitor<? extends T>)visitor).visitParent_element(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Parent_elementContext parent_element() throws RecognitionException {
		Parent_elementContext _localctx = new Parent_elementContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_parent_element);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(86);
			match(Name);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ElementContext extends ParserRuleContext {
		public TerminalNode Name() { return getToken(DTDParserParser.Name, 0); }
		public ElementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_element; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DTDParserListener ) ((DTDParserListener)listener).enterElement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DTDParserListener ) ((DTDParserListener)listener).exitElement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DTDParserVisitor ) return ((DTDParserVisitor<? extends T>)visitor).visitElement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ElementContext element() throws RecognitionException {
		ElementContext _localctx = new ElementContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_element);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(88);
			match(Name);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AttributeContext extends ParserRuleContext {
		public TerminalNode Name() { return getToken(DTDParserParser.Name, 0); }
		public ValueContext value() {
			return getRuleContext(ValueContext.class,0);
		}
		public AttributeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_attribute; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DTDParserListener ) ((DTDParserListener)listener).enterAttribute(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DTDParserListener ) ((DTDParserListener)listener).exitAttribute(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DTDParserVisitor ) return ((DTDParserVisitor<? extends T>)visitor).visitAttribute(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AttributeContext attribute() throws RecognitionException {
		AttributeContext _localctx = new AttributeContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_attribute);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(90);
			match(Name);
			setState(96);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__14:
				{
				setState(91);
				match(T__14);
				}
				break;
			case T__2:
				{
				setState(92);
				match(T__2);
				setState(93);
				value();
				setState(94);
				match(T__3);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(98);
			_la = _input.LA(1);
			if ( !(_la==T__15 || _la==T__16) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ValueContext extends ParserRuleContext {
		public List<TerminalNode> Name() { return getTokens(DTDParserParser.Name); }
		public TerminalNode Name(int i) {
			return getToken(DTDParserParser.Name, i);
		}
		public ValueContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_value; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DTDParserListener ) ((DTDParserListener)listener).enterValue(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DTDParserListener ) ((DTDParserListener)listener).exitValue(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DTDParserVisitor ) return ((DTDParserVisitor<? extends T>)visitor).visitValue(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ValueContext value() throws RecognitionException {
		ValueContext _localctx = new ValueContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_value);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(109);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__9 || _la==Name) {
				{
				{
				setState(103);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__9) {
					{
					{
					setState(100);
					match(T__9);
					}
					}
					setState(105);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(106);
				match(Name);
				}
				}
				setState(111);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\25s\4\2\t\2\4\3\t"+
		"\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\4"+
		"\f\t\f\3\2\3\2\7\2\33\n\2\f\2\16\2\36\13\2\7\2 \n\2\f\2\16\2#\13\2\3\3"+
		"\3\3\3\3\3\3\3\3\3\4\3\4\3\4\3\4\3\4\5\4/\n\4\3\5\7\5\62\n\5\f\5\16\5"+
		"\65\13\5\3\5\3\5\3\5\7\5:\n\5\f\5\16\5=\13\5\3\6\7\6@\n\6\f\6\16\6C\13"+
		"\6\3\6\3\6\3\6\7\6H\n\6\f\6\16\6K\13\6\3\7\3\7\3\b\3\b\3\b\7\bR\n\b\f"+
		"\b\16\bU\13\b\3\b\3\b\3\t\3\t\3\n\3\n\3\13\3\13\3\13\3\13\3\13\3\13\5"+
		"\13c\n\13\3\13\3\13\3\f\7\fh\n\f\f\f\16\fk\13\f\3\f\7\fn\n\f\f\f\16\f"+
		"q\13\f\3\f\2\2\r\2\4\6\b\n\f\16\20\22\24\26\2\6\3\2\6\t\3\2\13\f\3\2\r"+
		"\17\3\2\22\23\2r\2!\3\2\2\2\4$\3\2\2\2\6.\3\2\2\2\b;\3\2\2\2\nI\3\2\2"+
		"\2\fL\3\2\2\2\16N\3\2\2\2\20X\3\2\2\2\22Z\3\2\2\2\24\\\3\2\2\2\26o\3\2"+
		"\2\2\30\34\5\4\3\2\31\33\5\16\b\2\32\31\3\2\2\2\33\36\3\2\2\2\34\32\3"+
		"\2\2\2\34\35\3\2\2\2\35 \3\2\2\2\36\34\3\2\2\2\37\30\3\2\2\2 #\3\2\2\2"+
		"!\37\3\2\2\2!\"\3\2\2\2\"\3\3\2\2\2#!\3\2\2\2$%\7\3\2\2%&\5\20\t\2&\'"+
		"\5\6\4\2\'(\7\4\2\2(\5\3\2\2\2)*\7\5\2\2*+\5\b\5\2+,\t\2\2\2,/\3\2\2\2"+
		"-/\7\n\2\2.)\3\2\2\2.-\3\2\2\2/\7\3\2\2\2\60\62\t\3\2\2\61\60\3\2\2\2"+
		"\62\65\3\2\2\2\63\61\3\2\2\2\63\64\3\2\2\2\64\66\3\2\2\2\65\63\3\2\2\2"+
		"\66\67\5\n\6\2\678\t\4\2\28:\3\2\2\29\63\3\2\2\2:=\3\2\2\2;9\3\2\2\2;"+
		"<\3\2\2\2<\t\3\2\2\2=;\3\2\2\2>@\t\3\2\2?>\3\2\2\2@C\3\2\2\2A?\3\2\2\2"+
		"AB\3\2\2\2BD\3\2\2\2CA\3\2\2\2DE\5\f\7\2EF\t\4\2\2FH\3\2\2\2GA\3\2\2\2"+
		"HK\3\2\2\2IG\3\2\2\2IJ\3\2\2\2J\13\3\2\2\2KI\3\2\2\2LM\7\24\2\2M\r\3\2"+
		"\2\2NO\7\20\2\2OS\5\22\n\2PR\5\24\13\2QP\3\2\2\2RU\3\2\2\2SQ\3\2\2\2S"+
		"T\3\2\2\2TV\3\2\2\2US\3\2\2\2VW\7\4\2\2W\17\3\2\2\2XY\7\24\2\2Y\21\3\2"+
		"\2\2Z[\7\24\2\2[\23\3\2\2\2\\b\7\24\2\2]c\7\21\2\2^_\7\5\2\2_`\5\26\f"+
		"\2`a\7\6\2\2ac\3\2\2\2b]\3\2\2\2b^\3\2\2\2cd\3\2\2\2de\t\5\2\2e\25\3\2"+
		"\2\2fh\7\f\2\2gf\3\2\2\2hk\3\2\2\2ig\3\2\2\2ij\3\2\2\2jl\3\2\2\2ki\3\2"+
		"\2\2ln\7\24\2\2mi\3\2\2\2nq\3\2\2\2om\3\2\2\2op\3\2\2\2p\27\3\2\2\2qo"+
		"\3\2\2\2\r\34!.\63;AISbio";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}
package db;

import config.Configure;

import java.io.BufferedReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CommonDB {

    public static Connection connect() throws Exception{
        Connection conn = null;
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            conn = DriverManager.getConnection(Configure.URL_DB, Configure.ACCOUNT_DB, Configure.PASSWORD_DB);
            return conn;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return conn;
        }
    }

    public static void close(Connection conn) throws Exception{
        conn.close();
    }

    public static String createStatementGen(String inputFile, String tableName) {

        String create_script = "";

        Path filePath = Paths.get(inputFile);

        String file_name = filePath.getFileName().toString();

        try {
            BufferedReader br = Files.newBufferedReader(filePath, StandardCharsets.UTF_8);
            String line = br.readLine();

            List<String> headerList = Arrays.asList(line.split(","));

            create_script = "create table " + tableName + " ";

            for(int j = 0; j < headerList.size(); j ++){

                String header = "attr_" + headerList.get(j);
                String dataType = "varchar2(4000 byte)";

                if("INFA_NODE_TABLEATTRIBUTE.csv".equals(file_name)
                        && "VALUE".equals(headerList.get(j))){
                    dataType = "clob";
                }

                if( j == 0){
                    create_script = create_script + "("  + header + " " + dataType + ",";
                }

                if( j > 0 && j < headerList.size() -1){
                    create_script = create_script + header + " " + dataType + ",";
                }

                if( j == headerList.size() -1){
                    create_script = create_script + header + " " + dataType + ")";
                }
            }

            create_script = create_script + "";

        } catch (Exception e){

            e.printStackTrace();

        } finally {

            return create_script;
        }
    }



    public static List<String> insertStatementGen(String inputFile, String tableName) {

        String insert_script = "";
        List insertStatList = new ArrayList<String>();
        Path filePath = Paths.get(inputFile);

        try {
            BufferedReader br = Files.newBufferedReader(filePath, StandardCharsets.UTF_8);
            String line = br.readLine();
            int i = 0;

            while (line != null) {

                if(i > 0) {

                    List<String> columnList = Arrays.asList(line.split("\",\""));
                    insert_script = "insert into " + tableName + " values ";

                    for(int j = 0; j < columnList.size(); j ++){
                        String col = columnList.get(j);

                        if(col.indexOf("\'") >=0) {
                            col = col.replace("'","''");
                        }

                        if(col.indexOf("@#@") >=0) {
                            col = col.replace("@#@","\",\"");
                        }

                        if(j == 0){
                            col = col.replace("\"","");
                            insert_script = insert_script + "(\'" + col + "\'" + ",";
                        }
                        if(j > 0 && j < columnList.size() - 1) {
                            insert_script = insert_script + "\'" + col + "\'" + ",";
                        }
                        if(j == columnList.size() - 1){
                            col = col.replace("\"","");
                            insert_script = insert_script + "\'" + col + "\'" + ")";
                        }
                    }

                    insertStatList.add(insert_script);
                }

                i ++;
                line = br.readLine();
            }

        } catch (Exception e){

            e.printStackTrace();
        } finally {

            return insertStatList;
        }
    }
}

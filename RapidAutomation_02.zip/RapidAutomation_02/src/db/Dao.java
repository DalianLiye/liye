package db;

import common.Common;
import config.Configure;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Dao {


    public void syncTable(Connection conn, String inputFile, int syncMode) throws SQLException {

        Statement statement = conn.createStatement();
        File file =new File(inputFile);
        String tableName = file.getName().replace(".csv","");

        List<String> insertStatList = CommonDB.insertStatementGen(inputFile,tableName);

        if(syncMode == Configure.SYNC_MODE_TRUNC_INSERT){
            statement.executeUpdate("truncate table " + tableName);
        }

        if(syncMode == Configure.SYNC_MODE_DROP_INSERT){
            String createStat = CommonDB.createStatementGen(inputFile,tableName);
            boolean check_flg = checkTableExist(statement, tableName);

            if(check_flg){
                statement.executeUpdate("drop table " + tableName);
            }
            statement.executeUpdate(createStat);
        }
        System.out.println(insertStatList.size());
        String insertStat  = "";
        for(String insert : insertStatList){
            statement.addBatch(insert);
        }
        statement.executeBatch();
        //statement.executeUpdate(insertStat);

        statement.close();
    }

    public void syncTable01(Connection conn, String inputFile, int syncMode) throws SQLException {

        PreparedStatement pst = null;
        Statement statement = conn.createStatement();

        File file =new File(inputFile);
        String tableName = file.getName().replace(".csv","");
        Path filePath = Paths.get(inputFile);


        if(syncMode == Configure.SYNC_MODE_TRUNC_INSERT){
            statement.executeUpdate("truncate table " + tableName);
        }

        if(syncMode == Configure.SYNC_MODE_DROP_INSERT){
            String createStat = CommonDB.createStatementGen(inputFile,tableName);
            boolean check_flg = checkTableExist(statement, tableName);

            if(check_flg){
                statement.executeUpdate("drop table " + tableName);
            }
            statement.executeUpdate(createStat);
        }


        String insert_script = "";
        String question_mark = "";
        try {
            BufferedReader br = Files.newBufferedReader(filePath, StandardCharsets.UTF_8);
            String line = br.readLine();

            int i = 0;
            while (line != null) {

                if(i == 0){
                    List<String> headerList = Arrays.asList(line.split(","));

                    for(int j=0; j < headerList.size(); j++){
                        if(j == 0){
                            question_mark = question_mark + "?";
                        } else {
                            question_mark = question_mark + ",?";
                        }
                    }
                    insert_script = "insert into " + tableName + " values (" + question_mark + ")";

                } else {

                    List<String> columnList = Arrays.asList(line.split("\",\""));
                    conn.setAutoCommit(false);
                    pst = conn.prepareStatement(insert_script);
                    for(int k=0; k < columnList.size(); k ++){
                        pst.setString(k + 1,columnList.get(k));
                    }
                    pst.addBatch();
                    pst.executeBatch();
                    conn.commit();
                }
                i ++;
                line = br.readLine();
            }
        } catch (Exception e){
            e.printStackTrace();
        }

    }


    public String exportStoreProcedure(Connection conn, String procedureName, String schema) throws SQLException {

        Statement statement = conn.createStatement();
        String query_scripts = "";

        if("RPD_PROCS".equals(schema)){
            query_scripts = "select * from all_source@rpd_prd411_sp where OWNER ='RPD_PROCS' and NAME='"
                    + procedureName +
                    "' order by 3";
        } else {
            query_scripts= "select * from all_source@rpd_prd411 where OWNER ='RPD_OWNER' and NAME='"
                    + procedureName +
                    "' order by 3";
        }

        String ddl_scripts = "CREATE OR REPLACE ";

        ResultSet rs = statement.executeQuery(query_scripts);
        while(rs.next()) {
            ddl_scripts = ddl_scripts + rs.getString(5);
        }

        statement.close();
        conn.close();

        String scriptsExportPath = Configure.PLSQL_DDL_OUTPUT_DIR + procedureName + ".sql";
        Common.createFile(scriptsExportPath);
        Common.writeToFile(scriptsExportPath, ddl_scripts.toUpperCase());

        return scriptsExportPath;
    }


    public void exportView(Connection conn, String schema) throws SQLException {

        Statement statement = conn.createStatement();
        String query_scripts = "";
        String view_name = "";
        String view_scripts = "";

        if("RPD_OWNER".equals(schema)){
            query_scripts = "select view_name,text from dba_views@rpd_prd411 where OWNER ='RPD_OWNER'";
        }

        ResultSet rs = statement.executeQuery(query_scripts);
        while(rs.next()) {
            view_name = rs.getString(1);
            view_scripts = rs.getString(2);
            view_scripts = view_scripts.replace('，',',');
            String scriptsExportPath = Configure.VIEW_DDL_OUTPUT_DIR + view_name + ".sql";
            Common.createFile(scriptsExportPath);
            Common.writeToFile(scriptsExportPath, view_scripts.toUpperCase());
        }

        statement.close();
        conn.close();

    }

    public boolean checkTableExist(Statement statement, String tableName) throws SQLException {

        boolean check_flg = true;
        String query_scripts = "select count(*) from user_objects where object_name = '"
                + tableName.toUpperCase()
                + "'";

        ResultSet rs = statement.executeQuery(query_scripts);

        while(rs.next()) {
            if("0".equals(rs.getString(1))){
                check_flg = false;
            }
        }
        return check_flg;
    }


    public boolean insertDataToTableByScript(Connection conn, String tableName, String scriptFile) throws SQLException {

        boolean insertFlg = true;

        Statement statement = conn.createStatement();
        File file =new File(scriptFile);

        String insert = "create table " + tableName + " as ";


        boolean check_flg = checkTableExist(statement, tableName);

        if(check_flg){
            statement.executeUpdate("drop table " + tableName);
        }

        String script = " ";
        Path pathToFile = Paths.get(scriptFile);
        try (BufferedReader bufferedReader = Files.newBufferedReader(pathToFile, StandardCharsets.UTF_8)) {

            String line = bufferedReader.readLine();
            while (line != null) {
                script = script + " " + line;
                line = bufferedReader.readLine();
            }

            statement.executeUpdate(insert + script.replace("\r"," "));


        } catch (IOException e) {

            insertFlg = false;
            e.printStackTrace();

        } finally {

            statement.close();
            return insertFlg;
        }

    }


}

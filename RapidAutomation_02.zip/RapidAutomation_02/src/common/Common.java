package common;

import antlr4.dtd.DTDParserLexer;
import antlr4.dtd.DTDParserParser;
import antlr4.infa.ExprParseLexer;
import antlr4.infa.ExprParseParser;
import antlr4.plsql.PlSql2Lexer;
import antlr4.plsql.PlSql2Parser;
import antlr4.plsql.PlSqlLexer;
import antlr4.plsql.PlSqlParser;
import antlr4.test.tableColumnLexer;
import antlr4.test.tableColumnParser;
import antlr4.xml.XMLLexer;
import antlr4.xml.XMLParser;
import config.Configure;
import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.TokenSource;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeWalker;
import plsql.PLSQL2ParseByANTLR4Listener;
import plsql.PLSQLParseByANTLR4Listener;
import plsql.tableColumnParseByANTLR4Listener;
import xml.DTDParseByANTLR4Listener;
import xml.ExprParseByANTLR4Listener;
import xml.XMLParseByANTLR4Listener;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Common {

    // 创建文件
    public static boolean createFile(String fileToCreateWithPath){
        //true: 目标文件不存在，创建文件,
        //false:目标文件已存在，无需创建
        boolean flg = true;

        File file=new File(fileToCreateWithPath);

        if(!file.exists()) {
            try {
                file.createNewFile();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            flg = false;
        }

        return flg;
    }

    //写入文件
    public static void writeToFile(String file, String content) {
        BufferedWriter out = null;
        try {
            out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file, true)));
            out.write(content);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    //删除文件
    public static void deleteAllFiles(File path) {
        if (!path.exists()){
            return;
        }

        if (path.isFile()) {
            path.delete();
            return;
        }

        File[] filesList = path.listFiles();
        for(File file : filesList){
            deleteAllFiles(file);
        }
    }

    public static List<String> checkFilesDir(String dir){

        String[] fileList_temp = new File(dir).list();

        List<String> fileList = new ArrayList<String>();

        for(String str : fileList_temp) {
            fileList.add(str);
        }

        return fileList;
    }


    //启动ANTLR4进行解析
    public static Object parseByANTLR4(String inputFile, int targetType) throws IOException {

        XMLParseByANTLR4Listener xmlParseByANTLR4Listener = null;
        PLSQLParseByANTLR4Listener plsqlParseByANTLR4Listener = null;
        PLSQL2ParseByANTLR4Listener plsql2ParseByANTLR4Listener = null;
        DTDParseByANTLR4Listener dtdParseByANTLR4Listener = null;
        ExprParseByANTLR4Listener exprParseByANTLR4Listener = null;
        tableColumnParseByANTLR4Listener ee = null;

        InputStream is = new FileInputStream(inputFile);
        // create a CharStream that reads from standard input
        ANTLRInputStream input = new ANTLRInputStream(is);

        // Create a generic parse tree walker that can trigger callbacks
        ParseTreeWalker walker = new ParseTreeWalker();

        if(targetType == Configure.PARSE_TARGET_XML){
            // create a lexer that feeds off of input CharStream
            XMLLexer xmlLexer = new XMLLexer(input);

            // create a buffer of tokens pulled from the lexer
            CommonTokenStream tokens = new CommonTokenStream(xmlLexer);

            // create a parser that feeds off the tokens buffer
            XMLParser xmlParser = new XMLParser(tokens);

            // begin parsing at init rule
            ParseTree xmlTree = xmlParser.document();

            // Walk the tree created during the parse, trigger callbacks
            xmlParseByANTLR4Listener = new XMLParseByANTLR4Listener();

            walker.walk(xmlParseByANTLR4Listener, xmlTree);

            return xmlParseByANTLR4Listener;

        } else if(targetType == Configure.PARSE_TARGET_PLSQL_SP){
            // create a lexer that feeds off of input CharStream
            PlSql2Lexer Lexer = new PlSql2Lexer(input);
            // create a buffer of tokens pulled from the lexer
            CommonTokenStream tokens = new CommonTokenStream((TokenSource) Lexer);
            // create a parser that feeds off the tokens buffer
            PlSql2Parser parser = new PlSql2Parser(tokens);
            ParseTree tree = parser.sql_script(); // begin parsing at init rule

            // Walk the tree created during the parse, trigger callbacks
            plsql2ParseByANTLR4Listener = new PLSQL2ParseByANTLR4Listener();

            walker.walk(plsql2ParseByANTLR4Listener, tree);

            return plsql2ParseByANTLR4Listener;

        }  else if(targetType == Configure.PARSE_TARGET_PLSQL_PK || targetType == Configure.PARSE_TARGET_PLSQL_SQLQUERY){
            // create a lexer that feeds off of input CharStream
            PlSqlLexer Lexer = new PlSqlLexer(input);
            // create a buffer of tokens pulled from the lexer
            CommonTokenStream tokens = new CommonTokenStream((TokenSource) Lexer);
            // create a parser that feeds off the tokens buffer
            PlSqlParser parser = new PlSqlParser(tokens);
            ParseTree tree = parser.sql_script(); // begin parsing at init rule

            // Walk the tree created during the parse, trigger callbacks
            plsqlParseByANTLR4Listener = new PLSQLParseByANTLR4Listener();

            walker.walk(plsqlParseByANTLR4Listener, tree);

            return plsqlParseByANTLR4Listener;

        } else if(targetType == Configure.PARSE_TARGET_DTD) {
            // create a lexer that feeds off of input CharStream
            DTDParserLexer Lexer = new DTDParserLexer(input);
            // create a buffer of tokens pulled from the lexer
            CommonTokenStream tokens = new CommonTokenStream((TokenSource) Lexer);
            // create a parser that feeds off the tokens buffer
            DTDParserParser parser = new DTDParserParser(tokens);
            ParseTree tree = parser.dtd_document(); // begin parsing at init rule

            // Walk the tree created during the parse, trigger callbacks
            dtdParseByANTLR4Listener = new DTDParseByANTLR4Listener();

            walker.walk(dtdParseByANTLR4Listener, tree);

            return dtdParseByANTLR4Listener;

        } else if(targetType == Configure.PARSE_TARGET_EXPR) {
            // create a lexer that feeds off of input CharStream
            ExprParseLexer Lexer = new ExprParseLexer(input);
            // create a buffer of tokens pulled from the lexer
            CommonTokenStream tokens = new CommonTokenStream((TokenSource) Lexer);
            // create a parser that feeds off the tokens buffer
            ExprParseParser parser = new ExprParseParser(tokens);
            ParseTree tree = parser.expression(); // begin parsing at init rule

            // Walk the tree created during the parse, trigger callbacks
            exprParseByANTLR4Listener = new ExprParseByANTLR4Listener();

            walker.walk(exprParseByANTLR4Listener, tree);

            return exprParseByANTLR4Listener;

        } else if(targetType == Configure.PARSE_TARGET_PLSQL_SQLQUERY_COLUMN) {
            // create a lexer that feeds off of input CharStream
            tableColumnLexer Lexer = new tableColumnLexer(input);
            // create a buffer of tokens pulled from the lexer
            CommonTokenStream tokens = new CommonTokenStream((TokenSource) Lexer);
            // create a parser that feeds off the tokens buffer
            tableColumnParser parser = new tableColumnParser(tokens);
            ParseTree tree = parser.scripts(); // begin parsing at init rule

            // Walk the tree created during the parse, trigger callbacks
            ee = new tableColumnParseByANTLR4Listener();

            walker.walk(ee, tree);

            return ee;

        } else  {

            return null;
        }


    }

    public static String replaceXmlStr(String xmlStr){
        String xmlStrReplaced = "";
        xmlStrReplaced = xmlStr.replace("&#xD;","\r");
        xmlStrReplaced = xmlStrReplaced.replace("&#xA;","\n");
        xmlStrReplaced = xmlStrReplaced.replace("&#x9;","\t");
        xmlStrReplaced = xmlStrReplaced.replace("&apos;","\'");
        xmlStrReplaced = xmlStrReplaced.replace("&gt;",">");
        xmlStrReplaced = xmlStrReplaced.replace("&lt;","<");
        xmlStrReplaced = xmlStrReplaced.replace("&quot;","\"");


        return xmlStrReplaced;
    }

    public static String timeDiff(Date start_date, Date end_date) {

        long  diff = end_date.getTime() - start_date.getTime();
        SimpleDateFormat formatter = new SimpleDateFormat("hh:mm:ss");
        String diff_format = formatter.format(diff);
        return diff_format;
    }

    public static boolean accessInfaRepository(){

        StringBuilder stringBuilder = new StringBuilder();

        Process process = null;
        String line = null;
        boolean resultFlg = false;

        try {
            String cmd = Configure.INFA_CLIENT_LOCAL_PATH + "pmrep.exe" + Configure.SPACE_STRING +
                         "connect" + Configure.SPACE_STRING +
                         "-r" + Configure.SPACE_STRING + Configure.INFA_REPO + Configure.SPACE_STRING +
                         "-d" + Configure.SPACE_STRING + Configure.INFA_DOM + Configure.SPACE_STRING +
                         "-s" + Configure.SPACE_STRING + Configure.INFA_SECURITY_DOM + Configure.SPACE_STRING +
                         "-n" + Configure.SPACE_STRING + Configure.INFA_ACCOUNT + Configure.SPACE_STRING +
                         "-x" + Configure.SPACE_STRING + Configure.INFA_PASSWORD;

            process = Runtime.getRuntime().exec(cmd);

            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream(), "GBK"));
            while((line = bufferedReader.readLine()) != null) {
                if(line.indexOf("已成功完成") >= 0){
                    resultFlg = true;
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            return resultFlg;
        }
    }

    public static boolean exportWorkflowXML(String workflowName, String localDir){
        StringBuilder stringBuilder = new StringBuilder();

        Process process = null;
        String line = null;
        boolean resultFlg = false;

        try {

            String cmd = Configure.INFA_CLIENT_LOCAL_PATH + "pmrep.exe" + Configure.SPACE_STRING +
                       "objectexport"  + Configure.SPACE_STRING +
                       "-n" + workflowName + Configure.SPACE_STRING +
                       "-o workflow" + Configure.SPACE_STRING +
                       "-f rapid_project" + Configure.SPACE_STRING +
                       "-s -b -r" + Configure.SPACE_STRING +
                       "-u" + Configure.SPACE_STRING + localDir + workflowName + ".xml";

                    process = Runtime.getRuntime().exec(cmd);

            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream(), "GBK"));
            while((line = bufferedReader.readLine()) != null) {
                if(line.indexOf("已成功完成") >= 0){
                    resultFlg = true;
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            return resultFlg;
        }

    }



}

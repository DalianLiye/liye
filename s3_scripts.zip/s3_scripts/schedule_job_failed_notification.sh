#!/bin/sh
###############################################################################
#   自动job执行失败提醒，当自动job执行失败，会将失败job信息写入csv文件，并将csv文件发送运维人员
#   需要三个传参数：1.文件名字 2.邮件主题 3.邮件接收人        
#   例如：sh schedule_job_failed_notification.sh schedule_job_failed_notification.csv 'Schedule Job Failed Notification' 'shi_liye@network.lilly.com'
###############################################################################


fileName=$1
mailTitle=$2
receiver=$3

if [ -s ${fileName} ] ; then 
  cat ${fileName} | mail -s ${mailTitle} ${receiver};
fi

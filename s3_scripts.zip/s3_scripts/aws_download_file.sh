#!/bin/sh
#######################################################################################
##Discription: This scripts is created for demo cp files between aws s3 and local dc
##Created by: Charles Li
##Creaged Date: 2021-7-1
#######################################################################################
 
#setting input var
systemname=$1
filename=$2
#this var is setting for an optional input for ad-hoc date running by defualt it's system date - 8hours if run before 8am cst
localtime=$(date "+%Y-%m-%d")
utctime=$(date -d "-8 hours" "+%Y-%m-%d")

if [ $localtime = $utctime ]; then 
runtime=$localtime
else 
runtime=$utctime 
fi

timestamp=${3:-$runtime}
#timestamp=${3:-$(date +"%Y-%m-%d")}


#setting global var --need change here for different environment
rootfolder="/appdata/rapidprd"
awsenv="prd"
#awsenv="qa"
#setting var
bucketname="lly-cn-ibu-rapid-$systemname-$awsenv-private"
localdir="$rootfolder/home/CFC/ToRAPID/$systemname"
#profilename=$systemname"_dev_profile"
#echo "profile name is: "$profilename
pramfiledir="$rootfolder/rapid/parms"
#need to create a folder mailbody under parms
pramemaildir="$rootfolder/rapid/parms/mailbody"
#need to create a folder aws under log
logdir="$rootfolder/rapid/log/aws"
#timestamp=$(date +"%Y-%m-%d")

#need to create txt file with all emails listed in the file
export emaillist=`cat $pramfiledir/$systemname"_email_list".txt`

#input file name before running shell scripts
if [ $# -ne 2 ] && [ $# -ne 3 ]; then
echo "***Error**** -Please entry the system name and  file name or date optional you want to perform"
exit
fi

#Proxy settings with china proxy
#export http_proxy=http://proxy.gtm.lilly.com:9000/
#export https_proxy=https://proxy.gtm.lilly.com:9000/
export http_proxy=http://pcnshan1-int.xh3.lilly.com:9000/
export https_proxy=https://pcnshan1-int.xh3.lilly.com:9000/

echo $http_proxy > $logdir/sh_log_$systemname"_"$filename.log
echo $http_proxy >> $logdir/sh_log_$systemname"_"$filename.log

#configure the connections
sh $rootfolder/rapid/scripts/$systemname"_"$awsenv"_aws_config".sh #>> $logdir/sh_log_$systemname"_"$filename.log
echo "aws configure completed" >> $logdir/sh_log_$systemname"_"$filename.log
#delete the files before loading
rm $localdir/$filename.*
echo "files $filename.* under $localdir/ are removed" >> $logdir/sh_log_$systemname"_"$filename.log

#copy file and check if status, retry 5 times every 5mins, if all failed them mail out notification
for i in {0..5};
do
if [ $i -le 4 ]; then
#put it here run again just in case any configure missing records for first few configrations
sh $rootfolder/rapid/scripts/$systemname"_"$awsenv"_aws_config".sh
#aws s3 cp s3://$bucketname/ToRAPID/$filename/$timestamp/ $localdir/ --recursive  ##--profile $profilename #>$logdir/err_$filename.log
echo "file folders on aws is: s3://"$bucketname/ToRAPID/$filename/$timestamp/ >> $logdir/sh_log_$systemname"_"$filename.log
aws s3 cp s3://$bucketname/ToRAPID/$filename/$timestamp/ $localdir/ --recursive >> $logdir/sh_log_$systemname"_"$filename.log

 if [ -f $localdir/$filename.rdy ]; then
 #this is for success testing, will remove once work if its not neccessary
 echo "File $filename.csv  transfered completed"|mail -s "file $filename transfered successfully" ${emaillist}
 echo "file $filename.csv transfered successfully" >> $logdir/sh_log_$systemname"_"$filename.log
 break

 else

 echo "file $filename.csv  not exist, waiting for 5mins to execute again" >> $logdir/sh_log_$systemname"_"$filename.log

 sleep 300 #300 change back to 300 while go live, 10 is temporily for testing usage 10 seconds break

 fi
fi

#all re-run failed then send out notification email
if [ $i = 5 ]; then
#email body with file names
echo "Hi Users-,

File $filename.csv  was not proccessed. We will look into the issues and get back to you asap.

Thank you" > $pramemaildir/mail_body_$filename.txt

#emailing with msg
cat $pramemaildir/mail_body_$filename.txt|mail -s "file $filename.csv transfered failed" ${emaillist}

exit 1

fi

i=i+1 

done 



#!/bin/bash
##############################################################
#Created By: Charles Li
# Date: 19/07/2021
# Comment: build up the connectivity between local and aws s3   
##############################################################

#setting global var --need change here for different environment
rootfolder="/appdata/rapidprd"
awsenv="qa"

varfile="$rootfolder/rapid/parms/aws_$awsenv"_config".var"

export accesskey=`grep idoctoraccesskey $varfile|cut -c18-`
export secukey=`grep idoctorsecukey $varfile|cut -c16-`

/usr/bin/expect <<EOD
spawn aws configure
expect "]:"
send "$accesskey\r"
expect "]:"
send "$secukey\r"
expect "]:"
send "cn-northwest-1\r"
expect "]:"
send "csv\r"
interact
EOD
echo "configure completed"

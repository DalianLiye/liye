#!/bin/sh

###############################################################################
#   查找文件并压缩文件
#        
#  
#
###############################################################################

#etldate=$1

etldate=` date +"%Y%m%d" `
publishPath=/appdata/rapidprd/home/
filePath=$publishPath$1
fileName=$2
compressFilePath=$filePath/CFP
logPath=$filePath/log

if [ $# -ne 2 ]
then
    echo "Parameters Error,Example: sh compressFile.sh 参数1(/appdata/rapiddev/home/后面存放文件路径) 参数2(文件名带后缀名)"
    exit -1
fi


[ -d ${filePath} ] || mkdir -p ${filePath};
[ -d ${compressFilePath} ] || mkdir -p ${compressFilePath};
[ -d ${logPath} ] || mkdir -p ${logPath};


logfile=${logPath}/${fileName}_${etldate}.log
>$logfile

if [[ -f ${filePath}/${fileName} ]]
 then
  echo "[`date +%Y_%m_%d_%H_%M_%S_%N`] Start to zip file  ${fileName}" >> $logfile
  cd $filePath
  tar -zcvf ${compressFilePath}/${fileName}.tar.gz ${fileName}
   if [ $? -eq 0 ]
     then
       echo "[${fileName} zipped file path] ${compressFilePath}" >> $logfile
       echo "[`date +%Y_%m_%d_%H_%M_%S_%N`] File ${fileName} zipped Successfully " >> $logfile
   else 
       echo "[`date +%Y_%m_%d_%H_%M_%S_%N`] File ${fileName} zipped Failed" >> $logfile
   fi  
else
   echo "File is not exists,please check"  
   echo "File is not exists" >> $logfile
fi



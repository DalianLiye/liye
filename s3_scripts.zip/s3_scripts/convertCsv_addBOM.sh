#!/bin/sh

###############################################################################
#   因为需要将CSV用Excel直接打开，所以需要在CSV文件增加BOM头,BOM主要是为了解决Linux文件在Windows上乱码的问题
#   1.生成BOM开头的文件 
#   2.将informatica生成的文件数据追加到tmp文件
#   3.替换原有文件
###############################################################################

etldate=` date +"%Y%m%d" `
filePath=$1

if [ $# -ne 1 ]
then
    echo "Parameters Error,Example: sh exportCsv_addBOM.sh 参数1(/appdata/rapiddev/home)"
    exit -1
fi

convert_file() {

csvFile=${1}.csv
tmp_cavFile=${1}_tmp.csv

if [[ -f ${filePath}/${csvFile} ]] #判断文件是否存在
then 
    cd ${filePath}/
    printf '\xEF\xBB\xBF' > ${tmp_cavFile}  # 在文件中添加BOM头
	cat ${csvFile} >> ${tmp_cavFile}
	mv ${tmp_cavFile} ${csvFile} #替换原有文件	
	chmod 777 ${csvFile} 
else
    echo "数据文件没有生成"
    exit -1	
fi
}

for file in ${filePath}/*.csv    #提取路径下所有csv文件并转换为带BOM头的文件
do
   fileName=$(basename $file .csv) #提取文件名，不带后缀
   echo ${fileName}
   convert_file ${fileName}
done

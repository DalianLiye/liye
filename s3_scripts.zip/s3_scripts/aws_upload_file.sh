#!/bin/sh
#######################################################################################
##Discription: This scripts is created for demo cp files between aws s3 and local dc
##Created by: Charles Li
##Creaged Date: 2021-7-1
#######################################################################################
 
#setting up http(s) proxy this is for establishing the connectivity between local dc and s3 as aws not within lilly internet
#sh aws_proxy_settings.sh
#if command run successfully then echo else exit
#if [ $? = 0 ]; then
#echo "proxy setting successfully"
#else exit
#fi

#setting input var
systemname=$1
filename=$2
#this var is setting for an optional input for ad-hoc date running by defualt it's system date - 8hours if run before 8am cst
#localtime=$(date "+%Y-%m-%d")
#localtimeminus8hrs=$(date -d "-8 hours" "+%Y-%m-%d")

#if [ $localtime = $localtimeminus8hrs ]; then 
#runtime=$localtime
#else 
#runtime=$localtimeminus8hrs 
#fi

#timestamp=${3:-$runtime}
timestamp=${3:-$(date +"%Y-%m-%d")}


#setting global var --need change here for different environment
rootfolder="/appdata/rapidprd"
#setting awsenv to qa for testing purpose... connecting to aws qa environment
awsenv="prd"
#awsenv="qa"
#awsenv="dev"

#setting var
bucketname="lly-cn-ibu-rapid-$systemname-$awsenv-private"
localdir="$rootfolder/home/CFC/RapidTo"
#profilename="idoctor_"$awsenv"_profile"
#echo "profile name is: "$profilename
pramfiledir="$rootfolder/rapid/parms"
#need to create a folder mailbody under parms
pramemaildir="$rootfolder/rapid/parms/mailbody"
#need to create a flag folger for rdy file
flgfile="$rootfolder/rapid/parms/finishflag/finish.rdy" 
#need to create a folder aws under log
logdir="$rootfolder/rapid/log/aws"
#timestamp=$(date +"%Y-%m-%d")

#need to create txt file with all emails listed in the file
export emaillist=`cat $pramfiledir/$systemname"_email_list".txt`

#input file name before running shell scripts
if [ $# -ne 2 ] && [ $# -ne 3 ]; then
echo "***Error**** -Please entry the system name and file name or date optional you want to perform"
exit
fi

#Proxy settings with china proxy
#export http_proxy=http://proxy.gtm.lilly.com:9000/
#export https_proxy=https://proxy.gtm.lilly.com:9000/
export http_proxy=http://pcnshan1-int.xh3.lilly.com:9000/
export https_proxy=https://pcnshan1-int.xh3.lilly.com:9000/

echo $http_proxy > $logdir/sh_log_$systemname"_"$filename.log
echo $http_proxy >> $logdir/sh_log_$systemname"_"$filename.log

#configure the connections
sh $rootfolder/rapid/scripts/$systemname"_"$awsenv"_aws_config".sh
echo "aws configure completed" >> $logdir/sh_log_$systemname"_"$filename.log

#copy file and check if status, retry 5 times every 5mins, if all failed them mail out notification
for i in {0..5};
do
if [ $i -le 4 ]; then
#run configure sh again just in case any mistaking for first few configurations
sh $rootfolder/rapid/scripts/$systemname"_"$awsenv"_aws_config".sh
#if [ ! -f $localdir/$filename.csv ]||[ $? -ne 0 ]; then
 if [ -f $localdir/$filename.csv ]; then
 aws s3 cp $localdir/$filename.csv s3://$bucketname/RapidTo/$filename/$timestamp/$filename.csv
    if [ $? -eq 0 ]; then
    aws s3 cp $flgfile s3://$bucketname/RapidTo/$filename/$timestamp/$filename.rdy
     if [ $? -eq 0 ]; then
     echo "file $filename.csv transfered successfully" >> $logdir/sh_log_$systemname"_"$filename.log
     #this is for success testing, will remove once work if its not neccessary
     echo "File $filename.csv uploaded to aws s3 $bucketname/RapidTo/$filename/$timestamp"|mail -s "file $filename transfered successfully" ${emaillist}
     fi
    fi
 break

 else
  if [ -f $logdir/err_$filename.log ]; then
  echo "file $filename.csv  not exist, waiting for 5mins to execute again" >> $logdir/err_$filename.log
  else
  echo "file $filename.csv  not exist, waiting for 5mins to execute again" >$logdir/err_$filename.log
  fi
 sleep 300 #300 change back to 300 while go live, 10 is temporily for testing usage 10 seconds break
 fi
fi
#all re-run failed then send out notification email
if [ $i = 5 ]; then
#email body with file names
echo "Hi Users-,

File $filename.csv was not proccessed. We will look into the issues and get back to you asap.

Thank you" > $pramemaildir/mail_body_$filename.txt

#emailing with msg
cat $pramemaildir/mail_body_$filename.txt|mail -s "file $filename.csv transfered failed" ${emaillist}
exit 1
fi

i=i+1 

done

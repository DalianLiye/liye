#!/bin/sh
sftp -i /appdata/rapidprd/home/aktana_pem/LillyCN_DW.pem LillyCN_DW@lillycndis.aktana.com << EOF
lcd /appdata/rapidprd/home/aktana_pem
cd /incoming/dev
put LillyCN.csv

